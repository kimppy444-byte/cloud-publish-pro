"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Eye, Users, Video, TrendingUp, Upload, Clock, PlayCircle, ArrowUpRight, RefreshCw } from "lucide-react"
import type { MultiAccountToken } from "@/lib/youtube-auth"
import { Skeleton } from "@/components/ui/skeleton"

interface DashboardOverviewProps {
  accounts: MultiAccountToken[]
  onNavigate: (tab: string) => void
}

interface AccountStats {
  email: string
  name: string
  picture?: string
  viewCount: string
  subscriberCount: string
  videoCount: string
  recentViews?: string
  isLoading: boolean
  error?: string
}

export function DashboardOverview({ accounts, onNavigate }: DashboardOverviewProps) {
  const [accountStats, setAccountStats] = useState<AccountStats[]>([])
  const [isRefreshing, setIsRefreshing] = useState(false)

  const fetchAccountStats = async () => {
    setIsRefreshing(true)
    const stats: AccountStats[] = []

    for (const account of accounts) {
      try {
        const response = await fetch(`/api/youtube/analytics?access_token=${account.access_token}`)
        const data = await response.json()

        stats.push({
          email: account.email,
          name: account.name || account.email.split("@")[0],
          picture: account.picture,
          viewCount: data.channelStats?.viewCount || "0",
          subscriberCount: data.channelStats?.subscriberCount || "0",
          videoCount: data.channelStats?.videoCount || "0",
          isLoading: false,
        })
      } catch {
        stats.push({
          email: account.email,
          name: account.name || account.email.split("@")[0],
          picture: account.picture,
          viewCount: "0",
          subscriberCount: "0",
          videoCount: "0",
          isLoading: false,
          error: "Failed to load",
        })
      }
    }

    setAccountStats(stats)
    setIsRefreshing(false)
  }

  useEffect(() => {
    if (accounts.length > 0) {
      // Initialize with loading state
      setAccountStats(
        accounts.map((a) => ({
          email: a.email,
          name: a.name || a.email.split("@")[0],
          picture: a.picture,
          viewCount: "0",
          subscriberCount: "0",
          videoCount: "0",
          isLoading: true,
        })),
      )
      fetchAccountStats()
    }
  }, [accounts])

  const formatNumber = (num: string) => {
    const n = Number.parseInt(num)
    if (Number.isNaN(n)) return "0"
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`
    return n.toLocaleString()
  }

  const totalViews = accountStats.reduce((sum, a) => sum + Number.parseInt(a.viewCount || "0"), 0)
  const totalSubs = accountStats.reduce((sum, a) => sum + Number.parseInt(a.subscriberCount || "0"), 0)
  const totalVideos = accountStats.reduce((sum, a) => sum + Number.parseInt(a.videoCount || "0"), 0)

  return (
    <div className="space-y-8">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Views</p>
              <p className="text-3xl font-bold mt-1">{formatNumber(totalViews.toString())}</p>
            </div>
            <div className="h-12 w-12 rounded-lg bg-chart-1/10 flex items-center justify-center">
              <Eye className="h-6 w-6 text-chart-1" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-4 text-sm text-success">
            <TrendingUp className="h-4 w-4" />
            <span>Lifetime total</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Subscribers</p>
              <p className="text-3xl font-bold mt-1">{formatNumber(totalSubs.toString())}</p>
            </div>
            <div className="h-12 w-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
              <Users className="h-6 w-6 text-chart-2" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-4 text-sm text-muted-foreground">
            <span>Across {accounts.length} channel(s)</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Videos</p>
              <p className="text-3xl font-bold mt-1">{totalVideos}</p>
            </div>
            <div className="h-12 w-12 rounded-lg bg-chart-3/10 flex items-center justify-center">
              <Video className="h-6 w-6 text-chart-3" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-4 text-sm text-muted-foreground">
            <span>Published videos</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Channels</p>
              <p className="text-3xl font-bold mt-1">{accounts.length}</p>
            </div>
            <div className="h-12 w-12 rounded-lg bg-chart-4/10 flex items-center justify-center">
              <PlayCircle className="h-6 w-6 text-chart-4" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-4 text-sm text-muted-foreground">
            <span>Connected accounts</span>
          </div>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Button
            variant="outline"
            className="h-auto py-4 flex-col gap-2 bg-transparent"
            onClick={() => onNavigate("upload")}
          >
            <Upload className="h-5 w-5" />
            <span className="text-sm">Upload Video</span>
          </Button>
          <Button
            variant="outline"
            className="h-auto py-4 flex-col gap-2 bg-transparent"
            onClick={() => onNavigate("bulk-upload")}
          >
            <Video className="h-5 w-5" />
            <span className="text-sm">Bulk Upload</span>
          </Button>
          <Button
            variant="outline"
            className="h-auto py-4 flex-col gap-2 bg-transparent"
            onClick={() => onNavigate("analytics")}
          >
            <TrendingUp className="h-5 w-5" />
            <span className="text-sm">View Analytics</span>
          </Button>
          <Button
            variant="outline"
            className="h-auto py-4 flex-col gap-2 bg-transparent"
            onClick={() => onNavigate("scheduled")}
          >
            <Clock className="h-5 w-5" />
            <span className="text-sm">Scheduled</span>
          </Button>
        </div>
      </Card>

      {/* Channel Stats */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Channel Performance</h3>
          <Button variant="ghost" size="sm" onClick={fetchAccountStats} disabled={isRefreshing} className="gap-2">
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
        <div className="grid gap-4">
          {accountStats.map((stat) => (
            <Card
              key={stat.email}
              className="p-4 hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => onNavigate(`my-videos-${stat.email}`)}
            >
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={stat.picture || "/placeholder.svg"} />
                  <AvatarFallback className="bg-primary/10 text-primary">{stat.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold truncate">{stat.name}</h4>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{stat.email}</p>
                </div>
                {stat.isLoading ? (
                  <div className="flex gap-6">
                    <Skeleton className="h-10 w-20" />
                    <Skeleton className="h-10 w-20" />
                    <Skeleton className="h-10 w-20" />
                  </div>
                ) : (
                  <div className="flex gap-6">
                    <div className="text-center">
                      <p className="text-lg font-bold">{formatNumber(stat.viewCount)}</p>
                      <p className="text-xs text-muted-foreground">Views</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold">
                        {stat.subscriberCount === "0" ? "Hidden" : formatNumber(stat.subscriberCount)}
                      </p>
                      <p className="text-xs text-muted-foreground">Subs</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold">{stat.videoCount}</p>
                      <p className="text-xs text-muted-foreground">Videos</p>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
