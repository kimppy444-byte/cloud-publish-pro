"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { LogIn, LogOut, Plus } from 'lucide-react'
import {
  initiateOAuthFlow,
  clearToken,
  getAllStoredTokens,
  removeAccount,
  type MultiAccountToken,
} from "@/lib/youtube-auth"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface AuthButtonProps {
  onAuthChange?: (isAuthenticated: boolean, token?: string) => void
}

export function AuthButton({ onAuthChange }: AuthButtonProps) {
  const [accounts, setAccounts] = useState<MultiAccountToken[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadAccounts()
    const interval = setInterval(loadAccounts, 5000)
    return () => clearInterval(interval)
  }, [])

  const loadAccounts = () => {
    const stored = getAllStoredTokens()
    setAccounts(stored)
    setIsLoading(false)
    onAuthChange?.(stored.length > 0, stored[0]?.access_token)
  }

  const handleAddAccount = () => {
    setIsLoading(true)
    initiateOAuthFlow()
  }

  const handleRemoveAccount = (email: string) => {
    removeAccount(email)
    loadAccounts()
    if (getAllStoredTokens().length === 0) {
      window.location.reload()
    }
  }

  const handleLogout = () => {
    clearToken()
    setAccounts([])
    onAuthChange?.(false)
    window.location.reload()
  }
  
  const handleReAuth = () => {
    setIsLoading(true)
    initiateOAuthFlow()
  }

  if (isLoading) return null

  if (accounts.length === 0) {
    return (
      <Button onClick={handleAddAccount} variant="default" size="sm" className="gap-2">
        <LogIn className="w-4 h-4" />
        Sign In with YouTube
      </Button>
    )
  }

  return (
    <div className="flex items-center gap-2">
      <Button onClick={handleReAuth} variant="outline" size="sm" className="gap-2">
        <Plus className="w-4 h-4" />
        Re-auth
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            {accounts.length === 1 ? (
              <>
                <img src={accounts[0].picture || "/placeholder.svg"} alt="Avatar" className="w-4 h-4 rounded-full" />
                {accounts[0].name}
              </>
            ) : (
              <>{accounts.length} Accounts</>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <div className="px-2 py-1.5">
            <p className="text-xs font-semibold text-muted-foreground">Connected Accounts</p>
          </div>
          {accounts.map((account) => (
            <DropdownMenuItem key={account.email} className="flex items-center gap-2">
              <img src={account.picture || "/placeholder.svg"} alt={account.name} className="w-6 h-6 rounded-full" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{account.name}</p>
                <p className="text-xs text-muted-foreground truncate">{account.email}</p>
              </div>
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleAddAccount} className="gap-2">
            <Plus className="w-4 h-4" />
            Add Another Account
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleLogout} className="gap-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-950">
            <LogOut className="w-4 h-4" />
            Sign Out All
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
