"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { fetchChannelInfo, updateChannelInfo } from "@/lib/youtube-auth"
import { Users, Save, X, Loader2, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ChannelManagerProps {
  accessToken: string
}

const CHANNEL_SETTINGS_KEY = "youtube_channel_settings"

interface SavedChannelSettings {
  [channelId: string]: {
    title: string
    description: string
    savedAt: number
  }
}

function getSavedSettings(): SavedChannelSettings {
  if (typeof window === "undefined") return {}
  const stored = localStorage.getItem(CHANNEL_SETTINGS_KEY)
  if (!stored) return {}
  try {
    return JSON.parse(stored)
  } catch {
    return {}
  }
}

function saveSettings(channelId: string, title: string, description: string) {
  const settings = getSavedSettings()
  settings[channelId] = { title, description, savedAt: Date.now() }
  localStorage.setItem(CHANNEL_SETTINGS_KEY, JSON.stringify(settings))
}

export function ChannelManager({ accessToken }: ChannelManagerProps) {
  const [channelData, setChannelData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [apiWarning, setApiWarning] = useState<string | null>(null)
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    title: "",
    description: "",
  })

  useEffect(() => {
    const loadChannelInfo = async () => {
      try {
        const data = await fetchChannelInfo(accessToken)
        setChannelData(data)

        const savedSettings = getSavedSettings()
        const channelId = data.id

        if (savedSettings[channelId]) {
          // Use locally saved settings
          setFormData({
            title: savedSettings[channelId].title,
            description: savedSettings[channelId].description,
          })
        } else {
          // Use API data
          setFormData({
            title: data.brandingSettings?.channel?.title || data.snippet?.title || "",
            description: data.brandingSettings?.channel?.description || data.snippet?.description || "",
          })
        }
      } catch (error) {
        console.error("[v0] Error loading channel info:", error)
        toast({
          title: "Error",
          description: "Failed to load channel information",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadChannelInfo()
  }, [accessToken, toast])

  const handleSave = async () => {
    if (!channelData?.id) {
      toast({
        title: "Error",
        description: "Channel ID not found",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)
    setApiWarning(null)

    try {
      const updateData = {
        id: channelData.id,
        brandingSettings: {
          channel: {
            title: formData.title,
            description: formData.description,
          },
        },
      }

      console.log("[v0] Updating channel with data:", updateData)

      await updateChannelInfo(accessToken, updateData)

      saveSettings(channelData.id, formData.title, formData.description)

      // Update local state
      setChannelData((prev: any) => ({
        ...prev,
        brandingSettings: {
          ...prev.brandingSettings,
          channel: {
            ...prev.brandingSettings?.channel,
            title: formData.title,
            description: formData.description,
          },
        },
      }))

      toast({
        title: "Success",
        description: "Channel settings saved successfully",
      })
    } catch (error: any) {
      console.error("[v0] Error saving channel info:", error)

      saveSettings(channelData.id, formData.title, formData.description)

      setApiWarning(
        "YouTube API may not allow all changes (especially channel title). Your settings have been saved locally and will persist in this app.",
      )

      toast({
        title: "Partial Success",
        description: "Settings saved locally. YouTube API may have restrictions on certain changes.",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleCancel = () => {
    const savedSettings = getSavedSettings()
    const channelId = channelData?.id

    if (channelId && savedSettings[channelId]) {
      setFormData({
        title: savedSettings[channelId].title,
        description: savedSettings[channelId].description,
      })
    } else {
      setFormData({
        title: channelData?.brandingSettings?.channel?.title || channelData?.snippet?.title || "",
        description: channelData?.brandingSettings?.channel?.description || channelData?.snippet?.description || "",
      })
    }
    setApiWarning(null)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!channelData) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">Failed to load channel information</p>
      </Card>
    )
  }

  const subscriberCount = channelData.statistics?.subscriberCount || "0"
  const videoCount = channelData.statistics?.videoCount || "0"

  return (
    <div className="space-y-6">
      {apiWarning && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{apiWarning}</AlertDescription>
        </Alert>
      )}

      {/* Channel Header */}
      <Card className="overflow-hidden">
        <div className="relative h-32 bg-gradient-to-r from-primary/20 to-primary/10"></div>
        <div className="px-6 pb-6">
          <div className="flex gap-4 -mt-16 mb-6">
            <div className="w-28 h-28 rounded-full bg-primary/10 border-4 border-card flex items-center justify-center flex-shrink-0">
              <Users className="w-12 h-12 text-primary" />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Channel Title</label>
              <Input
                value={formData.title}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    title: e.target.value,
                  }))
                }
                placeholder="Channel title"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Note: YouTube may not allow title changes via API for some channels.
              </p>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Channel Description</label>
              <textarea
                value={formData.description}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                placeholder="Channel description"
                className="w-full p-3 border border-input rounded-md bg-background text-foreground min-h-[120px] resize-y"
                rows={4}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={isSaving} className="gap-2">
                {isSaving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save Changes
                  </>
                )}
              </Button>
              <Button onClick={handleCancel} variant="outline" className="gap-2 bg-transparent">
                <X className="w-4 h-4" />
                Cancel
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="p-6">
          <p className="text-sm text-muted-foreground mb-2">Total Videos</p>
          <p className="text-3xl font-bold">{videoCount}</p>
        </Card>
        <Card className="p-6">
          <p className="text-sm text-muted-foreground mb-2">Subscribers</p>
          <p className="text-3xl font-bold">{subscriberCount === "0" ? "Private" : subscriberCount}</p>
        </Card>
      </div>
    </div>
  )
}
