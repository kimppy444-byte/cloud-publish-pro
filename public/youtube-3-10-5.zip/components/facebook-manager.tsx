"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { upload } from "@vercel/blob/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"
import {
  Facebook,
  ThumbsUp,
  MessageCircle,
  Share2,
  Eye,
  Users,
  TrendingUp,
  Send,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Instagram,
  Upload,
  X,
  FileVideo,
  FileImage,
  Info,
  Trash2,
  Edit,
  Scissors,
  Link,
  Repeat,
  ExternalLink,
  Play,
  Languages,
} from "lucide-react"
import { generateFBSmartLink } from "@/lib/fb-smart-link"

// CHANGE: Import SocialUnlockSettings component
import SocialUnlockSettings from "@/components/social-unlock-settings"

interface FacebookPage {
  id: string
  name: string
  picture?: { data: { url: string } }
  access_token: string
  fan_count?: number
  followers_count?: number
  instagram_business_account?: { id: string }
}

interface FacebookPost {
  id: string
  message?: string
  full_picture?: string
  created_time: string
  likes?: { summary: { total_count: number } }
  comments?: { summary: { total_count: number } }
  shares?: { count: number }
}

interface InstagramAccount {
  id: string
  username?: string
  profile_picture_url?: string
  followers_count?: number
  media_count?: number
}

interface InstagramMedia {
  id: string
  caption?: string
  media_type: "IMAGE" | "VIDEO" | "CAROUSEL_ALBUM"
  media_url?: string
  thumbnail_url?: string
  permalink?: string
  timestamp: string
  like_count?: number
  comments_count?: number
}

interface PageInsights {
  page_impressions?: number
  page_engaged_users?: number
  page_post_engagements?: number
  page_fans?: number
}

interface UploadedFile {
  url: string
  filename: string
  size: number
  type: string
  isVideo: boolean
  isImage: boolean
}

interface SocialUnlockConfig {
  enabled: boolean
  targetUrl: string
  actions: {
    follow: boolean
    like: boolean
    comment: boolean
  }
}

export function FacebookManager() {
  const [accessToken, setAccessToken] = useState("")
  const [isConnected, setIsConnected] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [pages, setPages] = useState<FacebookPage[]>([])
  const [selectedPage, setSelectedPage] = useState<FacebookPage | null>(null)
  const [posts, setPosts] = useState<FacebookPost[]>([])
  const [insights, setInsights] = useState<PageInsights | null>(null)
  const [newPostContent, setNewPostContent] = useState("")
  const [isPosting, setIsPosting] = useState(false)

  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [filePreview, setFilePreview] = useState<string | null>(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [mediaUrl, setMediaUrl] = useState("")
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // CHANGE: Added state for Facebook video trimming
  const [fbVideoDuration, setFbVideoDuration] = useState<number | null>(null)
  const [fbTrimStart, setFbTrimStart] = useState(0)
  const [fbTrimEnd, setFbTrimEnd] = useState(60)
  const [isFbTrimmingVideo, setIsFbTrimmingVideo] = useState(false)
  const fbVideoRef = useRef<HTMLVideoElement>(null)

  // CHANGE: Remove Blob file upload for Instagram - just use URL input
  // File preview state (for local preview only, no upload)
  const [igSelectedFile, setIgSelectedFile] = useState<File | null>(null)
  const [igFilePreview, setIgFilePreview] = useState<string | null>(null)
  const igFileInputRef = useRef<HTMLInputElement>(null)

  // Instagram state
  const [instagramAccount, setInstagramAccount] = useState<InstagramAccount | null>(null)
  const [instagramMedia, setInstagramMedia] = useState<InstagramMedia[]>([])
  const [igPostCaption, setIgPostCaption] = useState("")
  const [igMediaUrl, setIgMediaUrl] = useState("")
  const [isIgPosting, setIsIgPosting] = useState(false)
  const [showUrlHelp, setShowUrlHelp] = useState(false)
  // FIX: Added `isIgUploading` state variable
  const [isIgUploading, setIsIgUploading] = useState(false)

  const [permissionError, setPermissionError] = useState<string | null>(null)

  // CHANGE: Added state for delete/edit functionality
  const [deletingPostId, setDeletingPostId] = useState<string | null>(null)
  const [editingPost, setEditingPost] = useState<FacebookPost | null>(null)
  const [editPostContent, setEditPostContent] = useState("")
  const [isEditingPost, setIsEditingPost] = useState(false)

  // CHANGE: Added state for Instagram post management
  const [deletingIgMediaId, setDeletingIgMediaId] = useState<string | null>(null)

  // CHANGE: Added state for Blob upload and video trimming for Instagram
  const [igUploadedFile, setIgUploadedFile] = useState<UploadedFile | null>(null)
  const [igUploadProgress, setIgUploadProgress] = useState(0)
  const [igVideoDuration, setIgVideoDuration] = useState<number | null>(null)
  const [igTrimStart, setIgTrimStart] = useState(0)
  const [igTrimEnd, setIgTrimEnd] = useState(30)
  const [isTrimmingVideo, setIsTrimmingVideo] = useState(false)
  const igVideoRef = useRef<HTMLVideoElement>(null)

  const [selectedPostIds, setSelectedPostIds] = useState<Set<string>>(new Set())
  const [isDeletingMultiple, setIsDeletingMultiple] = useState(false)

  // CHANGE: Added state for post to both FB & IG, smart link, and repeat count
  const [postToBoth, setPostToBoth] = useState(false)
  const [smartLink, setSmartLink] = useState("")

  // CHANGE: Added state for post to all pages
  const [postToAllPages, setPostToAllPages] = useState(false)

  const [postToAllIgAccounts, setPostToAllIgAccounts] = useState(false)

  const [repeatCount, setRepeatCount] = useState(1)
  const [currentRepeat, setCurrentRepeat] = useState(0)

  // CHANGE: Added state for Instagram-only tab smart link and repeat count
  const [igSmartLink, setIgSmartLink] = useState("")
  const [igRepeatCount, setIgRepeatCount] = useState(1)
  const [igCurrentRepeat, setIgCurrentRepeat] = useState(0)

  const [fbSocialUnlock, setFbSocialUnlock] = useState<SocialUnlockConfig>({
    enabled: false,
    targetUrl: "",
    actions: { follow: true, like: true, comment: false },
  })
  const [igSocialUnlock, setIgSocialUnlock] = useState<SocialUnlockConfig>({
    enabled: false,
    targetUrl: "",
    actions: { follow: true, like: true, comment: false },
  })

  // CHANGE: Added state for caption translation
  const [isTranslating, setIsTranslating] = useState(false)
  const [isIgTranslating, setIsIgTranslating] = useState(false)
  const [showTranslateMenu, setShowTranslateMenu] = useState(false)
  const [showIgTranslateMenu, setShowIgTranslateMenu] = useState(false)

  const HARDCODED_IG_ID = "17841478309161802"

  const { toast } = useToast()

  const pagesWithInstagram = pages.filter((page) => page.instagram_business_account)

  useEffect(() => {
    const saved = localStorage.getItem("fb_access_token")
    if (saved) {
      setAccessToken(saved)
    }
  }, [])

  const connectFacebook = async () => {
    if (!accessToken.trim()) {
      toast({ title: "Error", description: "Please enter your access token", variant: "destructive" })
      return
    }

    setIsLoading(true)
    setPermissionError(null)
    try {
      const res = await fetch(
        `https://graph.facebook.com/v19.0/me/accounts?access_token=${accessToken}&fields=id,name,picture,access_token,fan_count,followers_count,instagram_business_account`,
      )
      const data = await res.json()

      if (data.error) {
        throw new Error(data.error.message)
      }

      if (data.data && data.data.length > 0) {
        setPages(data.data)
        setSelectedPage(data.data[0])
        setIsConnected(true)
        localStorage.setItem("fb_access_token", accessToken)
        toast({ title: "Connected!", description: `Found ${data.data.length} page(s)` })

        loadPagePosts(data.data[0])
        loadPageInsights(data.data[0])

        if (data.data[0].instagram_business_account) {
          loadInstagramAccount(data.data[0])
        }
      } else {
        toast({
          title: "No Pages Found",
          description: "Your account doesn't manage any Facebook pages",
          variant: "destructive",
        })
      }
    } catch (error: any) {
      toast({ title: "Connection Failed", description: error.message, variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  const loadPagePosts = async (page: FacebookPage) => {
    try {
      const res = await fetch(
        `https://graph.facebook.com/v19.0/${page.id}/posts?access_token=${page.access_token}&fields=id,message,full_picture,created_time,likes.summary(true),comments.summary(true),shares&limit=10`,
      )
      const data = await res.json()
      if (data.data) {
        setPosts(data.data)
      }
    } catch (error) {
      console.error("Failed to load posts:", error)
    }
  }

  const loadPageInsights = async (page: FacebookPage) => {
    try {
      const res = await fetch(
        `https://graph.facebook.com/v19.0/${page.id}/insights?access_token=${page.access_token}&metric=page_impressions,page_engaged_users,page_post_engagements,page_fans&period=day&date_preset=last_7d`,
      )
      const data = await res.json()
      if (data.data) {
        const insightsMap: PageInsights = {}
        data.data.forEach((item: any) => {
          if (item.values && item.values.length > 0) {
            const key = item.name as keyof PageInsights
            insightsMap[key] = item.values[item.values.length - 1].value
          }
        })
        setInsights(insightsMap)
      }
    } catch (error) {
      console.error("Failed to load insights:", error)
    }
  }

  const loadInstagramAccount = async (page: FacebookPage) => {
    const igId = page.instagram_business_account?.id || HARDCODED_IG_ID

    try {
      const res = await fetch(
        `https://graph.facebook.com/v19.0/${igId}?access_token=${page.access_token}&fields=id,username,profile_picture_url,followers_count,media_count`,
      )
      const data = await res.json()
      if (!data.error) {
        setInstagramAccount(data)
        loadInstagramMedia(igId, page.access_token)
      } else {
        console.log("Instagram fetch error:", data.error)
        setInstagramAccount({ id: HARDCODED_IG_ID, username: "combo_wick1" })
      }
    } catch (error) {
      console.error("Failed to load Instagram account:", error)
    }
  }

  const loadInstagramMedia = async (igId: string, token: string) => {
    try {
      const res = await fetch(
        `https://graph.facebook.com/v19.0/${igId}/media?access_token=${token}&fields=id,caption,media_type,media_url,thumbnail_url,permalink,timestamp,like_count,comments_count&limit=12`,
      )
      const data = await res.json()
      if (data.data) {
        setInstagramMedia(data.data)
      }
    } catch (error) {
      console.error("Failed to load Instagram media:", error)
    }
  }

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setSelectedFile(file)
    const previewUrl = URL.createObjectURL(file)
    setFilePreview(previewUrl)

    // Auto-upload the file
    await uploadFileToBlob(file)
  }

  const uploadFileToBlob = async (file: File) => {
    setIsUploading(true)
    setUploadProgress(30)

    try {
      // Use client-side upload directly to Vercel Blob
      const blob = await upload(file.name, file, {
        access: "public",
        handleUploadUrl: "/api/media/upload",
      })

      setUploadProgress(100)

      const uploadedData = {
        url: blob.url,
        filename: file.name,
        size: file.size,
        type: file.type,
        isVideo: file.type.startsWith("video/"),
        isImage: file.type.startsWith("image/"),
      }

      setUploadedFile(uploadedData)
      setMediaUrl(blob.url)

      toast({
        title: "File uploaded!",
        description: "Your media is ready to post",
      })
    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message || "Failed to upload file",
        variant: "destructive",
      })
      clearSelectedFile()
    } finally {
      setIsUploading(false)
      setTimeout(() => setUploadProgress(0), 1000)
    }
  }

  const clearSelectedFile = () => {
    setSelectedFile(null)
    setFilePreview(null)
    setUploadedFile(null)
    setMediaUrl("")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  // CHANGE: Simplified - no Blob upload, just local preview
  const handleIgFileSelectLocal = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIgSelectedFile(file)
    const previewUrl = URL.createObjectURL(file)
    setIgFilePreview(previewUrl)

    // Show URL help since they need to host the file elsewhere
    setShowUrlHelp(true)
    toast({
      title: "File selected for preview",
      description: "Upload this file to Google Drive, Dropbox, or any file host and paste the direct URL below.",
    })
  }

  const deletePost = async (postId: string) => {
    if (!selectedPage) return

    setDeletingPostId(postId)
    try {
      const res = await fetch(`https://graph.facebook.com/v19.0/${postId}?access_token=${selectedPage.access_token}`, {
        method: "DELETE",
      })

      const data = await res.json()

      if (data.error) {
        throw new Error(data.error.message)
      }

      toast({ title: "Deleted!", description: "Post has been deleted successfully" })
      loadPagePosts(selectedPage)
    } catch (error: any) {
      toast({ title: "Delete Failed", description: error.message, variant: "destructive" })
    } finally {
      setDeletingPostId(null)
    }
  }

  const updatePost = async () => {
    if (!selectedPage || !editingPost) return

    setIsEditingPost(true)
    try {
      const params = new URLSearchParams({
        access_token: selectedPage.access_token,
        message: editPostContent,
      })

      const res = await fetch(`https://graph.facebook.com/v19.0/${editingPost.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params.toString(),
      })

      const data = await res.json()

      if (data.error) {
        throw new Error(data.error.message)
      }

      toast({ title: "Updated!", description: "Post has been updated successfully" })
      setEditingPost(null)
      setEditPostContent("")
      loadPagePosts(selectedPage)
    } catch (error: any) {
      toast({ title: "Update Failed", description: error.message, variant: "destructive" })
    } finally {
      setIsEditingPost(false)
    }
  }

  const deleteInstagramMedia = async (mediaId: string) => {
    if (!selectedPage) return

    setDeletingIgMediaId(mediaId)
    try {
      // Note: Instagram Graph API does not support deleting media via API
      // This will show an informative message
      toast({
        title: "Cannot Delete via API",
        description: "Instagram does not allow deleting posts via the API. Please delete from the Instagram app.",
        variant: "destructive",
      })
    } finally {
      setDeletingIgMediaId(null)
    }
  }

  const handleIgBlobUpload = async (file: File) => {
    setIsIgUploading(true)
    setIgUploadProgress(30)

    try {
      const blob = await upload(file.name, file, {
        access: "public",
        handleUploadUrl: "/api/media/upload",
      })

      setIgUploadProgress(100)

      const uploadedData: UploadedFile = {
        url: blob.url,
        filename: file.name,
        size: file.size,
        type: file.type,
        isVideo: file.type.startsWith("video/"),
        isImage: file.type.startsWith("image/"),
      }

      setIgUploadedFile(uploadedData)
      setIgMediaUrl(blob.url)

      toast({
        title: "File uploaded!",
        description: "Your media is ready. Videos need to be 24-30 seconds for best results.",
      })
    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message || "Failed to upload file",
        variant: "destructive",
      })
      clearIgSelectedFile()
    } finally {
      setIsIgUploading(false)
      setTimeout(() => setIgUploadProgress(0), 1000)
    }
  }

  const handleIgFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIgSelectedFile(file)
    const previewUrl = URL.createObjectURL(file)
    setIgFilePreview(previewUrl)

    // CHANGE: DO NOT upload to Blob here - only create preview for trimming
    // Removed auto-upload to prevent 100MB+ files from failing before editing
    // User will trim first, then upload the smaller trimmed file
    toast({
      title: "Video loaded",
      description: "Adjust the trim settings and click 'Trim Video' to prepare for upload.",
    })
  }

  const handleIgVideoLoaded = () => {
    if (igVideoRef.current) {
      const duration = igVideoRef.current.duration
      setIgVideoDuration(duration)
      setIgTrimEnd(Math.min(30, duration))
    }
  }

  const trimVideoForInstagram = async () => {
    if (!igSelectedFile || !igVideoDuration) return

    setIsTrimmingVideo(true)
    try {
      const { FFmpeg } = await import("@ffmpeg/ffmpeg")
      const { toBlobURL, fetchFile } = await import("@ffmpeg/util")

      const ffmpeg = new FFmpeg()
      await ffmpeg.load({
        coreURL: await toBlobURL("https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js", "text/javascript"),
        wasmURL: await toBlobURL("https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm", "application/wasm"),
      })

      await ffmpeg.writeFile("input.mp4", await fetchFile(igSelectedFile))

      // Trim video to selected duration (24-30 seconds recommended)
      await ffmpeg.exec([
        "-i",
        "input.mp4",
        "-ss",
        igTrimStart.toString(),
        "-to",
        igTrimEnd.toString(),
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "28",
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        "output.mp4",
      ])

      const data = await ffmpeg.readFile("output.mp4")
      const trimmedBlob = new Blob([data], { type: "video/mp4" })
      const trimmedFile = new File([trimmedBlob], `trimmed_${igSelectedFile.name}`, { type: "video/mp4" })

      // CHANGE: NOW upload the trimmed file to Blob (much smaller, won't fail)
      setIsIgUploading(true)
      setIgUploadProgress(30)

      const blob = await upload(trimmedFile.name, trimmedFile, {
        access: "public",
        handleUploadUrl: "/api/media/upload",
      })

      setIgUploadProgress(100)

      setIgUploadedFile({
        url: blob.url,
        filename: trimmedFile.name,
        size: trimmedFile.size,
        type: trimmedFile.type,
        isVideo: true,
        isImage: false,
      })
      setIgMediaUrl(blob.url)

      // Update preview
      const newPreviewUrl = URL.createObjectURL(trimmedBlob)
      if (igFilePreview) URL.revokeObjectURL(igFilePreview)
      setIgFilePreview(newPreviewUrl)

      toast({
        title: "Video trimmed and uploaded!",
        description: `Video trimmed to ${(igTrimEnd - igTrimStart).toFixed(1)} seconds and ready to post.`,
      })

      setIsIgUploading(false)
      setTimeout(() => setIgUploadProgress(0), 1000)
    } catch (error: any) {
      console.error("[v0] Error trimming video:", error)
      toast({
        title: "Trim failed",
        description: error.message || "Failed to trim video",
        variant: "destructive",
      })
      setIsIgUploading(false)
    } finally {
      setIsTrimmingVideo(false)
    }
  }

  const clearIgSelectedFile = () => {
    setIgSelectedFile(null)
    setIgFilePreview(null)
    setIgMediaUrl("")
    setIgUploadedFile(null)
    setIgVideoDuration(null)
    setIgTrimStart(0)
    setIgTrimEnd(30)
    if (igFileInputRef.current) {
      igFileInputRef.current.value = ""
    }
  }

  const deleteMultiplePosts = async () => {
    if (!selectedPage || selectedPostIds.size === 0) return

    setIsDeletingMultiple(true)
    let successCount = 0
    let failCount = 0

    for (const postId of selectedPostIds) {
      try {
        const res = await fetch(
          `https://graph.facebook.com/v19.0/${postId}?access_token=${selectedPage.access_token}`,
          {
            method: "DELETE",
          },
        )
        const data = await res.json()
        if (!data.error) {
          successCount++
        } else {
          failCount++
        }
      } catch {
        failCount++
      }
    }

    toast({
      title: "Bulk Delete Complete",
      description: `Deleted ${successCount} posts. ${failCount > 0 ? `${failCount} failed.` : ""}`,
    })

    setSelectedPostIds(new Set())
    loadPagePosts(selectedPage)
    setIsDeletingMultiple(false)
  }

  const togglePostSelection = (postId: string) => {
    const newSelected = new Set(selectedPostIds)
    if (newSelected.has(postId)) {
      newSelected.delete(postId)
    } else {
      newSelected.add(postId)
    }
    setSelectedPostIds(newSelected)
  }

  const selectAllPosts = () => {
    if (selectedPostIds.size === posts.length) {
      setSelectedPostIds(new Set())
    } else {
      setSelectedPostIds(new Set(posts.map((p) => p.id)))
    }
  }

  // CHANGE: Handle Facebook video loaded to get duration
  const handleFbVideoLoaded = () => {
    if (fbVideoRef.current) {
      const duration = fbVideoRef.current.duration
      setFbVideoDuration(duration)
      setFbTrimEnd(Math.min(60, duration))
    }
  }

  // CHANGE: Trim video for Facebook
  const trimVideoForFacebook = async () => {
    if (!selectedFile || !fbVideoDuration) return

    setIsFbTrimmingVideo(true)
    try {
      const { FFmpeg } = await import("@ffmpeg/ffmpeg")
      const { toBlobURL, fetchFile } = await import("@ffmpeg/util")

      const ffmpeg = new FFmpeg()
      await ffmpeg.load({
        coreURL: await toBlobURL("https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js", "text/javascript"),
        wasmURL: await toBlobURL("https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm", "application/wasm"),
      })

      await ffmpeg.writeFile("input.mp4", await fetchFile(selectedFile))

      // Trim video to selected duration
      await ffmpeg.exec([
        "-i",
        "input.mp4",
        "-ss",
        fbTrimStart.toString(),
        "-to",
        fbTrimEnd.toString(),
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "28",
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        "output.mp4",
      ])

      const data = await ffmpeg.readFile("output.mp4")
      const trimmedBlob = new Blob([data], { type: "video/mp4" })
      const trimmedFile = new File([trimmedBlob], `trimmed_${selectedFile.name}`, { type: "video/mp4" })

      // Upload trimmed file to Blob
      const blob = await upload(trimmedFile.name, trimmedFile, {
        access: "public",
        handleUploadUrl: "/api/media/upload",
      })

      setUploadedFile({
        url: blob.url,
        filename: trimmedFile.name,
        size: trimmedFile.size,
        type: trimmedFile.type,
        isVideo: true,
        isImage: false,
      })
      setMediaUrl(blob.url)

      // Update preview
      const newPreviewUrl = URL.createObjectURL(trimmedBlob)
      if (filePreview) URL.revokeObjectURL(filePreview)
      setFilePreview(newPreviewUrl)

      toast({
        title: "Video trimmed!",
        description: `Video trimmed to ${(fbTrimEnd - fbTrimStart).toFixed(1)} seconds and uploaded.`,
      })
    } catch (error: any) {
      console.error("[v0] Error trimming video:", error)
      toast({
        title: "Trim failed",
        description: error.message || "Failed to trim video",
        variant: "destructive",
      })
    } finally {
      setIsFbTrimmingVideo(false)
    }
  }

  // CHANGE: Modified postToFacebook to accept optional page parameter for posting to all pages
  const postToFacebook = async (
    content: string,
    targetPage?: FacebookPage,
  ): Promise<{ id: string; postUrl: string } | null> => {
    const pageToUse = targetPage || selectedPage
    if (!pageToUse) return null

    setIsPosting(true)
    try {
      let endpoint = `https://graph.facebook.com/v19.0/${pageToUse.id}`
      const body: Record<string, string> = { access_token: pageToUse.access_token }

      if (uploadedFile?.isVideo) {
        endpoint += "/videos"
        body.file_url = uploadedFile.url
        body.description = content
      } else if (uploadedFile?.isImage || mediaUrl) {
        endpoint += "/photos"
        body.url = uploadedFile?.url || mediaUrl
        body.message = content
      } else {
        endpoint += "/feed"
        body.message = content
      }

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      })

      const data = await res.json()
      if (data.error) throw new Error(data.error.message)

      const postId = data.id || data.post_id
      const postUrl = `https://www.facebook.com/${postId}`

      toast({ title: `Posted to ${pageToUse.name}!`, description: "Your post was published successfully." })
      if (pageToUse.id === selectedPage?.id) {
        loadPagePosts(pageToUse) // Re-fetch posts after successful posting only for selected page
      }

      return { id: postId, postUrl }
    } catch (error: unknown) {
      const err = error as Error
      toast({ title: "Post Failed", description: err.message, variant: "destructive" })
      return null
    } finally {
      setIsPosting(false)
    }
  }

  const postToInstagram = async (
    caption: string,
    targetPage?: FacebookPage,
    targetIgId?: string,
  ): Promise<{ id: string; postUrl: string } | null> => {
    const page = targetPage || selectedPage
    const igId = targetIgId || instagramAccount?.id || HARDCODED_IG_ID

    if (!page) return null

    setIsIgPosting(true)
    try {
      const videoUrl = igUploadedFile?.url || igMediaUrl || uploadedFile?.url || mediaUrl

      if (!videoUrl) {
        throw new Error("Please provide a video URL")
      }

      // Create container
      const containerRes = await fetch(`https://graph.facebook.com/v19.0/${igId}/media`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          video_url: videoUrl,
          caption,
          media_type: "REELS",
          access_token: page.access_token,
        }),
      })

      const containerData = await containerRes.json()
      if (containerData.error) throw new Error(containerData.error.message)

      // Wait for processing
      let status = "IN_PROGRESS"
      let attempts = 0
      while (status === "IN_PROGRESS" && attempts < 30) {
        await new Promise((resolve) => setTimeout(resolve, 3000))
        const statusRes = await fetch(
          `https://graph.facebook.com/v19.0/${containerData.id}?fields=status_code&access_token=${page.access_token}`,
        )
        const statusData = await statusRes.json()
        status = statusData.status_code
        attempts++
      }

      if (status !== "FINISHED") {
        throw new Error(`Video processing failed: ${status}`)
      }

      // Publish
      const publishRes = await fetch(`https://graph.facebook.com/v19.0/${igId}/media_publish`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          creation_id: containerData.id,
          access_token: page.access_token,
        }),
      })

      const publishData = await publishRes.json()
      if (publishData.error) throw new Error(publishData.error.message)

      // CHANGE: Fetch the actual permalink from the API instead of constructing a broken URL
      let postUrl = ""
      try {
        const mediaRes = await fetch(
          `https://graph.facebook.com/v19.0/${publishData.id}?fields=permalink&access_token=${page.access_token}`,
        )
        const mediaData = await mediaRes.json()
        if (mediaData.permalink) {
          postUrl = mediaData.permalink
        }
      } catch (e) {
        console.error("Failed to fetch permalink", e)
      }

      // Fallback if permalink fetch fails - use the Instagram username to construct URL
      if (!postUrl && instagramAccount?.username) {
        postUrl = `https://www.instagram.com/${instagramAccount.username}/`
      }

      toast({ title: "Posted to Instagram!", description: "Your Reel was published successfully." })
      fetchInstagramMedia() // Re-fetch media after successful posting

      return { id: publishData.id, postUrl }
    } catch (error: unknown) {
      const err = error as Error
      toast({ title: "Instagram Post Failed", description: err.message, variant: "destructive" })
      return null
    } finally {
      setIsIgPosting(false)
    }
  }

  // CHANGE: Added caption translation function using MyMemory API
  const translateCaption = async (text: string, targetLang: string, isInstagram = false) => {
    if (isInstagram) {
      setIsIgTranslating(true)
    } else {
      setIsTranslating(true)
    }

    try {
      const response = await fetch("/api/youtube/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          targetLanguage: targetLang,
          sourceLanguage: "en",
        }),
      })

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      if (isInstagram) {
        setIgPostCaption(data.translatedText)
        toast({ title: "Caption Translated!", description: `Translated to ${targetLang.toUpperCase()}` })
      } else {
        setNewPostContent(data.translatedText)
        toast({ title: "Caption Translated!", description: `Translated to ${targetLang.toUpperCase()}` })
      }
    } catch (error: any) {
      toast({
        title: "Translation Failed",
        description: error.message || "Failed to translate caption",
        variant: "destructive",
      })
    } finally {
      if (isInstagram) {
        setIsIgTranslating(false)
        setShowIgTranslateMenu(false)
      } else {
        setIsTranslating(false)
        setShowTranslateMenu(false)
      }
    }
  }

  const COMMON_LANGUAGES = [
    { code: "es", name: "Spanish" },
    { code: "fr", name: "French" },
    { code: "de", name: "German" },
    { code: "it", name: "Italian" },
    { code: "pt", name: "Portuguese" },
    { code: "ar", name: "Arabic" },
    { code: "hi", name: "Hindi" },
    { code: "ja", name: "Japanese" },
    { code: "ko", name: "Korean" },
    { code: "zh", name: "Chinese" },
  ]

  const createPost = async () => {
    if (!newPostContent.trim() && !uploadedFile && !mediaUrl) {
      toast({ title: "Error", description: "Please enter content or add media", variant: "destructive" })
      return
    }

    for (let i = 0; i < repeatCount; i++) {
      setCurrentRepeat(i + 1)

      const contentToPost = newPostContent

      const pagesToPost = postToAllPages ? pages : [selectedPage!]

      for (const page of pagesToPost) {
        // Post to Facebook
        const fbResult = await postToFacebook(contentToPost, page)

        // If social unlock is enabled and post succeeded, generate smart link
        if (fbSocialUnlock.enabled && fbSocialUnlock.targetUrl && fbResult) {
          const smartLinkUrl = await generateFBSmartLink({
            postId: fbResult.id,
            pageId: page.id,
            platform: "facebook",
            targetUrl: fbSocialUnlock.targetUrl,
            pageName: page.name,
            postUrl: fbResult.postUrl,
            actions: fbSocialUnlock.actions,
          })

          // Post smart link as a comment
          try {
            await fetch(`https://graph.facebook.com/v19.0/${fbResult.id}/comments`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                message: `🎁 UNLOCK EXCLUSIVE CONTENT: ${smartLinkUrl}`,
                access_token: page.access_token,
              }),
            })
          } catch (e) {
            console.error("Failed to add smart link comment:", e)
          }
        }

        // Post to Instagram if both is selected (only for the selected page's IG account)
        if (postToBoth && instagramAccount && page.id === selectedPage?.id) {
          const igResult = await postToInstagram(contentToPost)

          // If social unlock is enabled for IG and post succeeded
          if (igSocialUnlock.enabled && igSocialUnlock.targetUrl && igResult) {
            const igId = instagramAccount.id || HARDCODED_IG_ID

            const smartLinkUrl = await generateFBSmartLink({
              postId: igResult.id,
              pageId: igId,
              platform: "instagram",
              targetUrl: igSocialUnlock.targetUrl,
              pageName: instagramAccount.username,
              postUrl: igResult.postUrl,
              actions: igSocialUnlock.actions,
            })

            // Comment on IG post with smart link
            try {
              await fetch(`https://graph.facebook.com/v19.0/${igResult.id}/comments`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  message: `🎁 UNLOCK EXCLUSIVE CONTENT: ${smartLinkUrl}`,
                  access_token: selectedPage!.access_token,
                }),
              })
            } catch (e) {
              console.error("Failed to add IG smart link comment:", e)
            }
          }
        }
      }

      if (i < repeatCount - 1) {
        await new Promise((resolve) => setTimeout(resolve, 2000))
      }
    }

    setNewPostContent("")
    setUploadedFile(null)
    setMediaUrl("")
    setSelectedFile(null)
    setFilePreview(null)
    setRepeatCount(1)
    setCurrentRepeat(0)
    setPostToBoth(false) // Reset this checkbox
    setPostToAllPages(false) // Reset this checkbox
  }

  const createInstagramPost = async () => {
    if (!igMediaUrl.trim() && !igUploadedFile?.url) {
      toast({ title: "Error", description: "Please provide media URL or upload a file", variant: "destructive" })
      return
    }
    if (!igPostCaption.trim()) {
      toast({ title: "Error", description: "Please enter a caption", variant: "destructive" })
      return
    }

    const targetAccounts = postToAllIgAccounts
      ? pagesWithInstagram.map((page) => ({ page, igId: page.instagram_business_account!.id }))
      : [{ page: selectedPage!, igId: instagramAccount?.id || HARDCODED_IG_ID }]

    for (let i = 0; i < igRepeatCount; i++) {
      setIgCurrentRepeat(i + 1)

      for (const { page, igId } of targetAccounts) {
        const igResult = await postToInstagram(igPostCaption, page, igId)

        // If social unlock is enabled and post succeeded, add smart link as comment
        if (igSocialUnlock.enabled && igSocialUnlock.targetUrl && igResult && instagramAccount) {
          const smartLinkUrl = await generateFBSmartLink({
            postId: igResult.id,
            pageId: igId,
            platform: "instagram",
            targetUrl: igSocialUnlock.targetUrl,
            pageName: instagramAccount.username,
            postUrl: igResult.postUrl,
            actions: igSocialUnlock.actions,
          })

          // Comment on IG post with smart link
          try {
            await fetch(`https://graph.facebook.com/v19.0/${igResult.id}/comments`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                message: `🎁 UNLOCK EXCLUSIVE CONTENT: ${smartLinkUrl}`,
                access_token: page.access_token,
              }),
            })
          } catch (e) {
            console.error("Failed to add IG smart link comment:", e)
          }
        }
      }

      if (i < igRepeatCount - 1) {
        await new Promise((resolve) => setTimeout(resolve, 2000))
      }
    }

    setIgPostCaption("")
    setIgUploadedFile(null)
    setIgMediaUrl("")
    setIgSelectedFile(null)
    setIgFilePreview(null)
    setIgRepeatCount(1)
    setIgCurrentRepeat(0)
    setPostToAllIgAccounts(false)
  }

  const disconnect = () => {
    localStorage.removeItem("fb_access_token")
    setAccessToken("")
    setIsConnected(false)
    setPages([])
    setSelectedPage(null)
    setPosts([])
    setInsights(null)
    setInstagramAccount(null)
    setInstagramMedia([])
    setPermissionError(null)
    // Reset social unlock states
    setFbSocialUnlock({ enabled: false, targetUrl: "", actions: { follow: true, like: true, comment: false } })
    setIgSocialUnlock({ enabled: false, targetUrl: "", actions: { follow: true, like: true, comment: false } })
    // Reset posting states
    setPostToBoth(false)
    setPostToAllPages(false)
    setSmartLink("")
    setIgSmartLink("")
    setRepeatCount(1)
    setIgRepeatCount(1)
    // Reset postToAllIgAccounts
    setPostToAllIgAccounts(false)
    // Reset translation states
    setIsTranslating(false)
    setIsIgTranslating(false)
    setShowTranslateMenu(false)
    setShowIgTranslateMenu(false)
  }

  const fetchPosts = () => {
    if (selectedPage) {
      loadPagePosts(selectedPage)
    }
  }

  const fetchInstagramMedia = () => {
    if (selectedPage && selectedPage.instagram_business_account) {
      loadInstagramMedia(selectedPage.instagram_business_account.id, selectedPage.access_token)
    }
  }

  if (!isConnected) {
    return (
      <div className="max-w-xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 rounded-2xl bg-blue-500 flex items-center justify-center mb-4">
              <Facebook className="w-8 h-8 text-white" />
            </div>
            <CardTitle>Connect Facebook & Instagram</CardTitle>
            <CardDescription>
              Enter your Facebook Page Access Token to manage your pages and linked Instagram
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Access Token</Label>
              <Input
                type="password"
                placeholder="EAAxxxxxxxx..."
                value={accessToken}
                onChange={(e) => setAccessToken(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Get this from your Facebook Business App settings</p>
            </div>

            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Required Permissions</AlertTitle>
              <AlertDescription className="text-xs space-y-1">
                <p>Your token needs these permissions for posting:</p>
                <ul className="list-disc list-inside mt-1 space-y-0.5">
                  <li>
                    <strong>pages_manage_posts</strong> - Post to pages
                  </li>
                  <li>
                    <strong>pages_read_engagement</strong> - Read page data
                  </li>
                  <li>
                    <strong>instagram_basic</strong> - Access Instagram
                  </li>
                  <li>
                    <strong>instagram_content_publish</strong> - Post to Instagram
                  </li>
                </ul>
                <p className="mt-2">You must be an admin of the page with sufficient permissions.</p>
              </AlertDescription>
            </Alert>

            <Button onClick={connectFacebook} disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <Facebook className="w-4 h-4 mr-2" />
                  Connect Facebook
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Page Selector */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          {pages.map((page) => (
            <Button
              key={page.id}
              variant={selectedPage?.id === page.id ? "default" : "outline"}
              className="gap-2"
              onClick={() => {
                setSelectedPage(page)
                loadPagePosts(page)
                loadPageInsights(page)
                loadInstagramAccount(page)
                setPermissionError(null)
                // Reset social unlock states when page changes
                setFbSocialUnlock({
                  enabled: false,
                  targetUrl: "",
                  actions: { follow: true, like: true, comment: false },
                })
                setIgSocialUnlock({
                  enabled: false,
                  targetUrl: "",
                  actions: { follow: true, like: true, comment: false },
                })
                // Reset posting states
                setPostToBoth(false)
                setPostToAllPages(false)
                setSmartLink("")
                setIgSmartLink("")
                // Reset postToAllIgAccounts when page changes
                setPostToAllIgAccounts(false)
                // Reset translation states
                setIsTranslating(false)
                setIsIgTranslating(false)
                setShowTranslateMenu(false)
                setShowIgTranslateMenu(false)
              }}
            >
              <Avatar className="w-5 h-5">
                <AvatarImage src={page.picture?.data.url || "/placeholder.svg"} />
                <AvatarFallback>{page.name[0]}</AvatarFallback>
              </Avatar>
              {page.name}
            </Button>
          ))}
        </div>
        <Button variant="outline" size="sm" onClick={disconnect}>
          Disconnect
        </Button>
      </div>

      {permissionError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Permission Error</AlertTitle>
          <AlertDescription className="space-y-2">
            <p>{permissionError}</p>
            <div className="text-sm mt-2">
              <p className="font-medium">How to fix:</p>
              <ol className="list-decimal list-inside mt-1 space-y-1">
                <li>Go to your Facebook Business Settings</li>
                <li>Navigate to Business Integrations</li>
                <li>Remove this app and reconnect it</li>
                <li>Make sure to grant all requested permissions</li>
                <li>Ensure you are an admin of the page</li>
              </ol>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Tabs Component */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="create">Create Post</TabsTrigger>
          <TabsTrigger value="instagram" className="gap-1">
            <Instagram className="w-3 h-3" />
            Instagram
          </TabsTrigger>
          <TabsTrigger value="ig-post" className="gap-1">
            <Instagram className="w-3 h-3" />
            Post to IG
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-blue-100">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{selectedPage.fan_count?.toLocaleString() || "N/A"}</p>
                    <p className="text-sm text-muted-foreground">Page Likes</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-green-100">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{selectedPage.followers_count?.toLocaleString() || "N/A"}</p>
                    <p className="text-sm text-muted-foreground">Followers</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-purple-100">
                    <Eye className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{insights?.page_impressions?.toLocaleString() || "N/A"}</p>
                    <p className="text-sm text-muted-foreground">Impressions (7d)</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-orange-100">
                    <ThumbsUp className="w-5 h-5 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{insights?.page_post_engagements?.toLocaleString() || "N/A"}</p>
                    <p className="text-sm text-muted-foreground">Engagements (7d)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Connected Accounts */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-base">
                  <Facebook className="w-5 h-5 text-blue-600" />
                  Facebook Page
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={selectedPage.picture?.data.url || "/placeholder.svg"} />
                    <AvatarFallback>{selectedPage.name[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{selectedPage.name}</p>
                    <Badge variant="secondary" className="mt-1">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Connected
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-base">
                  <Instagram className="w-5 h-5 text-pink-600" />
                  Instagram Account
                </CardTitle>
              </CardHeader>
              <CardContent>
                {instagramAccount ? (
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={instagramAccount.profile_picture_url || "/placeholder.svg"} />
                      <AvatarFallback>{instagramAccount.username?.[0] || "I"}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">@{instagramAccount.username || "combo_wick1"}</p>
                      <Badge variant="secondary" className="mt-1">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Connected
                      </Badge>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <AlertCircle className="w-5 h-5" />
                    <p className="text-sm">No Instagram account linked to this page</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="posts" className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Checkbox
                checked={selectedPostIds.size === posts.length && posts.length > 0}
                onCheckedChange={selectAllPosts}
              />
              <span className="text-sm text-muted-foreground">
                {selectedPostIds.size > 0 ? `${selectedPostIds.size} selected` : "Select all"}
              </span>
            </div>
            {selectedPostIds.size > 0 && (
              <Button
                variant="destructive"
                size="sm"
                onClick={deleteMultiplePosts}
                disabled={isDeletingMultiple}
                className="gap-2"
              >
                {isDeletingMultiple ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete {selectedPostIds.size} Posts
                  </>
                )}
              </Button>
            )}
          </div>

          {editingPost && (
            <Card className="border-2 border-primary">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Edit className="w-5 h-5" />
                  Edit Post
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={editPostContent}
                  onChange={(e) => setEditPostContent(e.target.value)}
                  rows={4}
                  placeholder="Edit your post..."
                />
                <div className="flex gap-2">
                  <Button onClick={updatePost} disabled={isEditingPost}>
                    {isEditingPost ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setEditingPost(null)
                      setEditPostContent("")
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {posts.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No posts found</p>
              </CardContent>
            </Card>
          ) : (
            posts.map((post) => (
              <Card key={post.id} className={selectedPostIds.has(post.id) ? "ring-2 ring-primary" : ""}>
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Checkbox
                        checked={selectedPostIds.has(post.id)}
                        onCheckedChange={() => togglePostSelection(post.id)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        {post.full_picture && (
                          <img
                            src={post.full_picture || "/placeholder.svg"}
                            alt="Post image"
                            className="rounded-lg max-h-64 object-cover mb-3"
                          />
                        )}
                        <p className="whitespace-pre-wrap">{post.message || "(No text)"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="w-4 h-4" />
                        {post.likes?.summary.total_count || 0}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-4 h-4" />
                        {post.comments?.summary.total_count || 0}
                      </span>
                      <span className="flex items-center gap-1">
                        <Share2 className="w-4 h-4" />
                        {post.shares?.count || 0}
                      </span>
                      <span className="ml-auto">{new Date(post.created_time).toLocaleDateString()}</span>
                    </div>
                    <div className="flex gap-2 pt-2 border-t">
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2 bg-transparent"
                        onClick={() => {
                          setEditingPost(post)
                          setEditPostContent(post.message || "")
                        }}
                      >
                        <Edit className="w-4 h-4" />
                        Edit
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="gap-2"
                        onClick={() => deletePost(post.id)}
                        disabled={deletingPostId === post.id}
                      >
                        {deletingPostId === post.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                        Delete
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>Create Post</CardTitle>
              <CardDescription>Post to {selectedPage.name} and optionally to Instagram</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="What's on your mind?"
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                rows={4}
              />

              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowTranslateMenu(!showTranslateMenu)}
                  disabled={!newPostContent.trim() || isTranslating}
                >
                  {isTranslating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Translating...
                    </>
                  ) : (
                    <>
                      <Languages className="mr-2 h-4 w-4" />
                      Translate Caption
                    </>
                  )}
                </Button>

                {showTranslateMenu && (
                  <div className="flex flex-wrap gap-2">
                    {COMMON_LANGUAGES.map((lang) => (
                      <Button
                        key={lang.code}
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => translateCaption(newPostContent, lang.code, false)}
                        disabled={isTranslating}
                      >
                        {lang.name}
                      </Button>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Link className="w-4 h-4" />
                  Smart Link (Optional)
                </Label>
                <Input
                  placeholder="https://your-link.com (will be added to your post)"
                  value={smartLink}
                  onChange={(e) => setSmartLink(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">This link will be appended to your post content</p>
              </div>

              <div className="space-y-3">
                <Label>Upload Media</Label>

                {/* File Preview */}
                {filePreview && (
                  <div className="relative rounded-lg border overflow-hidden">
                    {selectedFile?.type.startsWith("video/") ? (
                      <video
                        ref={fbVideoRef}
                        src={filePreview}
                        className="max-h-48 w-full object-contain bg-black"
                        controls
                        onLoadedMetadata={handleFbVideoLoaded}
                      />
                    ) : (
                      <img
                        src={filePreview || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-48 w-full object-contain bg-muted"
                      />
                    )}
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 h-8 w-8"
                      onClick={clearSelectedFile}
                      disabled={isUploading || isFbTrimmingVideo}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                    {uploadedFile && (
                      <div className="absolute bottom-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Uploaded
                      </div>
                    )}
                  </div>
                )}

                {fbVideoDuration !== null && selectedFile?.type.startsWith("video/") && (
                  <div className="p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg space-y-4">
                    <div className="flex items-center gap-2">
                      <Scissors className="w-5 h-5 text-blue-600" />
                      <h4 className="font-semibold">Trim Video (optional)</h4>
                    </div>

                    <div className="text-sm text-muted-foreground">
                      Current duration: {fbVideoDuration.toFixed(1)}s | Selected: {(fbTrimEnd - fbTrimStart).toFixed(1)}
                      s
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">
                          Start: {fbTrimStart.toFixed(1)}s
                        </label>
                        <input
                          type="range"
                          min="0"
                          max={fbVideoDuration}
                          step="0.1"
                          value={fbTrimStart}
                          onChange={(e) => setFbTrimStart(Number.parseFloat(e.target.value))}
                          className="w-full"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">End: {fbTrimEnd.toFixed(1)}s</label>
                        <input
                          type="range"
                          min="0"
                          max={fbVideoDuration}
                          step="0.1"
                          value={fbTrimEnd}
                          onChange={(e) => setFbTrimEnd(Number.parseFloat(e.target.value))}
                          className="w-full"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {fbTrimEnd - fbTrimStart <= 60 && (
                        <Badge className="bg-green-500">Good length for Facebook!</Badge>
                      )}
                      {fbTrimEnd - fbTrimStart > 240 && (
                        <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                          Consider trimming for better engagement
                        </Badge>
                      )}
                    </div>

                    <Button
                      onClick={trimVideoForFacebook}
                      disabled={isFbTrimmingVideo || fbTrimEnd - fbTrimStart <= 0}
                      className="w-full gap-2"
                    >
                      {isFbTrimmingVideo ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Trimming & Uploading...
                        </>
                      ) : (
                        <>
                          <Scissors className="w-4 h-4" />
                          Trim Video to {(fbTrimEnd - fbTrimStart).toFixed(1)}s
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {/* Upload Button */}
                {!filePreview && (
                  <div
                    className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm font-medium">Click to upload or drag and drop</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Images (JPEG, PNG, GIF) up to 8MB or Videos (MP4, MOV) up to 100MB
                    </p>
                  </div>
                )}

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/gif,image/webp,video/mp4,video/quicktime,video/webm"
                  onChange={handleFileSelect}
                  className="hidden"
                />

                {/* Upload Progress */}
                {isUploading && (
                  <div className="space-y-2">
                    <Progress value={uploadProgress} />
                    <p className="text-xs text-muted-foreground text-center">Uploading... {uploadProgress}%</p>
                  </div>
                )}

                {/* Or use URL */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">Or paste URL</span>
                  </div>
                </div>

                <Input
                  placeholder="https://example.com/video.mp4 or image.jpg"
                  value={mediaUrl}
                  onChange={(e) => {
                    setMediaUrl(e.target.value)
                    if (e.target.value && uploadedFile) {
                      clearSelectedFile()
                    }
                  }}
                  disabled={!!uploadedFile}
                />
              </div>

              {pages.length > 1 && (
                <div className="p-3 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="postToAllPages"
                      checked={postToAllPages}
                      onCheckedChange={(checked) => setPostToAllPages(checked === true)}
                    />
                    <Label htmlFor="postToAllPages" className="flex items-center gap-2 cursor-pointer">
                      <Facebook className="w-4 h-4 text-blue-600" />
                      Post to all {pages.length} pages
                    </Label>
                  </div>
                  {postToAllPages && (
                    <div className="mt-2 ml-7 space-y-1">
                      <p className="text-xs text-muted-foreground">
                        Will post to: {pages.map((p) => p.name).join(", ")}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {instagramAccount && (
                <div className="p-3 bg-gradient-to-r from-pink-50 to-purple-50 dark:from-pink-950 dark:to-purple-950 rounded-lg border border-pink-200 dark:border-pink-800">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="postToBoth"
                      checked={postToBoth}
                      onCheckedChange={(checked) => setPostToBoth(checked === true)}
                    />
                    <Label htmlFor="postToBoth" className="flex items-center gap-2 cursor-pointer">
                      <Facebook className="w-4 h-4 text-blue-600" />
                      <span>+</span>
                      <Instagram className="w-4 h-4 text-pink-600" />
                      Also post to Instagram (@{instagramAccount.username || "combo_wick1"})
                    </Label>
                  </div>
                  {postToBoth && (
                    <p className="text-xs text-muted-foreground mt-2 ml-7">
                      The same media and caption will be posted to both platforms
                    </p>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label>Post Multiple Times</Label>
                <div className="flex items-center gap-3">
                  <Input
                    type="number"
                    min="1"
                    max="10"
                    value={repeatCount}
                    onChange={(e) => setRepeatCount(Math.max(1, Math.min(10, Number.parseInt(e.target.value) || 1)))}
                    className="w-24"
                  />
                  <span className="text-sm text-muted-foreground">time(s)</span>
                </div>
                {repeatCount > 1 && (
                  <p className="text-xs text-muted-foreground">
                    This will create {repeatCount} {postToBoth ? `x 2 = ${repeatCount * 2}` : ""} posts
                  </p>
                )}
              </div>

              {/* Posting Progress */}
              {isPosting && (
                <div className="space-y-2">
                  <Progress value={uploadProgress} />
                  <p className="text-xs text-muted-foreground text-center">
                    {currentRepeat > 0 && `Posting ${currentRepeat}/${repeatCount}... `}
                    {uploadProgress.toFixed(0)}%
                  </p>
                </div>
              )}

              <SocialUnlockSettings config={fbSocialUnlock} setConfig={setFbSocialUnlock} platform="facebook" />

              <div className="flex justify-between items-center">
                <div className="flex gap-2 flex-wrap">
                  <Badge variant="outline" className="gap-1">
                    <FileImage className="w-3 h-3" />
                    Photo
                  </Badge>
                  <Badge variant="outline" className="gap-1">
                    <FileVideo className="w-3 h-3" />
                    Video
                  </Badge>
                  {postToAllPages && (
                    <Badge className="gap-1 bg-gradient-to-r from-blue-500 to-purple-500">
                      <Facebook className="w-3 h-3" />
                      All {pages.length} Pages
                    </Badge>
                  )}
                  {postToBoth && (
                    <Badge className="gap-1 bg-gradient-to-r from-blue-500 to-pink-500">
                      <Instagram className="w-3 h-3" />
                      +IG
                    </Badge>
                  )}
                  {repeatCount > 1 && (
                    <Badge variant="secondary" className="gap-1">
                      x{repeatCount}
                    </Badge>
                  )}
                </div>
                <Button
                  onClick={createPost}
                  disabled={isPosting || isUploading || (!newPostContent.trim() && !mediaUrl.trim())}
                >
                  {isPosting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Posting...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      {postToAllPages ? `Post to All Pages` : postToBoth ? "Post to FB + IG" : "Post to Facebook"}
                      {repeatCount > 1 ? ` (x${repeatCount})` : ""}
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* CHANGE: Added missing Instagram tab content to display Instagram posts */}
        <TabsContent value="instagram" className="space-y-4">
          {instagramMedia.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Instagram className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">No Instagram posts found</p>
                <p className="text-sm text-muted-foreground mt-2">
                  {instagramAccount ? "Start posting to see your content here" : "Connect an Instagram account first"}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {instagramMedia.map((media) => (
                <Card key={media.id} className="overflow-hidden">
                  <div className="relative aspect-square">
                    {media.media_type === "VIDEO" ? (
                      <div className="relative w-full h-full">
                        <img
                          src={media.thumbnail_url || media.media_url || "/placeholder.svg"}
                          alt={media.caption || "Instagram video"}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                          <Play className="w-12 h-12 text-white" />
                        </div>
                      </div>
                    ) : (
                      <img
                        src={media.media_url || "/placeholder.svg"}
                        alt={media.caption || "Instagram post"}
                        className="w-full h-full object-cover"
                      />
                    )}
                    <Badge className="absolute top-2 right-2 bg-pink-600">
                      {media.media_type === "VIDEO"
                        ? "Reel"
                        : media.media_type === "CAROUSEL_ALBUM"
                          ? "Album"
                          : "Photo"}
                    </Badge>
                  </div>
                  <CardContent className="pt-4 space-y-3">
                    {media.caption && <p className="text-sm line-clamp-3">{media.caption}</p>}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="w-4 h-4" />
                        {media.like_count || 0}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-4 h-4" />
                        {media.comments_count || 0}
                      </span>
                      <span className="ml-auto text-xs">{new Date(media.timestamp).toLocaleDateString()}</span>
                    </div>
                    {media.permalink && (
                      <Button variant="outline" size="sm" className="w-full gap-2 bg-transparent" asChild>
                        <a href={media.permalink} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4" />
                          View on Instagram
                        </a>
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="ig-post">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Instagram className="w-5 h-5 text-pink-600" />
                Create Instagram Reel
              </CardTitle>
              <CardDescription>Share a video as an Instagram Reel (24-30 seconds recommended)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {pagesWithInstagram.length > 1 && (
                <div className="p-4 bg-gradient-to-r from-pink-50 to-purple-50 dark:from-pink-950 dark:to-purple-950 border border-pink-200 dark:border-pink-800 rounded-lg space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="postToAllIg"
                      checked={postToAllIgAccounts}
                      onCheckedChange={(checked) => setPostToAllIgAccounts(checked === true)}
                    />
                    <Label htmlFor="postToAllIg" className="flex items-center gap-2 cursor-pointer">
                      <Instagram className="w-4 h-4 text-pink-600" />
                      Post to all Instagram accounts ({pagesWithInstagram.length})
                    </Label>
                  </div>
                  {postToAllIgAccounts && (
                    <div className="text-xs text-muted-foreground pl-6 space-y-1">
                      <p>Will post to:</p>
                      <ul className="list-disc pl-4">
                        {pagesWithInstagram.map((page) => (
                          <li key={page.id}>{page.name} (IG)</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Link className="w-4 h-4" />
                  Smart Link (Optional)
                </Label>
                <Input
                  placeholder="https://your-link.com (will be added to caption)"
                  value={igSmartLink}
                  onChange={(e) => setIgSmartLink(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">This link will be appended to your caption</p>
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Repeat className="w-4 h-4" />
                  Post Multiple Times
                </Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={igRepeatCount}
                    onChange={(e) => setIgRepeatCount(Math.max(1, Math.min(10, Number.parseInt(e.target.value) || 1)))}
                    className="w-20"
                  />
                  <span className="text-sm text-muted-foreground">time(s)</span>
                </div>
              </div>

              <div className="space-y-3">
                <Label>Upload Media (Recommended)</Label>

                {/* File Preview */}
                {igFilePreview && (
                  <div className="relative rounded-lg border overflow-hidden">
                    {igSelectedFile?.type.startsWith("video/") ? (
                      <video
                        ref={igVideoRef}
                        src={igFilePreview}
                        className="max-h-48 w-full object-contain bg-black"
                        controls
                        onLoadedMetadata={handleIgVideoLoaded}
                      />
                    ) : (
                      <img
                        src={igFilePreview || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-48 w-full object-contain bg-muted"
                      />
                    )}
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 h-8 w-8"
                      onClick={clearIgSelectedFile}
                      disabled={isIgUploading || isTrimmingVideo}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                    {igUploadedFile && (
                      <div className="absolute bottom-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Uploaded to Blob
                      </div>
                    )}
                  </div>
                )}

                {/* Video Trimming Controls */}
                {igVideoDuration !== null && igSelectedFile?.type.startsWith("video/") && (
                  <div className="p-4 bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-800 rounded-lg space-y-4">
                    <div className="flex items-center gap-2">
                      <Scissors className="w-5 h-5 text-orange-600" />
                      <h4 className="font-semibold">Trim Video (24-30 seconds recommended)</h4>
                    </div>

                    <div className="text-sm text-muted-foreground">
                      Current duration: {igVideoDuration.toFixed(1)}s | Selected: {(igTrimEnd - igTrimStart).toFixed(1)}
                      s
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">
                          Start: {igTrimStart.toFixed(1)}s
                        </label>
                        <input
                          type="range"
                          min="0"
                          max={igVideoDuration}
                          step="0.1"
                          value={igTrimStart}
                          onChange={(e) => setIgTrimStart(Number.parseFloat(e.target.value))}
                          className="w-full"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">End: {igTrimEnd.toFixed(1)}s</label>
                        <input
                          type="range"
                          min="0"
                          max={igVideoDuration}
                          step="0.1"
                          value={igTrimEnd}
                          onChange={(e) => setIgTrimEnd(Number.parseFloat(e.target.value))}
                          className="w-full"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {igTrimEnd - igTrimStart >= 24 && igTrimEnd - igTrimStart <= 30 && (
                        <Badge className="bg-green-500">Perfect length for Reels!</Badge>
                      )}
                      {igTrimEnd - igTrimStart < 24 && (
                        <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                          Too short (min 24s)
                        </Badge>
                      )}
                      {igTrimEnd - igTrimStart > 30 && (
                        <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                          Consider trimming to 30s or less
                        </Badge>
                      )}
                    </div>

                    <Button
                      onClick={trimVideoForInstagram}
                      disabled={isTrimmingVideo || igTrimEnd - igTrimStart < 0}
                      className="w-full gap-2"
                    >
                      {isTrimmingVideo ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Trimming & Uploading...
                        </>
                      ) : (
                        <>
                          <Scissors className="w-4 h-4" />
                          Trim Video to {(igTrimEnd - igTrimStart).toFixed(1)}s
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {/* Upload Button */}
                {!igFilePreview && (
                  <div
                    className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                    onClick={() => igFileInputRef.current?.click()}
                  >
                    <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm font-medium">Click to upload image or video</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Videos: 24-30 seconds recommended | Images: JPEG, PNG
                    </p>
                  </div>
                )}

                <input
                  ref={igFileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,video/mp4,video/quicktime"
                  onChange={handleIgFileSelect}
                  className="hidden"
                />

                {/* Upload Progress */}
                {isIgUploading && (
                  <div className="space-y-2">
                    <Progress value={igUploadProgress} />
                    <p className="text-xs text-muted-foreground text-center">Uploading... {igUploadProgress}%</p>
                  </div>
                )}

                {/* Or use URL */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">Or paste URL</span>
                  </div>
                </div>

                <Input
                  placeholder="https://example.com/image.jpg or video.mp4"
                  value={igMediaUrl}
                  onChange={(e) => setIgMediaUrl(e.target.value)}
                  disabled={!!igUploadedFile}
                />

                {igUploadedFile && (
                  <p className="text-xs text-green-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Using uploaded file: {igUploadedFile.filename}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Caption</Label>
                <Textarea
                  placeholder="Write a caption..."
                  value={igPostCaption}
                  onChange={(e) => setIgPostCaption(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowIgTranslateMenu(!showIgTranslateMenu)}
                  disabled={!igPostCaption.trim() || isIgTranslating}
                >
                  {isIgTranslating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Translating...
                    </>
                  ) : (
                    <>
                      <Languages className="mr-2 h-4 w-4" />
                      Translate Caption
                    </>
                  )}
                </Button>

                {showIgTranslateMenu && (
                  <div className="flex flex-wrap gap-2">
                    {COMMON_LANGUAGES.map((lang) => (
                      <Button
                        key={lang.code}
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={() => translateCaption(igPostCaption, lang.code, true)}
                        disabled={isIgTranslating}
                      >
                        {lang.name}
                      </Button>
                    ))}
                  </div>
                )}
              </div>

              <SocialUnlockSettings config={igSocialUnlock} setConfig={setIgSocialUnlock} platform="instagram" />

              <div className="space-y-2">
                <Label>Post Multiple Times</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={igRepeatCount}
                    onChange={(e) => setIgRepeatCount(Math.max(1, Math.min(10, Number.parseInt(e.target.value) || 1)))}
                    className="w-20"
                  />
                  <span className="text-sm text-muted-foreground">time(s)</span>
                </div>
              </div>

              {isIgPosting && (
                <div className="space-y-2">
                  <Progress value={uploadProgress} />
                  <p className="text-xs text-muted-foreground text-center">
                    {igCurrentRepeat > 0 && `Posting ${igCurrentRepeat}/${igRepeatCount}... `}
                    {uploadProgress.toFixed(0)}%
                  </p>
                </div>
              )}

              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  <Badge variant="outline" className="gap-1">
                    <FileImage className="w-3 h-3" />
                    Photo
                  </Badge>
                  <Badge variant="outline" className="gap-1">
                    <FileVideo className="w-3 h-3" />
                    Reel
                  </Badge>
                  {igRepeatCount > 1 && (
                    <Badge variant="secondary" className="gap-1">
                      x{igRepeatCount}
                    </Badge>
                  )}
                  {postToAllIgAccounts && pagesWithInstagram.length > 1 && (
                    <Badge className="gap-1 bg-pink-600">
                      <Instagram className="w-3 h-3" />
                      {pagesWithInstagram.length} accounts
                    </Badge>
                  )}
                </div>
                <Button
                  onClick={createInstagramPost}
                  disabled={
                    isIgPosting || isIgUploading || isTrimmingVideo || (!igMediaUrl.trim() && !igUploadedFile?.url)
                  }
                >
                  {isIgPosting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Posting...
                    </>
                  ) : (
                    <>
                      <Instagram className="w-4 h-4 mr-2" />
                      Post to Instagram
                      {postToAllIgAccounts && pagesWithInstagram.length > 1 ? ` (${pagesWithInstagram.length})` : ""}
                      {igRepeatCount > 1 ? ` x${igRepeatCount}` : ""}
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
