"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { MessageCircle, Send, Loader2, CheckCircle2, AlertCircle } from 'lucide-react'
import { useToast } from "@/hooks/use-toast"

interface VideoCommentManagerProps {
  videoId: string
  accessToken: string
  videoTitle: string
}

export function VideoCommentManager({ videoId, accessToken, videoTitle }: VideoCommentManagerProps) {
  const [comment, setComment] = useState("")
  const [isPosting, setIsPosting] = useState(false)
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle")
  const [statusMessage, setStatusMessage] = useState("")
  const { toast } = useToast()

  const handlePostComment = async () => {
    if (!comment.trim()) {
      toast({
        title: "Comment Required",
        description: "Please enter a comment before posting.",
        variant: "destructive",
      })
      return
    }

    setIsPosting(true)
    setStatus("idle")

    try {
      const response = await fetch("/api/youtube/comment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accessToken,
          videoId,
          text: comment,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to post comment")
      }

      setStatus("success")
      setStatusMessage("Comment posted successfully!")
      setComment("")
      
      toast({
        title: "Comment Posted",
        description: "Your comment has been posted to the video.",
      })
    } catch (error) {
      setStatus("error")
      setStatusMessage(error instanceof Error ? error.message : "Failed to post comment")
      
      toast({
        title: "Comment Failed",
        description: error instanceof Error ? error.message : "Failed to post comment",
        variant: "destructive",
      })
    } finally {
      setIsPosting(false)
    }
  }

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 dark:bg-blue-950 rounded-lg">
            <MessageCircle className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          <div>
            <h3 className="font-bold">Post a Comment</h3>
            <p className="text-sm text-muted-foreground line-clamp-1">{videoTitle}</p>
          </div>
        </div>

        <div>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Write your comment here..."
            className="w-full p-3 border border-border rounded-md bg-background text-foreground"
            rows={4}
            disabled={isPosting}
          />
          <p className="text-xs text-muted-foreground mt-1">
            This comment will be posted publicly on the video
          </p>
        </div>

        {status === "success" && (
          <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
            <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
            <p className="text-sm text-green-800 dark:text-green-200">{statusMessage}</p>
          </div>
        )}

        {status === "error" && (
          <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
            <p className="text-sm text-red-800 dark:text-red-200">{statusMessage}</p>
          </div>
        )}

        <Button onClick={handlePostComment} disabled={isPosting || !comment.trim()} className="w-full gap-2">
          {isPosting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Posting...
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              Post Comment
            </>
          )}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          Note: Pinning comments is only available through YouTube Studio due to API limitations
        </p>
      </div>
    </Card>
  )
}
