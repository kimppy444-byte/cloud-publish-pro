"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Zap, RefreshCw, AlertCircle, RotateCw } from 'lucide-react'
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { 
  getAllClients, 
  getActiveClient, 
  setActiveClient, 
  clearQuotaExceeded, 
  getQuotaExceededClients,
  isClientQuotaExceeded,
  type ClientConfig 
} from "@/lib/client-manager"
import { getAutoSwitchPreference, setAutoSwitchPreference } from "@/lib/quota-handler"

interface ClientSwitcherProps {
  onClientSwitch?: (clientId: string) => void
}

export function ClientSwitcher({ onClientSwitch }: ClientSwitcherProps) {
  const [clients, setClients] = useState<ClientConfig[]>([])
  const [activeClient, setActiveClientState] = useState<ClientConfig | null>(null)
  const [quotaExceededClients, setQuotaExceededClients] = useState<string[]>([])
  const [autoSwitch, setAutoSwitch] = useState(false)

  useEffect(() => {
    loadClients()
    setAutoSwitch(getAutoSwitchPreference())
  }, [])

  const loadClients = () => {
    const allClients = getAllClients()
    const active = getActiveClient()
    const exceeded = getQuotaExceededClients()
    setClients(allClients)
    setActiveClientState(active)
    setQuotaExceededClients(exceeded)
  }

  const handleSwitchClient = (clientId: string) => {
    setActiveClient(clientId)
    loadClients()
    onClientSwitch?.(clientId)
  }

  const handleAutoSwitchToggle = (enabled: boolean) => {
    setAutoSwitch(enabled)
    setAutoSwitchPreference(enabled)
  }

  const handleResetQuota = () => {
    clearQuotaExceeded()
    loadClients()
  }

  if (clients.length === 0) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-3 text-muted-foreground">
          <Zap className="w-5 h-5" />
          <div>
            <p className="text-sm font-medium">No API clients configured</p>
            <p className="text-xs mt-1">Add NEXT_PUBLIC_GOOGLE_CLIENT_ID environment variables to enable multi-client switching</p>
          </div>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="auto-switch" className="text-base font-semibold">Auto-Switch on Quota Limit</Label>
              <p className="text-sm text-muted-foreground">
                Automatically switch to the next client when quota is exceeded
              </p>
            </div>
            <Switch
              id="auto-switch"
              checked={autoSwitch}
              onCheckedChange={handleAutoSwitchToggle}
            />
          </div>
          
          {quotaExceededClients.length > 0 && (
            <div className="pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <AlertCircle className="w-4 h-4 text-destructive" />
                  <span>{quotaExceededClients.length} client(s) marked as quota exceeded</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleResetQuota}
                  className="gap-2"
                >
                  <RotateCw className="w-3 h-3" />
                  Reset All
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">API Client Switcher</h3>
          </div>
          {activeClient && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Active:</span>
              <span className="text-sm font-semibold text-foreground">{activeClient.label}</span>
            </div>
          )}
        </div>

        <p className="text-sm text-muted-foreground mb-4">
          Switch between different Google API clients when one reaches its quota limit. You have {clients.length} client(s) configured.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {clients.map((client) => {
            const isActive = activeClient?.id === client.id
            const hasQuotaIssue = isClientQuotaExceeded(client.id)
            
            return (
              <button
                key={client.id}
                onClick={() => !isActive && handleSwitchClient(client.id)}
                className={`p-4 rounded-lg border-2 transition-all text-left relative ${
                  isActive 
                    ? "border-primary bg-primary/10 cursor-default" 
                    : hasQuotaIssue
                      ? "border-destructive/50 bg-destructive/5 hover:border-destructive cursor-pointer"
                      : "border-border hover:border-primary/50 cursor-pointer"
                }`}
              >
                {hasQuotaIssue && !isActive && (
                  <div className="absolute top-2 right-2">
                    <AlertCircle className="w-4 h-4 text-destructive" />
                  </div>
                )}
                
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm">{client.label}</span>
                  {isActive && (
                    <CheckCircle2 className="w-4 h-4 text-primary" />
                  )}
                </div>
                
                <p className="text-xs text-muted-foreground break-all">
                  {client.clientId.substring(0, 20)}...
                </p>
                
                {hasQuotaIssue && (
                  <p className="text-xs text-destructive mt-2">Quota exceeded</p>
                )}
                
                {!isActive && (
                  <div className="mt-3">
                    <Button
                      variant={hasQuotaIssue ? "destructive" : "outline"}
                      size="sm"
                      className="w-full gap-2"
                    >
                      <RefreshCw className="w-3 h-3" />
                      Switch to This
                    </Button>
                  </div>
                )}
              </button>
            )
          })}
        </div>
      </Card>
    </div>
  )
}
