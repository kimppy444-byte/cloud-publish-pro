"use client"

import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Link2, ExternalLink, UserPlus, ThumbsUp, MessageSquare } from "lucide-react"

interface SocialUnlockConfig {
  enabled: boolean
  targetUrl: string
  actions: {
    follow: boolean
    like: boolean
    comment: boolean
  }
}

interface SocialUnlockSettingsProps {
  config: SocialUnlockConfig
  setConfig: (config: SocialUnlockConfig) => void
  platform: "facebook" | "instagram"
}

export default function SocialUnlockSettings({ config, setConfig, platform }: SocialUnlockSettingsProps) {
  const platformColor =
    platform === "instagram"
      ? "from-pink-50 to-purple-50 dark:from-pink-950 dark:to-purple-950 border-pink-200 dark:border-pink-800"
      : "from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200 dark:border-blue-800"

  const iconBg = platform === "instagram" ? "bg-gradient-to-r from-pink-600 to-purple-600" : "bg-blue-600"

  return (
    <Card className={`p-4 bg-gradient-to-r ${platformColor} border-2`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${iconBg}`}>
            <Link2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-lg">Social Unlock</h3>
            <p className="text-sm text-muted-foreground">Require actions to unlock a destination link</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Checkbox
            id={`${platform}-social-unlock-enabled`}
            checked={config.enabled}
            onCheckedChange={(checked) => setConfig({ ...config, enabled: checked === true })}
          />
          <Label htmlFor={`${platform}-social-unlock-enabled`} className="text-sm font-semibold cursor-pointer">
            Enable
          </Label>
        </div>
      </div>

      {config.enabled && (
        <div className="space-y-4 pt-4 border-t border-current/10">
          <div>
            <Label className="text-sm font-semibold mb-2 flex items-center gap-2">
              <ExternalLink className="w-4 h-4" />
              Destination URL (Where users go after unlock)
            </Label>
            <Input
              value={config.targetUrl}
              onChange={(e) => setConfig({ ...config, targetUrl: e.target.value })}
              placeholder="https://example.com/download"
              className="bg-background"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Users must complete actions below before accessing this link
            </p>
          </div>

          <div>
            <Label className="text-sm font-semibold mb-3 block">Required Actions</Label>
            <div className="space-y-2">
              <label className="flex items-center gap-3 cursor-pointer p-2 rounded hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
                <Checkbox
                  checked={config.actions.follow}
                  onCheckedChange={(checked) =>
                    setConfig({
                      ...config,
                      actions: { ...config.actions, follow: checked === true },
                    })
                  }
                />
                <UserPlus className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Require Follow {platform === "instagram" ? "Account" : "Page"}</span>
              </label>

              <label className="flex items-center gap-3 cursor-pointer p-2 rounded hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
                <Checkbox
                  checked={config.actions.like}
                  onCheckedChange={(checked) =>
                    setConfig({
                      ...config,
                      actions: { ...config.actions, like: checked === true },
                    })
                  }
                />
                <ThumbsUp className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Require Like Post</span>
              </label>

              <label className="flex items-center gap-3 cursor-pointer p-2 rounded hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
                <Checkbox
                  checked={config.actions.comment}
                  onCheckedChange={(checked) =>
                    setConfig({
                      ...config,
                      actions: { ...config.actions, comment: checked === true },
                    })
                  }
                />
                <MessageSquare className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Require Comment on Post</span>
              </label>
            </div>
          </div>

          <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded border border-blue-200 dark:border-blue-800">
            <p className="text-xs text-blue-800 dark:text-blue-200">
              <strong>How it works:</strong> After posting, a smart unlock link will be added as a comment. When users
              click it, they must complete the required actions before accessing your destination URL.
            </p>
          </div>
        </div>
      )}
    </Card>
  )
}
