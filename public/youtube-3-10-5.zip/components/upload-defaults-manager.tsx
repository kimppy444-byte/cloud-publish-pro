"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Settings,
  Save,
  RotateCcw,
  Lock,
  Globe,
  Eye,
  User,
  Users,
  Copy,
  Check,
  Link2,
  ExternalLink,
} from "lucide-react"
import { getUploadDefaults, saveUploadDefaults, clearUploadDefaults, type UploadDefaults } from "@/lib/upload-defaults"
import { useToast } from "@/hooks/use-toast"
import { getAllStoredTokens } from "@/lib/youtube-auth"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function UploadDefaultsManager() {
  const { toast } = useToast()
  const [accounts, setAccounts] = useState<Array<{ email: string; name?: string }>>([])
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null)
  const [defaults, setDefaults] = useState<UploadDefaults>({
    description: "",
    tags: "",
    category: "22",
    privacy: "private",
    allowComments: true,
    allowRatings: true,
    socialUnlockEnabled: false,
    socialUnlockTargetUrl: "",
    socialUnlockActions: {
      subscribe: true,
      like: true,
      comment: false,
    },
  })
  const [copyFromEmail, setCopyFromEmail] = useState<string>("")

  useEffect(() => {
    const tokens = getAllStoredTokens()
    setAccounts(tokens.map((t) => ({ email: t.email, name: t.name })))
    if (tokens.length > 0) {
      setSelectedEmail(tokens[0].email)
    }
  }, [])

  useEffect(() => {
    if (selectedEmail) {
      const stored = getUploadDefaults(selectedEmail)
      if (stored) {
        setDefaults(stored)
      } else {
        setDefaults({
          description: "",
          tags: "",
          category: "22",
          privacy: "private",
          allowComments: true,
          allowRatings: true,
          socialUnlockEnabled: false,
          socialUnlockTargetUrl: "",
          socialUnlockActions: {
            subscribe: true,
            like: true,
            comment: false,
          },
        })
      }
    }
  }, [selectedEmail])

  const handleSave = () => {
    if (!selectedEmail) return
    saveUploadDefaults(defaults, selectedEmail)
    toast({
      title: "Defaults Saved",
      description: `Upload defaults saved for ${selectedEmail}`,
    })
  }

  const handleReset = () => {
    if (!selectedEmail) return
    clearUploadDefaults(selectedEmail)
    setDefaults({
      description: "",
      tags: "",
      category: "22",
      privacy: "private",
      allowComments: true,
      allowRatings: true,
      socialUnlockEnabled: false,
      socialUnlockTargetUrl: "",
      socialUnlockActions: {
        subscribe: true,
        like: true,
        comment: false,
      },
    })
    toast({
      title: "Defaults Reset",
      description: `Upload defaults cleared for ${selectedEmail}`,
    })
  }

  const handleCopyDefaults = () => {
    if (!copyFromEmail || copyFromEmail === selectedEmail) return

    const copiedDefaults = getUploadDefaults(copyFromEmail)
    if (copiedDefaults) {
      setDefaults(copiedDefaults)
      toast({
        title: "Defaults Copied",
        description: `Copied defaults from ${copyFromEmail}. Click Save to apply.`,
      })
    } else {
      toast({
        title: "No Defaults Found",
        description: `No saved defaults for ${copyFromEmail}`,
        variant: "destructive",
      })
    }
  }

  const privacyOptions = [
    { value: "public" as const, label: "Public", icon: <Globe className="w-4 h-4" /> },
    { value: "unlisted" as const, label: "Unlisted", icon: <Eye className="w-4 h-4" /> },
    { value: "private" as const, label: "Private", icon: <Lock className="w-4 h-4" /> },
  ]

  const categories = [
    { id: "1", name: "Film & Animation" },
    { id: "2", name: "Autos & Vehicles" },
    { id: "10", name: "Music" },
    { id: "15", name: "Pets & Animals" },
    { id: "17", name: "Sports" },
    { id: "20", name: "Gaming" },
    { id: "22", name: "People & Blogs" },
    { id: "23", name: "Comedy" },
    { id: "24", name: "Entertainment" },
    { id: "26", name: "Howto & Style" },
    { id: "27", name: "Education" },
    { id: "28", name: "Science & Technology" },
  ]

  if (accounts.length === 0) {
    return (
      <Card className="p-8 text-center">
        <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">No accounts connected. Please connect an account first.</p>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-2">
        <div className="flex items-center gap-3 mb-3">
          <Users className="w-5 h-5 text-primary" />
          <h3 className="font-bold">Select Account to Configure</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-3">
          Each account has its own upload defaults. Choose which account to configure:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {accounts.map((account) => {
            const hasDefaults = !!getUploadDefaults(account.email)
            return (
              <button
                key={account.email}
                onClick={() => setSelectedEmail(account.email)}
                className={`p-4 rounded-lg border-2 transition-all text-left relative ${
                  selectedEmail === account.email
                    ? "border-primary bg-primary/10 shadow-md ring-2 ring-primary/20"
                    : "border-border hover:border-primary/50 bg-background"
                }`}
              >
                {hasDefaults && (
                  <div className="absolute top-2 right-2">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                )}
                <div className="flex items-center gap-2 mb-1">
                  <User className="w-4 h-4 text-primary" />
                  <p className="font-semibold text-sm truncate">{account.name || account.email.split("@")[0]}</p>
                </div>
                <p className="text-xs text-muted-foreground truncate">{account.email}</p>
                <p className="text-xs text-muted-foreground mt-1">{hasDefaults ? "Has defaults" : "No defaults"}</p>
              </button>
            )
          })}
        </div>
      </Card>

      {accounts.length > 1 && selectedEmail && (
        <Card className="p-4 bg-muted/30 border-dashed">
          <div className="flex items-center gap-3 mb-3">
            <Copy className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-sm">Copy Defaults from Another Account</h3>
          </div>
          <div className="flex gap-2">
            <Select value={copyFromEmail} onValueChange={setCopyFromEmail}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Select account to copy from..." />
              </SelectTrigger>
              <SelectContent>
                {accounts
                  .filter((acc) => acc.email !== selectedEmail)
                  .map((acc) => (
                    <SelectItem key={acc.email} value={acc.email}>
                      {acc.name || acc.email.split("@")[0]} ({acc.email})
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <Button
              onClick={handleCopyDefaults}
              variant="outline"
              disabled={!copyFromEmail || copyFromEmail === selectedEmail}
              className="gap-2 bg-transparent"
            >
              <Copy className="w-4 h-4" />
              Copy
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Copy settings from another account as a starting point. Remember to click Save after copying.
          </p>
        </Card>
      )}

      <Card className="p-6">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Settings className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-lg">Upload Defaults</h3>
                <p className="text-sm text-muted-foreground">
                  {selectedEmail && (
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      Configuring defaults for: <span className="font-semibold">{selectedEmail}</span>
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold mb-2 block">Default Description Template</label>
              <textarea
                value={defaults.description}
                onChange={(e) => setDefaults({ ...defaults, description: e.target.value })}
                placeholder="Enter default description that will be applied to all uploads..."
                className="w-full p-3 border border-border rounded-md bg-background text-foreground"
                rows={6}
              />
              <p className="text-xs text-muted-foreground mt-1">
                This description will be automatically added to all video uploads for {selectedEmail}
              </p>
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Default Tags</label>
              <Input
                value={defaults.tags}
                onChange={(e) => setDefaults({ ...defaults, tags: e.target.value })}
                placeholder="tag1, tag2, tag3"
              />
              <p className="text-xs text-muted-foreground mt-1">Separate tags with commas</p>
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Default Category</label>
              <select
                value={defaults.category}
                onChange={(e) => setDefaults({ ...defaults, category: e.target.value })}
                className="w-full p-2 border border-border rounded-md bg-background text-foreground"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Default Privacy</label>
              <div className="grid grid-cols-3 gap-3">
                {privacyOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setDefaults({ ...defaults, privacy: option.value })}
                    className={`p-3 rounded-lg border-2 transition-all text-center ${
                      defaults.privacy === option.value
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="flex justify-center mb-1">{option.icon}</div>
                    <p className="text-sm font-semibold">{option.label}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 p-3 bg-muted/30 rounded-lg border">
              <label className="text-sm font-semibold block">Default Viewer Permissions</label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={defaults.allowComments}
                  onChange={(e) => setDefaults({ ...defaults, allowComments: e.target.checked })}
                  className="rounded w-4 h-4"
                />
                <span className="text-sm">Allow comments by default</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={defaults.allowRatings}
                  onChange={(e) => setDefaults({ ...defaults, allowRatings: e.target.checked })}
                  className="rounded w-4 h-4"
                />
                <span className="text-sm">Show like/dislike by default</span>
              </label>
            </div>

            <div className="space-y-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 rounded-lg border-2 border-purple-200 dark:border-purple-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-600 rounded-lg">
                    <Link2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Smart Links (Social Unlock)</h3>
                    <p className="text-sm text-muted-foreground">
                      Automatically add unlock links to video descriptions
                    </p>
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={defaults.socialUnlockEnabled}
                    onChange={(e) => setDefaults({ ...defaults, socialUnlockEnabled: e.target.checked })}
                    className="rounded w-5 h-5"
                  />
                  <span className="text-sm font-semibold">Enable</span>
                </label>
              </div>

              {defaults.socialUnlockEnabled && (
                <div className="space-y-4 pt-2 border-t border-purple-200 dark:border-purple-800">
                  <div>
                    <label className="text-sm font-semibold mb-2 block flex items-center gap-2">
                      <ExternalLink className="w-4 h-4" />
                      Target URL (Where users will be sent after unlock)
                    </label>
                    <Input
                      value={defaults.socialUnlockTargetUrl}
                      onChange={(e) => setDefaults({ ...defaults, socialUnlockTargetUrl: e.target.value })}
                      placeholder="https://example.com/download"
                      className="bg-background"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      This is the link users will unlock after completing the required actions
                    </p>
                  </div>

                  <div>
                    <label className="text-sm font-semibold mb-2 block">Required Actions</label>
                    <div className="space-y-2">
                      <label className="flex items-center gap-3 cursor-pointer p-2 rounded hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
                        <input
                          type="checkbox"
                          checked={defaults.socialUnlockActions?.subscribe}
                          onChange={(e) =>
                            setDefaults({
                              ...defaults,
                              socialUnlockActions: {
                                ...defaults.socialUnlockActions!,
                                subscribe: e.target.checked,
                              },
                            })
                          }
                          className="rounded w-4 h-4"
                        />
                        <span className="text-sm">Require Subscribe to Channel</span>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer p-2 rounded hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
                        <input
                          type="checkbox"
                          checked={defaults.socialUnlockActions?.like}
                          onChange={(e) =>
                            setDefaults({
                              ...defaults,
                              socialUnlockActions: {
                                ...defaults.socialUnlockActions!,
                                like: e.target.checked,
                              },
                            })
                          }
                          className="rounded w-4 h-4"
                        />
                        <span className="text-sm">Require Like Video</span>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer p-2 rounded hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
                        <input
                          type="checkbox"
                          checked={defaults.socialUnlockActions?.comment}
                          onChange={(e) =>
                            setDefaults({
                              ...defaults,
                              socialUnlockActions: {
                                ...defaults.socialUnlockActions!,
                                comment: e.target.checked,
                              },
                            })
                          }
                          className="rounded w-4 h-4"
                        />
                        <span className="text-sm">Require Comment on Video</span>
                      </label>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded border border-blue-200 dark:border-blue-800">
                    <p className="text-xs text-blue-800 dark:text-blue-200">
                      <strong>How it works:</strong> After each video upload, a smart link will be automatically added
                      to the video description. Viewers must complete the required actions to unlock access to your
                      target URL.
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-3 pt-2">
              <Button onClick={handleSave} className="flex-1 gap-2" disabled={!selectedEmail}>
                <Save className="w-4 h-4" />
                Save Defaults for {selectedEmail?.split("@")[0]}
              </Button>
              <Button
                onClick={handleReset}
                variant="outline"
                className="gap-2 bg-transparent"
                disabled={!selectedEmail}
              >
                <RotateCcw className="w-4 h-4" />
                Reset
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
