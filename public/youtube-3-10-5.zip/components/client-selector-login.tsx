"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, XCircle, RefreshCw, Copy, Check, AlertCircle } from "lucide-react"
import {
  getAllClients,
  getActiveClient,
  setActiveClient,
  isClientQuotaExceeded,
  clearQuotaExceeded,
  type ClientConfig,
} from "@/lib/client-manager"

export function ClientSelectorLogin() {
  const [clients, setClients] = useState<ClientConfig[]>([])
  const [selectedClient, setSelectedClient] = useState<ClientConfig | null>(null)
  const [quotaExceeded, setQuotaExceeded] = useState<string[]>([])
  const [showRedirectInfo, setShowRedirectInfo] = useState(false)
  const [copiedRedirect, setCopiedRedirect] = useState(false)
  const [redirectUri, setRedirectUri] = useState("")

  useEffect(() => {
    const allClients = getAllClients()
    const activeClient = getActiveClient()
    const exceeded = allClients.map((c) => c.id).filter((id) => isClientQuotaExceeded(id))

    setClients(allClients)
    setSelectedClient(activeClient)
    setQuotaExceeded(exceeded)

    if (typeof window !== "undefined") {
      setRedirectUri(window.location.origin)
    }
  }, [])

  const handleSelectClient = (client: ClientConfig) => {
    setSelectedClient(client)
    setActiveClient(client.id)
  }

  const handleResetQuotas = () => {
    clearQuotaExceeded()
    setQuotaExceeded([])
  }

  const handleCopyRedirect = async () => {
    try {
      await navigator.clipboard.writeText(redirectUri)
      setCopiedRedirect(true)
      setTimeout(() => setCopiedRedirect(false), 2000)
    } catch (err) {
      console.error("[v0] Failed to copy:", err)
    }
  }

  const availableCount = clients.filter((c) => !quotaExceeded.includes(c.id)).length
  const exceededCount = quotaExceeded.length

  if (clients.length <= 1) {
    return null
  }

  return (
    <Card className="p-6 bg-card border-2">
      <div className="space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold mb-1">Select API Client</h3>
            <p className="text-sm text-muted-foreground">Choose which Google Client ID to use for authentication</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowRedirectInfo(!showRedirectInfo)}
              className="gap-2"
            >
              <AlertCircle className="w-4 h-4" />
              Setup Help
            </Button>
            <Button variant="outline" size="sm" onClick={handleResetQuotas} className="gap-2 bg-transparent">
              <RefreshCw className="w-4 h-4" />
              Reset Quotas
            </Button>
          </div>
        </div>

        {showRedirectInfo && (
          <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg space-y-3">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-sm text-blue-900 mb-2">Configure OAuth Redirect URI</p>
                <p className="text-sm text-blue-800 mb-3">
                  Each Google Client ID must have this exact redirect URI configured in Google Cloud Console:
                </p>
                <div className="flex items-center gap-2 p-3 bg-white border border-blue-200 rounded font-mono text-sm">
                  <code className="flex-1">{redirectUri}</code>
                  <Button size="sm" variant="ghost" onClick={handleCopyRedirect} className="gap-2">
                    {copiedRedirect ? (
                      <>
                        <Check className="w-4 h-4" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
                <ol className="text-sm text-blue-800 mt-3 space-y-1 list-decimal list-inside">
                  <li>Go to Google Cloud Console → APIs & Services → Credentials</li>
                  <li>Click on your OAuth 2.0 Client ID</li>
                  <li>Under "Authorized redirect URIs", add the URI above</li>
                  <li>Click "Save" and wait a few minutes for changes to take effect</li>
                </ol>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
            <CheckCircle2 className="w-5 h-5 text-green-600" />
            <div>
              <p className="text-sm font-medium">Available</p>
              <p className="text-2xl font-bold text-green-600">{availableCount}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <XCircle className="w-5 h-5 text-red-600" />
            <div>
              <p className="text-sm font-medium">Quota Exceeded</p>
              <p className="text-2xl font-bold text-red-600">{exceededCount}</p>
            </div>
          </div>
        </div>

        <div className="space-y-2 max-h-80 overflow-y-auto">
          {clients.map((client) => {
            const isExceeded = quotaExceeded.includes(client.id)
            const isSelected = selectedClient?.id === client.id

            return (
              <button
                key={client.id}
                onClick={() => !isExceeded && handleSelectClient(client)}
                disabled={isExceeded}
                className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                  isSelected
                    ? "border-primary bg-primary/5"
                    : isExceeded
                      ? "border-red-200 bg-red-50 opacity-50 cursor-not-allowed"
                      : "border-border hover:border-primary/50 hover:bg-accent"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="font-semibold text-sm">{client.label}</p>
                      {isSelected && (
                        <Badge variant="default" className="text-xs">
                          Selected
                        </Badge>
                      )}
                      {isExceeded && (
                        <Badge variant="destructive" className="text-xs">
                          Quota Exceeded
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs font-mono text-muted-foreground break-all blur-sm select-none">
                      {client.clientId}
                    </p>
                  </div>
                  {isSelected && !isExceeded && <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />}
                  {isExceeded && <XCircle className="w-5 h-5 text-red-500 flex-shrink-0" />}
                </div>
              </button>
            )
          })}
        </div>

        {exceededCount > 0 && (
          <div className="flex items-start gap-2 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
            <XCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-yellow-900">Quota Information</p>
              <p className="text-yellow-800 mt-1">
                YouTube API quotas reset at midnight Pacific Time. You can manually reset the quota tracking above if
                needed.
              </p>
            </div>
          </div>
        )}
      </div>
    </Card>
  )
}
