"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { AlertCircle, Plus, Trash2, LogIn, Loader2, Mail, ExternalLink } from "lucide-react"
import { getAllStoredTokens, removeAccount, initiateOAuthFlow, type MultiAccountToken } from "@/lib/youtube-auth"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export function AccountManager() {
  const [accounts, setAccounts] = useState<MultiAccountToken[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadAccounts()
    const interval = setInterval(loadAccounts, 2000)
    return () => clearInterval(interval)
  }, [])

  const loadAccounts = () => {
    const stored = getAllStoredTokens()
    setAccounts(stored)
    setIsLoading(false)
  }

  const handleAddAccount = () => {
    setIsLoading(true)
    initiateOAuthFlow()
  }

  const handleRemoveAccount = (email: string) => {
    removeAccount(email)
    setAccounts(accounts.filter((a) => a.email !== email))
  }

  if (isLoading && accounts.length === 0) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-lg">Connected Accounts</h3>
          <p className="text-sm text-muted-foreground">
            {accounts.length} account{accounts.length !== 1 ? "s" : ""} connected
          </p>
        </div>
        <Button onClick={handleAddAccount} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Account
        </Button>
      </div>

      {accounts.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No Accounts Connected</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Connect your YouTube accounts to start managing your channels, uploading videos, and tracking analytics.
          </p>
          <Button onClick={handleAddAccount} className="gap-2">
            <LogIn className="w-4 h-4" />
            Sign In with YouTube
          </Button>
        </Card>
      ) : (
        <div className="grid gap-4">
          {accounts.map((account) => (
            <Card key={account.email} className="p-6">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4 min-w-0">
                  <Avatar className="h-14 w-14 shrink-0">
                    <AvatarImage src={account.picture || "/placeholder.svg"} />
                    <AvatarFallback className="bg-primary/10 text-primary text-lg">
                      {account.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <h4 className="font-semibold text-lg">{account.name}</h4>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Mail className="w-4 h-4 shrink-0" />
                      <span className="truncate">{account.email}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button variant="outline" size="sm" className="gap-2 bg-transparent" asChild>
                    <a href={`https://studio.youtube.com`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4" />
                      Studio
                    </a>
                  </Button>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="gap-2 text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Remove Account</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to remove {account.name || account.email}? You can always add it back
                          later.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleRemoveAccount(account.email)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Remove
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Info Card */}
      <Card className="p-4 bg-muted/50">
        <p className="text-sm text-muted-foreground">
          <strong>Tip:</strong> Add multiple accounts to upload videos to different channels or manage multiple YouTube
          brands from one dashboard.
        </p>
      </Card>
    </div>
  )
}
