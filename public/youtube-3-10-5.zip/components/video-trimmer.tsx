"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Scissors, Play, Pause, RotateCcw } from "lucide-react"

interface VideoTrimmerProps {
  videoFile: File
  onTrimComplete: (trimmedFile: File) => void
}

export function VideoTrimmer({ videoFile, onTrimComplete }: VideoTrimmerProps) {
  const [startTime, setStartTime] = useState(0)
  const [endTime, setEndTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isTrimming, setIsTrimming] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [videoUrl, setVideoUrl] = useState<string>("")

  useEffect(() => {
    const url = URL.createObjectURL(videoFile)
    setVideoUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [videoFile])

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const videoDuration = videoRef.current.duration
      setDuration(videoDuration)
      setEndTime(videoDuration)
    }
  }

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const time = videoRef.current.currentTime
      setCurrentTime(time)

      if (time >= endTime) {
        videoRef.current.pause()
        setIsPlaying(false)
        videoRef.current.currentTime = startTime
      }
    }
  }

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.currentTime = startTime
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleReset = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0
      videoRef.current.pause()
      setIsPlaying(false)
      setStartTime(0)
      setEndTime(duration)
      setCurrentTime(0)
    }
  }

  const handleTrim = async () => {
    if (!videoFile) return

    setIsTrimming(true)

    try {
      // For browser-based trimming, we'll use ffmpeg.wasm
      const { createFFmpeg, fetchFile } = await import("@ffmpeg/ffmpeg")

      const ffmpeg = createFFmpeg({ log: true })
      await ffmpeg.load()

      ffmpeg.FS("writeFile", "input.mp4", await fetchFile(videoFile))

      await ffmpeg.run(
        "-i",
        "input.mp4",
        "-ss",
        startTime.toString(),
        "-to",
        endTime.toString(),
        "-c",
        "copy",
        "output.mp4",
      )

      const data = ffmpeg.FS("readFile", "output.mp4")
      const trimmedBlob = new Blob([data.buffer], { type: "video/mp4" })
      const trimmedFile = new File([trimmedBlob], `trimmed_${videoFile.name}`, { type: "video/mp4" })

      onTrimComplete(trimmedFile)
    } catch (error) {
      console.error("[v0] Error trimming video:", error)
      alert("Failed to trim video. This feature requires ffmpeg.wasm support.")
    } finally {
      setIsTrimming(false)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <Card className="p-6 space-y-4">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-orange-600 rounded-lg">
          <Scissors className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="font-bold text-xl">Video Trimmer</h3>
          <p className="text-sm text-muted-foreground">Cut your video to any length</p>
        </div>
      </div>

      <div className="space-y-4">
        <video
          ref={videoRef}
          src={videoUrl}
          className="w-full aspect-video bg-black rounded-lg"
          onLoadedMetadata={handleLoadedMetadata}
          onTimeUpdate={handleTimeUpdate}
        />

        <div className="flex items-center gap-3">
          <Button onClick={togglePlayPause} variant="outline" size="sm">
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          <Button onClick={handleReset} variant="outline" size="sm">
            <RotateCcw className="w-4 h-4" />
          </Button>
          <div className="flex-1 text-sm text-muted-foreground text-center">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-semibold mb-2 block">Start Time: {formatTime(startTime)}</label>
            <input
              type="range"
              min="0"
              max={duration}
              step="0.1"
              value={startTime}
              onChange={(e) => setStartTime(Number.parseFloat(e.target.value))}
              className="w-full"
            />
          </div>

          <div>
            <label className="text-sm font-semibold mb-2 block">End Time: {formatTime(endTime)}</label>
            <input
              type="range"
              min="0"
              max={duration}
              step="0.1"
              value={endTime}
              onChange={(e) => setEndTime(Number.parseFloat(e.target.value))}
              className="w-full"
            />
          </div>

          <div className="p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
            <p className="text-sm font-semibold mb-1">Trimmed Duration</p>
            <p className="text-2xl font-bold">{formatTime(endTime - startTime)}</p>
            {endTime - startTime <= 60 && (
              <p className="text-xs text-purple-600 dark:text-purple-400 mt-2 font-semibold">
                ✨ This will qualify as a YouTube Short!
              </p>
            )}
          </div>
        </div>

        <Button onClick={handleTrim} disabled={isTrimming || startTime >= endTime} className="w-full gap-2" size="lg">
          {isTrimming ? (
            <>
              <Scissors className="w-4 h-4 animate-spin" />
              Trimming Video...
            </>
          ) : (
            <>
              <Scissors className="w-4 h-4" />
              Trim Video
            </>
          )}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          Note: Video trimming requires ffmpeg.wasm. For production use, consider server-side processing.
        </p>
      </div>
    </Card>
  )
}
