"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ChannelSelector } from "@/components/channel-selector"
import { VideoEditor } from "@/components/video-editor"
import { getAllStoredTokens, fetchAllChannels } from "@/lib/youtube-auth"
import { getUploadDefaults } from "@/lib/upload-defaults"
import { generateSmartLink, generateSmartLinkText } from "@/lib/smart-link"
import { toast } from "@/hooks/use-toast"
import {
  Upload,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Trash2,
  Lock,
  Globe,
  Eye,
  Settings2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Film,
  Tag,
  FolderOpen,
  Shield,
  Scissors,
  ImageIcon,
} from "lucide-react"
import { QuotaSwitchDialog } from "@/components/quota-switch-dialog"
import { markClientQuotaExceeded, getActiveClient } from "@/lib/client-manager"
import { MultiAccountVideoConfigurator } from "@/components/multi-account-video-configurator"

export type { VideoUploadItem }

type UploadMode = "same" | "different"
type PrivacyStatus = "public" | "private" | "unlisted"

// Define UploadDefaults interface for clarity, assuming it's defined elsewhere or inferred
interface UploadDefaults {
  privacy: PrivacyStatus
  category: string
  allowComments: boolean
  allowRatings: boolean
  description: string
  tags: string
  socialUnlockEnabled?: boolean
  socialUnlockTargetUrl?: string
  socialUnlockActions?: { subscribe: boolean; like: boolean; comment: boolean }
}

interface VideoUploadItem {
  id: string
  file: File | null
  title: string
  description: string
  channels: string[]
  tags: string
  category: string
  privacy: PrivacyStatus
  allowComments: boolean
  allowRatings: boolean
  thumbnail: File | null
  thumbnailPreview: string | null
  scheduled: boolean
  scheduleTime: string
  expandedSettings: boolean
  previewUrl: string | null
  duration: number | null
  isShort: boolean
  showEditor: boolean
  dualUpload: boolean
  customShortsDuration: number
}

export function BulkUploader() {
  const [uploadMode, setUploadMode] = useState<UploadMode>("same")
  const [selectedChannels, setSelectedChannels] = useState<string[]>([])
  const [videos, setVideos] = useState<VideoUploadItem[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({})
  const [uploadStatus, setUploadStatus] = useState<{
    [key: string]: "pending" | "uploading" | "success" | "error"
  }>({})
  const [statusMessages, setStatusMessages] = useState<{ [key: string]: string }>({})

  const [globalPrivacy, setGlobalPrivacy] = useState<PrivacyStatus>("private")
  const [globalCategory, setGlobalCategory] = useState("22")
  const [globalAllowComments, setGlobalAllowComments] = useState(true)
  const [globalAllowRatings, setGlobalAllowRatings] = useState(true)

  const [accessTokens, setAccessTokens] = useState<{ [email: string]: string }>({})
  const [channelEmailMap, setChannelEmailMap] = useState<{ [channelId: string]: string }>({})
  const [showQuotaDialog, setShowQuotaDialog] = useState(false)

  const [currentUserEmail, setCurrentUserEmail] = useState<string | null>(null)
  const [allAccountDefaults, setAllAccountDefaults] = useState<{ [email: string]: UploadDefaults }>({})

  const [showMultiAccountConfig, setShowMultiAccountConfig] = useState(false)
  const [pendingVideoFile, setPendingVideoFile] = useState<File | null>(null)

  useEffect(() => {
    const tokens = getAllStoredTokens()
    const tokenMap = tokens.reduce(
      (acc, token) => {
        acc[token.email] = token.access_token
        return acc
      },
      {} as { [email: string]: string },
    )
    setAccessTokens(tokenMap)
    if (tokens.length > 0) {
      setCurrentUserEmail(tokens[0].email)
    }

    const defaultsMap: { [email: string]: UploadDefaults } = {}
    tokens.forEach((token) => {
      const defaults = getUploadDefaults(token.email)
      if (defaults) {
        defaultsMap[token.email] = defaults
      }
    })
    setAllAccountDefaults(defaultsMap)
  }, [])

  useEffect(() => {
    const buildChannelMap = async () => {
      const tokens = getAllStoredTokens()
      const map: { [channelId: string]: string } = {}

      for (const token of tokens) {
        try {
          const channels = await fetchAllChannels(token.access_token)
          channels.forEach((ch: any) => {
            map[ch.id] = token.email
          })
        } catch (err) {
          console.error(`Failed to build channel map for ${token.email}:`, err)
        }
      }

      setChannelEmailMap(map)
    }

    buildChannelMap()
  }, [])

  useEffect(() => {
    const defaults = getUploadDefaults(currentUserEmail || undefined)
    if (defaults) {
      console.log("[v0] Loaded upload defaults for bulk uploader:", currentUserEmail, defaults)
      setGlobalPrivacy(defaults.privacy)
      setGlobalCategory(defaults.category)
      setGlobalAllowComments(defaults.allowComments)
      setGlobalAllowRatings(defaults.allowRatings)
    }
  }, [currentUserEmail])

  const categories = [
    { id: "1", name: "Film & Animation" },
    { id: "2", name: "Autos & Vehicles" },
    { id: "10", name: "Music" },
    { id: "15", name: "Pets & Animals" },
    { id: "17", name: "Sports" },
    { id: "18", name: "Short Movies" },
    { id: "19", name: "Travel & Events" },
    { id: "20", name: "Gaming" },
    { id: "21", name: "Videoblogging" },
    { id: "22", name: "People & Blogs" },
    { id: "23", name: "Comedy" },
    { id: "24", name: "Entertainment" },
    { id: "25", name: "News & Politics" },
    { id: "26", name: "Howto & Style" },
    { id: "27", name: "Education" },
    { id: "28", name: "Science & Technology" },
    { id: "29", name: "Nonprofits & Activism" },
  ]

  const privacyOptions = [
    {
      value: "public" as PrivacyStatus,
      label: "Public",
      icon: <Globe className="w-4 h-4" />,
      description: "Everyone can find and watch",
    },
    {
      value: "unlisted" as PrivacyStatus,
      label: "Unlisted",
      icon: <Eye className="w-4 h-4" />,
      description: "Only with the link",
    },
    {
      value: "private" as PrivacyStatus,
      label: "Private",
      icon: <Lock className="w-4 h-4" />,
      description: "Only you",
    },
  ]

  const addVideo = () => {
    if (uploadMode === "same" && selectedChannels.length > 1) {
      const accountEmails = new Set(selectedChannels.map((ch) => channelEmailMap[ch]).filter(Boolean))
      if (accountEmails.size > 1) {
        // Check if all accounts have the same description
        const uniqueDescriptions = new Set(
          Array.from(accountEmails).map((email) => {
            const defaults = getUploadDefaults(email)
            return defaults?.description || ""
          }),
        )

        // Only show configurator if descriptions differ
        if (uniqueDescriptions.size > 1) {
          setPendingVideoFile(null)
          setShowMultiAccountConfig(true)
          return
        }
      }
    }

    // Original logic for single account or "different" mode or same descriptions
    let accountEmail = currentUserEmail

    if (uploadMode === "same" && selectedChannels.length > 0) {
      accountEmail = channelEmailMap[selectedChannels[0]] || currentUserEmail
    }

    const defaults = getUploadDefaults(accountEmail || undefined)
    console.log("[v0] Adding video with defaults for account:", accountEmail, defaults)

    const newVideo: VideoUploadItem = {
      id: `video-${Date.now()}`,
      file: null,
      title: "",
      description: defaults?.description || "",
      channels: uploadMode === "same" ? selectedChannels : [],
      tags: defaults?.tags || "",
      category: defaults?.category || globalCategory,
      privacy: defaults?.privacy || globalPrivacy,
      allowComments: defaults?.allowComments ?? globalAllowComments,
      allowRatings: defaults?.allowRatings ?? globalAllowRatings,
      thumbnail: null,
      thumbnailPreview: null,
      scheduled: false,
      scheduleTime: "",
      expandedSettings: false,
      previewUrl: null,
      duration: null,
      isShort: false,
      showEditor: false,
      dualUpload: false,
      customShortsDuration: 60,
    }
    setVideos([...videos, newVideo])
  }

  const removeVideo = (id: string) => {
    setVideos(videos.filter((v) => v.id !== id))
  }

  const updateVideo = (id: string, updates: Partial<VideoUploadItem>) => {
    if (updates.channels && updates.channels.length > 0) {
      const firstChannelEmail = channelEmailMap[updates.channels[0]]
      console.log("[v0] Channel selected:", updates.channels[0], "Account:", firstChannelEmail)

      if (firstChannelEmail) {
        const accountDefaults = getUploadDefaults(firstChannelEmail)
        console.log("[v0] Loading defaults for account:", firstChannelEmail, accountDefaults)

        if (accountDefaults) {
          // Always apply account defaults when channels change
          updates.description = accountDefaults.description
          updates.tags = accountDefaults.tags
          updates.category = accountDefaults.category
          updates.privacy = accountDefaults.privacy
          updates.allowComments = accountDefaults.allowComments
          updates.allowRatings = accountDefaults.allowRatings
        }
      }
    }

    setVideos(videos.map((v) => (v.id === id ? { ...v, ...updates } : v)))
  }

  const applyGlobalSettings = () => {
    setVideos(
      videos.map((v) => ({
        ...v,
        privacy: globalPrivacy,
        category: globalCategory,
        allowComments: globalAllowComments,
        allowRatings: globalAllowRatings,
      })),
    )
  }

  const cleanFilenameToTitle = (filename: string): string => {
    // Remove file extension
    const nameWithoutExt = filename.replace(/\.[^/.]+$/, "")
    // Replace underscores and dashes with spaces
    const cleaned = nameWithoutExt.replace(/[_-]/g, " ")
    // Capitalize first letter of each word
    return cleaned
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  const handleFileChange = (id: string, file: File | null) => {
    if (file && file.size > 128 * 1024 * 1024) {
      setStatusMessages({ ...statusMessages, [id]: "File size must be less than 128 MB" })
      return
    }

    // Auto-populate title from filename if title is empty
    const currentVideo = videos.find((v) => v.id === id)
    const updates: Partial<VideoUploadItem> = { file }

    if (file && (!currentVideo?.title || currentVideo.title === "")) {
      updates.title = cleanFilenameToTitle(file.name)
    }

    // Create video preview URL
    updates.previewUrl = file ? URL.createObjectURL(file) : null
    updates.showEditor = false

    updateVideo(id, updates)
  }

  const handleThumbnailChange = (id: string, file: File | null) => {
    if (file && file.size > 2 * 1024 * 1024) {
      setStatusMessages({ ...statusMessages, [id]: "Thumbnail must be less than 2 MB" })
      return
    }
    const thumbnailPreview = file ? URL.createObjectURL(file) : null
    updateVideo(id, { thumbnail: file, thumbnailPreview })
  }

  const handleEditComplete = (id: string, editedFile: File) => {
    updateVideo(id, {
      file: editedFile,
      showEditor: false,
      previewUrl: URL.createObjectURL(editedFile),
    })
  }

  const videoInEditor = videos.find((v) => v.showEditor && v.file)
  if (videoInEditor) {
    return (
      <VideoEditor
        videoFile={videoInEditor.file!}
        onEditComplete={(editedFile) => handleEditComplete(videoInEditor.id, editedFile)}
        onCancel={() => updateVideo(videoInEditor.id, { showEditor: false })}
      />
    )
  }

  const handleMultiAccountConfirm = (configurations: { [email: string]: Partial<VideoUploadItem> }) => {
    const newVideos: VideoUploadItem[] = []

    Object.entries(configurations).forEach(([email, config]) => {
      const newVideo: VideoUploadItem = {
        id: `video-${Date.now()}-${email}`,
        file: pendingVideoFile,
        title: config.title || "",
        description: config.description || "",
        channels: config.channels || [],
        tags: config.tags || "",
        category: config.category || globalCategory,
        privacy: config.privacy || globalPrivacy,
        allowComments: config.allowComments ?? globalAllowComments,
        allowRatings: config.allowRatings ?? globalAllowComments,
        thumbnail: null,
        thumbnailPreview: null,
        scheduled: false,
        scheduleTime: "",
        expandedSettings: false,
        previewUrl: pendingVideoFile ? URL.createObjectURL(pendingVideoFile) : null,
        duration: null,
        isShort: false,
        showEditor: false,
        dualUpload: false,
        customShortsDuration: 60,
      }
      newVideos.push(newVideo)
    })

    setVideos([...videos, ...newVideos])
    setPendingVideoFile(null)
  }

  const uploadToChannels = async (
    video: VideoUploadItem,
    videoFile: File,
    videoTitle: string,
    videoDescription: string,
    videoTags: string,
    asShort: boolean,
    targetChannels: string[],
  ) => {
    const parsedTags = videoTags
      .split(",")
      .map((tag) => tag.trim())
      .filter((tag) => tag.length > 0)
      .slice(0, 30)

    const finalTags = asShort
      ? [...parsedTags, "Shorts", "Short"].filter((tag, index, self) => self.indexOf(tag) === index)
      : parsedTags

    const finalTitle = asShort && !videoTitle.includes("#Shorts") ? `${videoTitle} #Shorts` : videoTitle

    const finalDescription =
      asShort && !videoDescription.includes("#Shorts") ? `${videoDescription}\n\n#Shorts` : videoDescription

    for (let channelIndex = 0; channelIndex < targetChannels.length; channelIndex++) {
      const channelId = targetChannels[channelIndex]

      const accountEmail = channelEmailMap[channelId]
      const accessToken = accountEmail ? accessTokens[accountEmail] : Object.values(accessTokens)[0]

      if (!accessToken) {
        throw new Error(`No valid access token found for channel ${channelId}`)
      }

      console.log("[v0] Uploading to channel", channelId, "for account", accountEmail)

      const videoMetadata = {
        snippet: {
          title: finalTitle.substring(0, 100),
          description: finalDescription.substring(0, 5000),
          tags: finalTags.length > 0 ? finalTags : undefined,
          categoryId: video.category,
        },
        status: {
          privacyStatus: video.privacy,
          selfDeclaredMadeForKids: false,
          embeddable: true,
          publicStatsViewable: true,
        },
      }

      if (asShort) {
        console.log(`[v0] Uploading video ${video.id} as YouTube Short - Added #Shorts to title and description`)
      }

      const initResponse = await fetch(
        "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json; charset=UTF-8",
            "X-Upload-Content-Length": videoFile.size.toString(),
            "X-Upload-Content-Type": videoFile.type || "video/mp4",
          },
          body: JSON.stringify(videoMetadata),
        },
      )

      if (!initResponse.ok) {
        const errorText = await initResponse.text()
        if (initResponse.status === 403 || errorText.includes("quotaExceeded")) {
          const activeClient = getActiveClient()
          if (activeClient) {
            markClientQuotaExceeded(activeClient.id)
          }
          setShowQuotaDialog(true)
        }
        throw new Error(`Failed to initialize upload: ${initResponse.status}`)
      }

      const sessionUri = initResponse.headers.get("location")
      if (!sessionUri) {
        throw new Error("No session URI provided")
      }

      const uploadResponse = await fetch(sessionUri, {
        method: "PUT",
        headers: {
          "Content-Type": videoFile.type || "video/mp4",
        },
        body: videoFile,
      })

      if (!uploadResponse.ok) {
        const errorText = await uploadResponse.text()
        if (uploadResponse.status === 403 || errorText.includes("quotaExceeded")) {
          const activeClient = getActiveClient()
          if (activeClient) {
            markClientQuotaExceeded(activeClient.id)
          }
          setShowQuotaDialog(true)
        }
        throw new Error(`Upload failed: ${uploadResponse.status}`)
      }

      const result = await uploadResponse.json()

      const defaults = getUploadDefaults(accountEmail || undefined)
      if (defaults?.socialUnlockEnabled && defaults.socialUnlockTargetUrl && result.id) {
        try {
          const smartLink = await generateSmartLink({
            videoId: result.id,
            channelId,
            targetUrl: defaults.socialUnlockTargetUrl,
            actions: defaults.socialUnlockActions || { subscribe: true, like: true, comment: false },
          })

          const smartLinkText = generateSmartLinkText(smartLink)
          const updatedDescription = finalDescription + smartLinkText

          const updateResponse = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet`, {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${accessToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              id: result.id,
              snippet: {
                ...result.snippet,
                title: finalTitle,
                description: updatedDescription.substring(0, 5000),
                categoryId: video.category,
              },
            }),
          })

          if (updateResponse.ok) {
            console.log("[v0] Smart link added to video description for channel:", channelId)
          }
        } catch (error) {
          console.error("[v0] Failed to add smart link:", error)
        }
      }

      if (video.thumbnail && result.id) {
        console.log(`[v0] Uploading thumbnail for video ${video.id}:`, result.id)

        try {
          const thumbnailResponse = await fetch(
            `https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=${result.id}`,
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": video.thumbnail.type,
              },
              body: video.thumbnail,
            },
          )

          if (thumbnailResponse.ok) {
            const thumbResult = await thumbnailResponse.json()
            console.log(`[v0] Thumbnail uploaded successfully for video ${result.id}:`, thumbResult)
          } else {
            const errorText = await thumbnailResponse.text()
            console.error(`[v0] Thumbnail upload failed for video ${result.id}:`, thumbnailResponse.status, errorText)

            if (thumbnailResponse.status === 403) {
              toast({
                title: "Thumbnail Failed - Missing Permission",
                description: `Thumbnail upload failed for: ${video.title}. Click Re-auth at the top.`,
                variant: "destructive",
              })
            }
          }
        } catch (error) {
          console.error(`[v0] Thumbnail upload error for video ${video.id}:`, error)
        }
      }

      const progress = Math.round(((channelIndex + 1) / targetChannels.length) * 100)
      setUploadProgress((prev) => ({ ...prev, [video.id]: progress }))
    }
  }

  const uploadSingleVideo = async (video: VideoUploadItem) => {
    if (!video.file || !video.title) return false

    const targetChannels = uploadMode === "same" ? selectedChannels : video.channels
    if (targetChannels.length === 0) return false

    try {
      setUploadStatus((prev) => ({ ...prev, [video.id]: "uploading" }))

      if (video.dualUpload && video.duration !== null && video.duration > 60) {
        setStatusMessages({
          ...statusMessages,
          [video.id]: "Creating Shorts version...",
        })

        // Create shorts version
        const { FFmpeg } = await import("@ffmpeg/ffmpeg")
        const { toBlobURL } = await import("@ffmpeg/util")

        const ffmpeg = new FFmpeg()
        await ffmpeg.load({
          coreURL: await toBlobURL("https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js", "text/javascript"),
          wasmURL: await toBlobURL(
            "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm",
            "application/wasm",
          ),
        })

        await ffmpeg.writeFile("input.mp4", new Uint8Array(await video.file.arrayBuffer()))

        const shortsDuration = video.customShortsDuration
        await ffmpeg.exec([
          "-i",
          "input.mp4",
          "-ss",
          "0",
          "-to",
          shortsDuration.toString(),
          "-vf",
          "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2",
          "-c:v",
          "libx264",
          "-preset",
          "veryfast",
          "-crf",
          "28",
          "-c:a",
          "aac",
          "-b:a",
          "128k",
          "output.mp4",
        ])

        const shortsData = await ffmpeg.readFile("output.mp4")
        const shortsBlob = new Blob([shortsData], { type: "video/mp4" })
        const shortsFile = new File([shortsBlob], `shorts_${video.file.name}`, { type: "video/mp4" })

        // Upload full version
        setStatusMessages({
          ...statusMessages,
          [video.id]: "Uploading full video...",
        })
        await uploadToChannels(video, video.file, video.title, video.description, video.tags, false, targetChannels)

        // Upload shorts version
        setStatusMessages({
          ...statusMessages,
          [video.id]: "Uploading Shorts version...",
        })
        await uploadToChannels(
          video,
          shortsFile,
          `${video.title} #Shorts`,
          `${video.description}\n\n#Shorts`,
          `${video.tags},Shorts,Short`,
          true,
          targetChannels,
        )

        setUploadStatus((prev) => ({ ...prev, [video.id]: "success" }))
        setStatusMessages({
          ...statusMessages,
          [video.id]: `Both full video and Short uploaded to ${targetChannels.length} channel(s)`,
        })
        return true
      } else {
        // Regular upload
        const isShortUpload = video.isShort && video.duration !== null && video.duration <= 60
        await uploadToChannels(
          video,
          video.file,
          video.title,
          video.description,
          video.tags,
          isShortUpload,
          targetChannels,
        )

        setUploadStatus((prev) => ({ ...prev, [video.id]: "success" }))
        setStatusMessages({
          ...statusMessages,
          [video.id]: `Successfully uploaded to ${targetChannels.length} channel(s)`,
        })
        return true
      }
    } catch (error) {
      setUploadStatus((prev) => ({ ...prev, [video.id]: "error" }))
      setStatusMessages({
        ...statusMessages,
        [video.id]: error instanceof Error ? error.message : "Upload failed",
      })
      return false
    }
  }

  const handleBulkUpload = async () => {
    setIsUploading(true)

    for (const video of videos) {
      if (video.file && video.title) {
        await uploadSingleVideo(video)
        await new Promise((resolve) => setTimeout(resolve, 500))
      }
    }

    setIsUploading(false)
  }

  return (
    <div className="space-y-6">
      <MultiAccountVideoConfigurator
        open={showMultiAccountConfig}
        onClose={() => {
          setShowMultiAccountConfig(false)
          setPendingVideoFile(null)
        }}
        videoFile={pendingVideoFile}
        videoTitle={cleanFilenameToTitle(pendingVideoFile?.name || "")}
        selectedChannels={selectedChannels}
        channelEmailMap={channelEmailMap}
        onConfirm={handleMultiAccountConfirm}
        categories={categories}
      />

      <QuotaSwitchDialog
        open={showQuotaDialog}
        onClose={() => setShowQuotaDialog(false)}
        onSwitch={() => {
          toast({
            title: "Client Switched",
            description: "Now using new API client. Try uploading again.",
          })
        }}
      />
      <Card className="p-6">
        <h3 className="font-semibold mb-4">Upload Mode</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={() => setUploadMode("same")}
            className={`p-4 rounded-lg border-2 transition-all text-left ${
              uploadMode === "same" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
            }`}
          >
            <p className="font-semibold mb-1">Same Video, Multiple Channels</p>
            <p className="text-sm text-muted-foreground">
              Upload one video to multiple channels across all your accounts
            </p>
          </button>
          <button
            onClick={() => setUploadMode("different")}
            className={`p-4 rounded-lg border-2 transition-all text-left ${
              uploadMode === "different" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
            }`}
          >
            <p className="font-semibold mb-1">Different Videos, Different Channels</p>
            <p className="text-sm text-muted-foreground">
              Upload multiple videos to specific channels from any account
            </p>
          </button>
        </div>
      </Card>

      {uploadMode === "same" && (
        <Card className="p-6">
          <ChannelSelector selectedChannels={selectedChannels} onChannelsChange={setSelectedChannels} />
        </Card>
      )}

      {/* Added account defaults preview section */}
      {Object.keys(allAccountDefaults).length > 0 && (
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-2">
          <div className="flex items-center gap-2 mb-4">
            <Eye className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold">Account Default Descriptions Preview</h3>
          </div>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {Object.entries(allAccountDefaults).map(([email, defaults]) => (
              <div key={email} className="p-3 bg-white dark:bg-gray-900 rounded-lg border shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-blue-600 dark:text-blue-400">{email}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="px-2 py-0.5 bg-muted rounded-full capitalize">{defaults.privacy}</span>
                    <span className="px-2 py-0.5 bg-muted rounded-full">
                      {categories.find((c) => c.id === defaults.category)?.name || "Unknown"}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2 break-words">
                  {defaults.description || "No description set"}
                </p>
                {defaults.tags && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {defaults.tags
                      .split(",")
                      .slice(0, 3)
                      .map((tag, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs rounded-full"
                        >
                          {tag.trim()}
                        </span>
                      ))}
                    {defaults.tags.split(",").length > 3 && (
                      <span className="px-2 py-0.5 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs rounded-full">
                        +{defaults.tags.split(",").length - 3}
                      </span>
                    )}
                  </div>
                )}
                {defaults.socialUnlockEnabled && (
                  <div className="flex items-center gap-1 mt-2">
                    <Sparkles className="w-3 h-3 text-purple-600 dark:text-purple-400" />
                    <span className="text-xs font-semibold text-purple-700 dark:text-purple-300">
                      Smart Link Enabled
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card className="p-6 bg-muted/30 border-dashed">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold flex items-center gap-2">
              <Settings2 className="w-4 h-4" />
              Default Settings (Apply to All Videos)
            </h3>
            <Button onClick={applyGlobalSettings} variant="outline" size="sm">
              Apply to All
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold mb-2 block">Default Privacy</label>
              <div className="grid grid-cols-3 gap-2">
                {privacyOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setGlobalPrivacy(option.value)}
                    className={`p-2 rounded-lg border-2 transition-all text-center text-xs ${
                      globalPrivacy === option.value
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="flex justify-center mb-1">{option.icon}</div>
                    <p className="font-semibold">{option.label}</p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Default Category</label>
              <select
                value={globalCategory}
                onChange={(e) => setGlobalCategory(e.target.value)}
                className="w-full p-2 border border-border rounded-md bg-background text-foreground text-sm"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={globalAllowComments}
                onChange={(e) => setGlobalAllowComments(e.target.checked)}
                className="rounded w-4 h-4"
              />
              <span className="text-sm">Allow comments by default</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={globalAllowRatings}
                onChange={(e) => setGlobalAllowRatings(e.target.checked)}
                className="rounded w-4 h-4"
              />
              <span className="text-sm">Show like/dislike by default</span>
            </label>
          </div>
        </div>
      </Card>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Videos to Upload</h3>
          <Button onClick={addVideo} variant="outline" size="sm" disabled={isUploading}>
            Add Video
          </Button>
        </div>

        {videos.length === 0 ? (
          <Card className="p-8 text-center">
            <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No videos added yet. Click "Add Video" to get started.</p>
          </Card>
        ) : (
          videos.map((video) => (
            <Card key={video.id} className="p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="font-semibold text-sm">{video.title || "Untitled Video"}</p>
                  <p className="text-xs text-muted-foreground">{video.file?.name || "No file selected"}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    onClick={() => updateVideo(video.id, { expandedSettings: !video.expandedSettings })}
                    variant="ghost"
                    size="sm"
                    className="text-muted-foreground"
                  >
                    {video.expandedSettings ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                  <Button
                    onClick={() => removeVideo(video.id)}
                    variant="ghost"
                    size="sm"
                    disabled={isUploading}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-2 block">Video File</label>
                  <div
                    className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary/50 transition-colors cursor-pointer"
                    onClick={() => document.getElementById(`file-input-${video.id}`)?.click()}
                  >
                    <p className="text-sm">{video.file?.name || "Click to select file"}</p>
                    <input
                      id={`file-input-${video.id}`}
                      type="file"
                      accept="video/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0] || null
                        if (uploadMode === "same" && selectedChannels.length > 1 && file) {
                          const accountEmails = new Set(
                            selectedChannels.map((ch) => channelEmailMap[ch]).filter(Boolean),
                          )
                          if (accountEmails.size > 1) {
                            // Check if descriptions differ
                            const uniqueDescriptions = new Set(
                              Array.from(accountEmails).map((email) => {
                                const defaults = getUploadDefaults(email)
                                return defaults?.description || ""
                              }),
                            )

                            if (uniqueDescriptions.size > 1) {
                              setPendingVideoFile(file)
                              setShowMultiAccountConfig(true)
                              return
                            }
                          }
                        }
                        handleFileChange(video.id, file)
                      }}
                      className="hidden"
                      disabled={isUploading}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold mb-2 block">Thumbnail (Optional)</label>
                  {video.thumbnailPreview ? (
                    <div className="space-y-2">
                      <div className="relative border-2 border-border rounded-lg overflow-hidden aspect-video">
                        <img
                          src={video.thumbnailPreview || "/placeholder.svg"}
                          alt="Thumbnail preview"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <Button
                            onClick={() => {
                              if (video.thumbnailPreview) {
                                URL.revokeObjectURL(video.thumbnailPreview)
                              }
                              updateVideo(video.id, { thumbnail: null, thumbnailPreview: null })
                            }}
                            variant="destructive"
                            size="sm"
                            className="h-7 w-7 p-0"
                            disabled={isUploading}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                      <Button
                        onClick={() => document.getElementById(`thumb-input-${video.id}`)?.click()}
                        variant="outline"
                        size="sm"
                        className="w-full gap-2"
                        disabled={isUploading}
                      >
                        <ImageIcon className="w-4 h-4" />
                        Change Thumbnail
                      </Button>
                    </div>
                  ) : (
                    <div
                      className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary/50 transition-colors cursor-pointer aspect-video flex items-center justify-center"
                      onClick={() => document.getElementById(`thumb-input-${video.id}`)?.click()}
                    >
                      <div>
                        <ImageIcon className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-sm">{video.thumbnail?.name || "Click to select thumbnail"}</p>
                      </div>
                    </div>
                  )}
                  <input
                    id={`thumb-input-${video.id}`}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleThumbnailChange(video.id, e.target.files?.[0] || null)}
                    className="hidden"
                    disabled={isUploading}
                  />
                </div>
              </div>

              {video.file && (
                <>
                  <Card className="overflow-hidden border-2">
                    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 p-6 border-b">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-600 rounded-lg">
                            <Film className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h3 className="font-bold text-lg">Video Preview</h3>
                            <p className="text-xs text-muted-foreground">Review how your video will appear</p>
                          </div>
                        </div>
                        <Button
                          onClick={() => updateVideo(video.id, { showEditor: true })}
                          variant="outline"
                          size="sm"
                          className="gap-2"
                          disabled={isUploading}
                        >
                          <Scissors className="w-4 h-4" />
                          Edit Video
                        </Button>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        {/* Video Player Section */}
                        <div className="space-y-3">
                          <video
                            src={video.previewUrl || undefined}
                            controls
                            className="w-full aspect-video bg-black rounded-lg shadow-lg"
                            onLoadedMetadata={(e) => {
                              const videoEl = e.currentTarget
                              const duration = videoEl.duration
                              const updates: Partial<VideoUploadItem> = { duration }

                              const aspectRatio = videoEl.videoWidth / videoEl.videoHeight
                              console.log(
                                "[v0] Video dimensions:",
                                videoEl.videoWidth,
                                "x",
                                videoEl.videoHeight,
                                "aspect ratio:",
                                aspectRatio.toFixed(2),
                              )

                              if (duration <= 60 && aspectRatio < 1) {
                                updates.isShort = true
                                console.log("[v0] Video qualifies as Short: vertical aspect ratio and ≤60 seconds")
                              } else if (duration <= 60) {
                                console.log(
                                  "[v0] Video is ≤60 seconds but NOT vertical (aspect ratio:",
                                  aspectRatio.toFixed(2),
                                  "). May not display as Short.",
                                )
                              }

                              updateVideo(video.id, updates)
                            }}
                          >
                            Your browser does not support the video tag.
                          </video>
                          {video.duration !== null && (
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 px-3 py-1.5 bg-white dark:bg-gray-900 rounded-full border shadow-sm">
                                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                                <span className="text-sm font-semibold">{Math.round(video.duration)}s</span>
                              </div>
                              {video.duration <= 60 && (
                                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full shadow-md text-xs font-bold">
                                  <Sparkles className="w-3.5 h-3.5" />
                                  Shorts Eligible
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Video Metadata Section */}
                        <div className="space-y-4">
                          <div className="bg-white dark:bg-gray-900 rounded-lg p-4 shadow-sm border">
                            <div className="flex items-start gap-3 mb-3">
                              <div className="p-1.5 bg-blue-100 dark:bg-blue-900 rounded">
                                <Film className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs text-muted-foreground mb-1">Title</p>
                                <p className="font-semibold text-sm leading-snug break-words">
                                  {video.title || "No title set"}
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="bg-white dark:bg-gray-900 rounded-lg p-4 shadow-sm border">
                            <div className="flex items-start gap-3 mb-3">
                              <div className="p-1.5 bg-green-100 dark:bg-green-900 rounded">
                                <Tag className="w-4 h-4 text-green-600 dark:text-green-400" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs text-muted-foreground mb-1">Description</p>
                                <p className="text-sm text-muted-foreground leading-relaxed break-words line-clamp-3">
                                  {video.description || "No description"}
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div className="bg-white dark:bg-gray-900 rounded-lg p-3 shadow-sm border">
                              <div className="flex items-center gap-2 mb-2">
                                <div className="p-1 bg-purple-100 dark:bg-purple-900 rounded">
                                  <FolderOpen className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                                </div>
                                <p className="text-xs text-muted-foreground">Category</p>
                              </div>
                              <p className="text-sm font-semibold">
                                {categories.find((cat) => cat.id === video.category)?.name || "Unknown"}
                              </p>
                            </div>

                            <div className="bg-white dark:bg-gray-900 rounded-lg p-3 shadow-sm border">
                              <div className="flex items-center gap-2 mb-2">
                                <div className="p-1 bg-amber-100 dark:bg-amber-900 rounded">
                                  <Shield className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                                </div>
                                <p className="text-xs text-muted-foreground">Privacy</p>
                              </div>
                              <div className="flex items-center gap-1.5">
                                {video.privacy === "public" && <Globe className="w-3.5 h-3.5" />}
                                {video.privacy === "unlisted" && <Eye className="w-3.5 h-3.5" />}
                                {video.privacy === "private" && <Lock className="w-3.5 h-3.5" />}
                                <p className="text-sm font-semibold capitalize">{video.privacy}</p>
                              </div>
                            </div>
                          </div>

                          {video.tags && (
                            <div className="bg-white dark:bg-gray-900 rounded-lg p-3 shadow-sm border">
                              <p className="text-xs text-muted-foreground mb-2">Tags</p>
                              <div className="flex flex-wrap gap-1.5">
                                {video.tags
                                  .split(",")
                                  .slice(0, 5)
                                  .map((tag, index) => (
                                    <span
                                      key={index}
                                      className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs rounded-full"
                                    >
                                      {tag.trim()}
                                    </span>
                                  ))}
                                {video.tags.split(",").length > 5 && (
                                  <span className="px-2 py-0.5 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs rounded-full">
                                    +{video.tags.split(",").length - 5} more
                                  </span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                </>
              )}

              <div>
                <label className="text-sm font-semibold mb-2 block">Title</label>
                <Input
                  value={video.title}
                  onChange={(e) => updateVideo(video.id, { title: e.target.value })}
                  placeholder="Video title"
                  disabled={isUploading}
                />
              </div>

              <div>
                <label className="text-sm font-semibold mb-2 block">Description (Optional)</label>
                <textarea
                  value={video.description}
                  onChange={(e) => updateVideo(video.id, { description: e.target.value })}
                  placeholder="Video description"
                  className="w-full p-3 border border-border rounded-md bg-background text-foreground disabled:opacity-50"
                  rows={2}
                  disabled={isUploading}
                />
              </div>

              <div>
                <label className="text-sm font-semibold mb-2 block">Tags (Optional)</label>
                <Input
                  value={video.tags}
                  onChange={(e) => updateVideo(video.id, { tags: e.target.value })}
                  placeholder="Separate by commas (e.g. vlog, travel, music)"
                  disabled={isUploading}
                />
                <p className="text-xs text-muted-foreground mt-1">Maximum 30 tags</p>
              </div>

              {uploadMode === "different" && (
                <div>
                  <label className="text-sm font-semibold mb-2 block">Select Channels</label>
                  <ChannelSelector
                    selectedChannels={video.channels}
                    onChannelsChange={(channels) => updateVideo(video.id, { channels })}
                  />
                </div>
              )}

              {video.expandedSettings && (
                <div className="space-y-4 pt-4 border-t">
                  <div>
                    <label className="text-sm font-semibold mb-3 block">Privacy Settings</label>
                    <div className="grid grid-cols-3 gap-3">
                      {privacyOptions.map((option) => (
                        <button
                          key={option.value}
                          onClick={() => updateVideo(video.id, { privacy: option.value })}
                          disabled={isUploading}
                          className={`p-3 rounded-lg border-2 transition-all text-left text-sm ${
                            video.privacy === option.value
                              ? "border-primary bg-primary/10"
                              : "border-border hover:border-primary/50"
                          } disabled:opacity-50`}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            {option.icon}
                            <span className="font-semibold">{option.label}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">{option.description}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-semibold mb-2 block">Category</label>
                    <select
                      value={video.category}
                      onChange={(e) => updateVideo(video.id, { category: e.target.value })}
                      disabled={isUploading}
                      className="w-full p-3 border border-border rounded-md bg-background text-foreground disabled:opacity-50"
                    >
                      {categories.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2 p-3 bg-muted/30 rounded-lg border border-border">
                    <label className="text-sm font-semibold block">Viewer Permissions</label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={video.allowComments}
                        onChange={(e) => updateVideo(video.id, { allowComments: e.target.checked })}
                        disabled={isUploading}
                        className="rounded w-4 h-4"
                      />
                      <span className="text-sm">Allow comments</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={video.allowRatings}
                        onChange={(e) => updateVideo(video.id, { allowRatings: e.target.checked })}
                        disabled={isUploading}
                        className="rounded w-4 h-4"
                      />
                      <span className="text-sm">Show like/dislike</span>
                    </label>
                  </div>

                  <div>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={video.scheduled}
                        onChange={(e) => updateVideo(video.id, { scheduled: e.target.checked })}
                        disabled={isUploading}
                        className="rounded w-4 h-4"
                      />
                      <span className="text-sm">Schedule for later</span>
                    </label>
                    {video.scheduled && (
                      <Input
                        type="datetime-local"
                        value={video.scheduleTime}
                        onChange={(e) => updateVideo(video.id, { scheduleTime: e.target.value })}
                        className="mt-2"
                        disabled={isUploading}
                      />
                    )}
                  </div>
                </div>
              )}

              {video.duration !== null && video.duration <= 60 && (
                <div className="p-4 bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800 rounded-lg">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={video.isShort}
                      onChange={(e) => updateVideo(video.id, { isShort: e.target.checked })}
                      disabled={isUploading}
                      className="rounded w-4 h-4 mt-0.5"
                    />
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                        <span className="text-sm font-semibold">Upload as YouTube Short</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        This video is {Math.round(video.duration)} seconds long and can be uploaded as a Short. Shorts
                        appear in the Shorts feed and get more discovery.
                      </p>
                    </div>
                  </label>
                </div>
              )}

              {video.duration !== null && video.duration > 60 && (
                <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-2 border-purple-200 dark:border-purple-800 rounded-lg space-y-4">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={video.dualUpload}
                      onChange={(e) => updateVideo(video.id, { dualUpload: e.target.checked })}
                      disabled={isUploading}
                      className="rounded w-4 h-4 mt-0.5"
                    />
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                        <span className="text-sm font-semibold">Upload to Both Video & Shorts</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Upload the full {Math.round(video.duration)}s video AND automatically create a vertical Shorts
                        version. Get double the reach!
                      </p>
                    </div>
                  </label>

                  {video.dualUpload && (
                    <div className="pl-7 space-y-3">
                      <div className="p-3 bg-white dark:bg-gray-900 rounded-lg border border-purple-200 dark:border-purple-800">
                        <label className="text-xs font-semibold mb-2 block text-purple-900 dark:text-purple-100">
                          Shorts Video Length (seconds)
                        </label>
                        <div className="flex items-center gap-3">
                          <input
                            type="range"
                            min="58"
                            max="60"
                            step="1"
                            value={video.customShortsDuration}
                            onChange={(e) => updateVideo(video.id, { customShortsDuration: Number(e.target.value) })}
                            disabled={isUploading}
                            className="flex-1"
                          />
                          <div className="flex items-center gap-1 px-3 py-1.5 bg-purple-100 dark:bg-purple-900 rounded-full border border-purple-300 dark:border-purple-700">
                            <span className="text-sm font-bold text-purple-700 dark:text-purple-300">
                              {video.customShortsDuration}s
                            </span>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          Choose how long your Short will be. Recommended: 58-60 seconds for maximum engagement.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {uploadStatus[video.id] === "uploading" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold">Uploading...</p>
                    <p className="text-sm text-muted-foreground">{uploadProgress[video.id] || 0}%</p>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all"
                      style={{ width: `${uploadProgress[video.id] || 0}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {uploadStatus[video.id] === "success" && (
                <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0" />
                  <p className="text-sm text-green-800 dark:text-red-200">{statusMessages[video.id]}</p>
                </div>
              )}

              {uploadStatus[video.id] === "error" && (
                <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
                  <p className="text-sm text-red-800 dark:text-red-200">{statusMessages[video.id]}</p>
                </div>
              )}
            </Card>
          ))
        )}
      </div>

      <Button
        onClick={handleBulkUpload}
        disabled={
          isUploading ||
          videos.length === 0 ||
          videos.every((v) => !v.file || !v.title) ||
          selectedChannels.length === 0
        }
        className="w-full gap-2"
        size="lg"
      >
        {isUploading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Uploading {videos.filter((v) => uploadStatus[v.id] === "success").length} of {videos.length}
          </>
        ) : (
          <>
            <Upload className="w-4 h-4" />
            Start Bulk Upload
          </>
        )}
      </Button>
    </div>
  )
}
