"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { getUploadDefaults } from "@/lib/upload-defaults"
import { X, Check, Film, User, Globe, Lock, Eye } from 'lucide-react'
import type { VideoUploadItem } from "./bulk-uploader"

type PrivacyStatus = "public" | "private" | "unlisted"

interface UploadDefaults {
  privacy: PrivacyStatus
  category: string
  allowComments: boolean
  allowRatings: boolean
  description: string
  tags: string
}

interface MultiAccountVideoConfiguratorProps {
  open: boolean
  onClose: () => void
  videoFile: File | null
  videoTitle: string
  selectedChannels: string[]
  channelEmailMap: { [channelId: string]: string }
  onConfirm: (configurations: { [email: string]: Partial<VideoUploadItem> }) => void
  categories: { id: string; name: string }[]
}

export function MultiAccountVideoConfigurator({
  open,
  onClose,
  videoFile,
  videoTitle,
  selectedChannels,
  channelEmailMap,
  onConfirm,
  categories,
}: MultiAccountVideoConfiguratorProps) {
  const [accountConfigs, setAccountConfigs] = useState<{ [email: string]: Partial<VideoUploadItem> }>({})

  useEffect(() => {
    if (open && selectedChannels.length > 0) {
      // Group channels by account email
      const accountsMap: { [email: string]: string[] } = {}
      selectedChannels.forEach((channelId) => {
        const email = channelEmailMap[channelId]
        if (email) {
          if (!accountsMap[email]) {
            accountsMap[email] = []
          }
          accountsMap[email].push(channelId)
        }
      })

      // Initialize configs for each account
      const configs: { [email: string]: Partial<VideoUploadItem> } = {}
      Object.keys(accountsMap).forEach((email) => {
        const defaults = getUploadDefaults(email)
        configs[email] = {
          title: videoFile?.name || videoTitle,
          description: defaults?.description || "",
          tags: defaults?.tags || "",
          category: defaults?.category || "22",
          privacy: defaults?.privacy || "private",
          allowComments: defaults?.allowComments ?? true,
          allowRatings: defaults?.allowRatings ?? true,
          channels: accountsMap[email],
        }
      })
      setAccountConfigs(configs)
    }
  }, [open, selectedChannels, channelEmailMap, videoTitle, videoFile])

  if (!open) return null

  const accountEmails = Object.keys(accountConfigs)

  const privacyIcons = {
    public: <Globe className="w-4 h-4" />,
    private: <Lock className="w-4 h-4" />,
    unlisted: <Eye className="w-4 h-4" />,
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-6 border-b bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Configure Video for Each Account</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Customize title, description, and settings for each of your {accountEmails.length} accounts
              </p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {accountEmails.map((email) => {
              const config = accountConfigs[email]
              return (
                <Card key={email} className="p-5 border-2 hover:border-primary/50 transition-colors">
                  <div className="flex items-center gap-3 mb-4 pb-3 border-b">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-full">
                      <User className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{email}</p>
                      <p className="text-xs text-muted-foreground">
                        {config.channels?.length || 0} channel(s)
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="text-xs font-semibold mb-1.5 block">Title</label>
                      <Input
                        value={config.title || ""}
                        onChange={(e) =>
                          setAccountConfigs({
                            ...accountConfigs,
                            [email]: { ...config, title: e.target.value },
                          })
                        }
                        placeholder="Video title"
                        className="text-sm"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold mb-1.5 block">Description</label>
                      <textarea
                        value={config.description || ""}
                        onChange={(e) =>
                          setAccountConfigs({
                            ...accountConfigs,
                            [email]: { ...config, description: e.target.value },
                          })
                        }
                        placeholder="Video description"
                        className="w-full p-2 border border-border rounded-md bg-background text-sm resize-none"
                        rows={3}
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold mb-1.5 block">Tags</label>
                      <Input
                        value={config.tags || ""}
                        onChange={(e) =>
                          setAccountConfigs({
                            ...accountConfigs,
                            [email]: { ...config, tags: e.target.value },
                          })
                        }
                        placeholder="tag1, tag2, tag3"
                        className="text-sm"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold mb-1.5 block">Category</label>
                      <select
                        value={config.category || "22"}
                        onChange={(e) =>
                          setAccountConfigs({
                            ...accountConfigs,
                            [email]: { ...config, category: e.target.value },
                          })
                        }
                        className="w-full p-2 border border-border rounded-md bg-background text-sm"
                      >
                        {categories.map((cat) => (
                          <option key={cat.id} value={cat.id}>
                            {cat.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-semibold mb-1.5 block">Privacy</label>
                      <div className="grid grid-cols-3 gap-2">
                        {(["public", "unlisted", "private"] as PrivacyStatus[]).map((privacy) => (
                          <button
                            key={privacy}
                            onClick={() =>
                              setAccountConfigs({
                                ...accountConfigs,
                                [email]: { ...config, privacy },
                              })
                            }
                            className={`p-2 rounded-lg border-2 transition-all text-xs ${
                              config.privacy === privacy
                                ? "border-primary bg-primary/10"
                                : "border-border hover:border-primary/50"
                            }`}
                          >
                            <div className="flex justify-center mb-1">{privacyIcons[privacy]}</div>
                            <p className="font-semibold capitalize">{privacy}</p>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2 pt-2">
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input
                          type="checkbox"
                          checked={config.allowComments ?? true}
                          onChange={(e) =>
                            setAccountConfigs({
                              ...accountConfigs,
                              [email]: { ...config, allowComments: e.target.checked },
                            })
                          }
                          className="rounded w-3.5 h-3.5"
                        />
                        <span>Allow comments</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer text-xs">
                        <input
                          type="checkbox"
                          checked={config.allowRatings ?? true}
                          onChange={(e) =>
                            setAccountConfigs({
                              ...accountConfigs,
                              [email]: { ...config, allowRatings: e.target.checked },
                            })
                          }
                          className="rounded w-3.5 h-3.5"
                        />
                        <span>Show like/dislike</span>
                      </label>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>

        <div className="p-6 border-t bg-muted/30 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Film className="w-4 h-4" />
            <span>
              {videoFile?.name || "No file"} • {accountEmails.length} account(s)
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                onConfirm(accountConfigs)
                onClose()
              }}
              className="gap-2"
            >
              <Check className="w-4 h-4" />
              Confirm & Add Video
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
