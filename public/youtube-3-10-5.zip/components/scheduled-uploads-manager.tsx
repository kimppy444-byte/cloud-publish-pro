"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, Trash2, Calendar, Video, Globe, Lock, Eye, Play } from 'lucide-react'
import { toast } from "@/hooks/use-toast"

interface ScheduledUpload {
  id: string
  title: string
  scheduledTime: string
  privacy: string
  channels: number
  thumbnail?: string
}

export function ScheduledUploadsManager() {
  const [scheduledUploads, setScheduledUploads] = useState<ScheduledUpload[]>([])

  useEffect(() => {
    const stored = localStorage.getItem("scheduledUploads")
    if (stored) {
      setScheduledUploads(JSON.parse(stored))
    }
  }, [])

  const deleteScheduled = (id: string) => {
    const updated = scheduledUploads.filter((u) => u.id !== id)
    setScheduledUploads(updated)
    localStorage.setItem("scheduledUploads", JSON.stringify(updated))
    toast({
      title: "Scheduled Upload Removed",
      description: "The scheduled upload has been deleted.",
    })
  }

  const executeNow = (id: string) => {
    toast({
      title: "Uploading Now",
      description: "Starting immediate upload...",
    })
    // In real implementation, this would trigger the actual upload
  }

  if (scheduledUploads.length === 0) {
    return (
      <Card className="p-8 text-center">
        <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
        <h3 className="font-semibold mb-2">No Scheduled Uploads</h3>
        <p className="text-sm text-muted-foreground">
          Schedule videos in the bulk uploader to see them here
        </p>
      </Card>
    )
  }

  const privacyIcons = {
    public: <Globe className="w-4 h-4" />,
    private: <Lock className="w-4 h-4" />,
    unlisted: <Eye className="w-4 h-4" />,
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-lg">Scheduled Uploads</h3>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-100 dark:bg-blue-900 rounded-full">
          <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <span className="text-sm font-semibold">{scheduledUploads.length} pending</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {scheduledUploads.map((upload) => (
          <Card key={upload.id} className="p-4 hover:border-primary/50 transition-colors">
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Video className="w-4 h-4 text-primary flex-shrink-0" />
                    <h4 className="font-semibold text-sm truncate">{upload.title}</h4>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {privacyIcons[upload.privacy as keyof typeof privacyIcons]}
                    <span className="capitalize">{upload.privacy}</span>
                    <span>•</span>
                    <span>{upload.channels} channel(s)</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-lg">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs font-medium">
                  {new Date(upload.scheduledTime).toLocaleString()}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  onClick={() => executeNow(upload.id)}
                  variant="outline"
                  size="sm"
                  className="flex-1 gap-2"
                >
                  <Play className="w-3.5 h-3.5" />
                  Upload Now
                </Button>
                <Button
                  onClick={() => deleteScheduled(upload.id)}
                  variant="ghost"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
