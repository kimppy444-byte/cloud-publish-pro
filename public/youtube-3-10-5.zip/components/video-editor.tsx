"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Scissors, Play, Pause, RotateCcw, Crop, Download } from "lucide-react"
import { FFmpeg } from "@ffmpeg/ffmpeg"
import { toBlobURL } from "@ffmpeg/util"

interface VideoEditorProps {
  videoFile: File
  onEditComplete: (editedFile: File) => void
  onCancel?: () => void
}

export function VideoEditor({ videoFile, onEditComplete, onCancel }: VideoEditorProps) {
  const [startTime, setStartTime] = useState(0)
  const [endTime, setEndTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [videoWidth, setVideoWidth] = useState(0)
  const [videoHeight, setVideoHeight] = useState(0)
  const [aspectRatio, setAspectRatio] = useState<"original" | "9:16" | "16:9" | "1:1">("original")
  const [ffmpegLoaded, setFfmpegLoaded] = useState(false)
  const [loadError, setLoadError] = useState<string>("")
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const ffmpegRef = useRef<FFmpeg | null>(null)
  const [videoUrl, setVideoUrl] = useState<string>("")

  useEffect(() => {
    const url = URL.createObjectURL(videoFile)
    setVideoUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [videoFile])

  useEffect(() => {
    loadFFmpeg()
  }, [])

  const loadFFmpeg = async () => {
    try {
      const ffmpeg = new FFmpeg()
      ffmpegRef.current = ffmpeg

      ffmpeg.on("log", ({ message }) => {
        console.log("[v0] FFmpeg:", message)
      })

      const baseURL = "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd"
      await ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, "text/javascript"),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, "application/wasm"),
      })

      setFfmpegLoaded(true)
      console.log("[v0] FFmpeg loaded successfully")
    } catch (error) {
      console.error("[v0] Error loading FFmpeg:", error)
      setLoadError("FFmpeg failed to load. Video editing may not work in this browser.")
    }
  }

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const videoDuration = videoRef.current.duration
      setDuration(videoDuration)
      setEndTime(videoDuration)
      setVideoWidth(videoRef.current.videoWidth)
      setVideoHeight(videoRef.current.videoHeight)
    }
  }

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const time = videoRef.current.currentTime
      setCurrentTime(time)

      if (time >= endTime) {
        videoRef.current.pause()
        setIsPlaying(false)
        videoRef.current.currentTime = startTime
      }
    }
  }

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.currentTime = startTime
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleReset = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0
      videoRef.current.pause()
      setIsPlaying(false)
      setStartTime(0)
      setEndTime(duration)
      setCurrentTime(0)
      setAspectRatio("original")
    }
  }

  const handleProcess = async () => {
    if (!videoFile || !ffmpegRef.current || !ffmpegLoaded) {
      alert("FFmpeg is not loaded yet. Please wait a moment and try again.")
      return
    }

    setIsProcessing(true)

    try {
      const ffmpeg = ffmpegRef.current

      await ffmpeg.writeFile("input.mp4", new Uint8Array(await videoFile.arrayBuffer()))

      const filterCommands = []

      if (aspectRatio !== "original") {
        let targetWidth, targetHeight

        if (aspectRatio === "9:16") {
          targetWidth = 1080
          targetHeight = 1920
        } else if (aspectRatio === "16:9") {
          targetWidth = 1920
          targetHeight = 1080
        } else if (aspectRatio === "1:1") {
          targetWidth = 1080
          targetHeight = 1080
        }

        filterCommands.push(
          `scale=${targetWidth}:${targetHeight}:force_original_aspect_ratio=decrease,pad=${targetWidth}:${targetHeight}:(ow-iw)/2:(oh-ih)/2`,
        )
      }

      const args = ["-i", "input.mp4", "-ss", startTime.toString(), "-to", endTime.toString()]

      if (filterCommands.length > 0) {
        args.push("-vf", filterCommands.join(","))
      }

      args.push("-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-c:a", "aac", "-b:a", "128k", "output.mp4")

      await ffmpeg.exec(args)

      const data = await ffmpeg.readFile("output.mp4")
      const editedBlob = new Blob([data], { type: "video/mp4" })
      const editedFile = new File([editedBlob], `edited_${videoFile.name}`, { type: "video/mp4" })

      onEditComplete(editedFile)
    } catch (error) {
      console.error("[v0] Error processing video:", error)
      alert("Failed to process video. Please try with a smaller video or different settings.")
    } finally {
      setIsProcessing(false)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const trimmedDuration = endTime - startTime
  const isShortQualified =
    trimmedDuration <= 60 && (aspectRatio === "9:16" || (aspectRatio === "original" && videoWidth < videoHeight))

  return (
    <Card className="p-6 space-y-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-600 rounded-lg">
            <Scissors className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-xl">Video Editor</h3>
            <p className="text-sm text-muted-foreground">Trim length and change aspect ratio</p>
          </div>
        </div>
        {onCancel && (
          <Button onClick={onCancel} variant="outline" size="sm">
            Cancel
          </Button>
        )}
      </div>

      {!ffmpegLoaded && !loadError && (
        <div className="p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg text-center">
          <p className="text-sm font-semibold mb-2">Loading Video Editor...</p>
          <div className="w-full bg-blue-200 dark:bg-blue-900 rounded-full h-2">
            <div className="bg-blue-600 h-2 rounded-full animate-pulse w-3/4"></div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Initializing FFmpeg in your browser</p>
        </div>
      )}

      {loadError && (
        <div className="p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
          <p className="text-sm font-semibold text-red-600 dark:text-red-400 mb-1">Error Loading Editor</p>
          <p className="text-xs text-muted-foreground">{loadError}</p>
        </div>
      )}

      <div className="space-y-4">
        <video
          ref={videoRef}
          src={videoUrl}
          className="w-full aspect-video bg-black rounded-lg"
          onLoadedMetadata={handleLoadedMetadata}
          onTimeUpdate={handleTimeUpdate}
        />

        <div className="flex items-center gap-3">
          <Button onClick={togglePlayPause} variant="outline" size="sm">
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          <Button onClick={handleReset} variant="outline" size="sm">
            <RotateCcw className="w-4 h-4" />
          </Button>
          <div className="flex-1 text-sm text-muted-foreground text-center">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
        </div>

        <div className="space-y-4 p-4 bg-muted/30 rounded-lg border">
          <div>
            <label className="text-sm font-semibold mb-2 flex items-center gap-2">
              <Scissors className="w-4 h-4" />
              Trim Video Length
            </label>
            <div className="space-y-3 mt-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Start Time: {formatTime(startTime)}</label>
                <input
                  type="range"
                  min="0"
                  max={duration}
                  step="0.1"
                  value={startTime}
                  onChange={(e) => setStartTime(Number.parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1 block">End Time: {formatTime(endTime)}</label>
                <input
                  type="range"
                  min="0"
                  max={duration}
                  step="0.1"
                  value={endTime}
                  onChange={(e) => setEndTime(Number.parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>
          </div>

          <div className="pt-3 border-t">
            <label className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Crop className="w-4 h-4" />
              Change Aspect Ratio
            </label>
            <div className="grid grid-cols-4 gap-2">
              <button
                onClick={() => setAspectRatio("original")}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  aspectRatio === "original" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                }`}
              >
                <div className="text-xs font-semibold mb-1">Original</div>
                <div className="text-xs text-muted-foreground">
                  {videoWidth}x{videoHeight}
                </div>
              </button>
              <button
                onClick={() => setAspectRatio("9:16")}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  aspectRatio === "9:16" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                }`}
              >
                <div className="text-xs font-semibold mb-1">9:16</div>
                <div className="text-xs text-muted-foreground">Vertical</div>
              </button>
              <button
                onClick={() => setAspectRatio("16:9")}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  aspectRatio === "16:9" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                }`}
              >
                <div className="text-xs font-semibold mb-1">16:9</div>
                <div className="text-xs text-muted-foreground">Wide</div>
              </button>
              <button
                onClick={() => setAspectRatio("1:1")}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  aspectRatio === "1:1" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                }`}
              >
                <div className="text-xs font-semibold mb-1">1:1</div>
                <div className="text-xs text-muted-foreground">Square</div>
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Convert to 9:16 vertical format for YouTube Shorts</p>
          </div>
        </div>

        <div className="p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg space-y-2">
          <p className="text-sm font-semibold mb-1">Preview Changes</p>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-muted-foreground text-xs">Duration</p>
              <p className="font-bold">{formatTime(trimmedDuration)}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-xs">Aspect Ratio</p>
              <p className="font-bold">{aspectRatio === "original" ? `${videoWidth}x${videoHeight}` : aspectRatio}</p>
            </div>
          </div>
          {isShortQualified && (
            <div className="pt-2 border-t border-blue-200 dark:border-blue-800">
              <p className="text-xs text-purple-600 dark:text-purple-400 font-semibold flex items-center gap-1">
                <span className="text-base">✨</span> This will qualify as a YouTube Short!
              </p>
            </div>
          )}
        </div>

        <Button
          onClick={handleProcess}
          disabled={isProcessing || startTime >= endTime || !ffmpegLoaded}
          className="w-full gap-2"
          size="lg"
        >
          {isProcessing ? (
            <>
              <Scissors className="w-4 h-4 animate-spin" />
              Processing Video...
            </>
          ) : !ffmpegLoaded ? (
            <>
              <Scissors className="w-4 h-4" />
              Loading Editor...
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              Apply Changes
            </>
          )}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          Video processing uses FFmpeg in your browser. First use may take a moment to load.
        </p>
      </div>

      <canvas ref={canvasRef} className="hidden" />
    </Card>
  )
}
