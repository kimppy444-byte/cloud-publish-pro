"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast"
import { Video, Eye, ThumbsUp, MessageCircle, Pencil, Trash2, ExternalLink, RefreshCw, Globe, Lock, Users, Image, Languages, CheckSquare } from 'lucide-react'
import { Checkbox } from "@/components/ui/checkbox"

interface VideoData {
  id: string
  title: string
  description: string
  thumbnail: string
  publishedAt: string
  viewCount: string
  likeCount: string
  commentCount: string
  privacyStatus: string
}

interface MyVideosManagerProps {
  accessToken: string
}

const getCacheKey = (accessToken: string) => {
  const tokenHash = btoa(accessToken.substring(0, 20))
  return `youtube_videos_${tokenHash}`
}

const getCacheTimestampKey = (accessToken: string) => {
  const tokenHash = btoa(accessToken.substring(0, 20))
  return `youtube_videos_timestamp_${tokenHash}`
}

export function MyVideosManager({ accessToken }: MyVideosManagerProps) {
  const [videos, setVideos] = useState<VideoData[]>([])
  const [filteredVideos, setFilteredVideos] = useState<VideoData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [editingVideo, setEditingVideo] = useState<VideoData | null>(null)
  const [deleteVideoId, setDeleteVideoId] = useState<string | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null)
  const { toast } = useToast()

  const [searchQuery, setSearchQuery] = useState("")
  const [selectedVideos, setSelectedVideos] = useState<Set<string>>(new Set())
  const [isMultiSelectMode, setIsMultiSelectMode] = useState(false)
  const [isBatchDeleting, setIsBatchDeleting] = useState(false)

  // Edit form state
  const [editTitle, setEditTitle] = useState("")
  const [editDescription, setEditDescription] = useState("")
  const [editPrivacy, setEditPrivacy] = useState("")
  const [editThumbnail, setEditThumbnail] = useState<File | null>(null)
  const [editThumbnailPreview, setEditThumbnailPreview] = useState<string | null>(null)
  const [isTranslating, setIsTranslating] = useState(false)

  const fetchMyVideos = async (forceRefresh = false) => {
    setIsLoading(true)
    try {
      const cacheKey = getCacheKey(accessToken)
      const timestampKey = getCacheTimestampKey(accessToken)

      // Check cache first if not forcing refresh
      if (!forceRefresh) {
        const cachedData = localStorage.getItem(cacheKey)
        const cachedTimestamp = localStorage.getItem(timestampKey)

        if (cachedData && cachedTimestamp) {
          const cacheAge = Date.now() - Number.parseInt(cachedTimestamp)
          // Use cache if less than 5 minutes old
          if (cacheAge < 5 * 60 * 1000) {
            const parsedData = JSON.parse(cachedData)
            setVideos(parsedData)
            setFilteredVideos(parsedData)
            setLastRefresh(new Date(Number.parseInt(cachedTimestamp)))
            setIsLoading(false)
            return
          }
        }
      }

      // Fetch fresh data from API
      const response = await fetch(`/api/youtube/my-videos?access_token=${accessToken}`)
      const data = await response.json()

      const videosData = data.videos || []
      setVideos(videosData)
      setFilteredVideos(videosData)

      localStorage.setItem(cacheKey, JSON.JSON.stringify(videosData))
      const timestamp = Date.now().toString()
      localStorage.setItem(timestampKey, timestamp)
      setLastRefresh(new Date(Number.parseInt(timestamp)))

      if (forceRefresh) {
        toast({
          title: "Refreshed",
          description: "Videos updated successfully",
        })
      }
    } catch (error) {
      console.error("Error fetching videos:", error)
      toast({
        title: "Error",
        description: "Failed to load your videos",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (accessToken) {
      fetchMyVideos()
    }
  }, [accessToken])

  useEffect(() => {
    let filtered = videos

    if (searchQuery) {
      filtered = filtered.filter(
        (v) =>
          v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    setFilteredVideos(filtered)
  }, [videos, searchQuery])

  const formatNumber = (num: string) => {
    const n = Number.parseInt(num)
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`
    return n.toString()
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
  }

  const formatLastRefresh = () => {
    if (!lastRefresh) return ""
    const now = Date.now()
    const diff = now - lastRefresh.getTime()
    const minutes = Math.floor(diff / 60000)
    if (minutes < 1) return "Just now"
    if (minutes === 1) return "1 minute ago"
    if (minutes < 60) return `${minutes} minutes ago`
    const hours = Math.floor(minutes / 60)
    if (hours === 1) return "1 hour ago"
    return `${hours} hours ago`
  }

  const toggleMultiSelectMode = () => {
    setIsMultiSelectMode(!isMultiSelectMode)
    setSelectedVideos(new Set())
  }

  const toggleVideoSelection = (videoId: string) => {
    const newSelected = new Set(selectedVideos)
    if (newSelected.has(videoId)) {
      newSelected.delete(videoId)
    } else {
      newSelected.add(videoId)
    }
    setSelectedVideos(newSelected)
  }

  const selectAllVideos = () => {
    if (selectedVideos.size === filteredVideos.length) {
      setSelectedVideos(new Set())
    } else {
      setSelectedVideos(new Set(filteredVideos.map(v => v.id)))
    }
  }

  const handleBatchDelete = async () => {
    if (selectedVideos.size === 0) return

    setIsBatchDeleting(true)
    const videosToDelete = Array.from(selectedVideos)
    let successCount = 0
    let failCount = 0

    for (const videoId of videosToDelete) {
      try {
        const response = await fetch(`/api/youtube/delete-video?access_token=${accessToken}&video_id=${videoId}`, {
          method: "DELETE",
        })

        if (response.ok) {
          successCount++
        } else {
          failCount++
        }
      } catch (error) {
        console.error(`Error deleting video ${videoId}:`, error)
        failCount++
      }
    }

    toast({
      title: "Batch Delete Complete",
      description: `Successfully deleted ${successCount} video(s). ${failCount > 0 ? `Failed: ${failCount}` : ""}`,
      variant: failCount > 0 ? "destructive" : "default",
    })

    setSelectedVideos(new Set())
    setIsMultiSelectMode(false)
    setIsBatchDeleting(false)
    setIsDeleteDialogOpen(false)
    fetchMyVideos(true)
  }

  const openEditDialog = (video: VideoData) => {
    setEditingVideo(video)
    setEditTitle(video.title)
    setEditDescription(video.description)
    setEditPrivacy(video.privacyStatus)
    setEditThumbnail(null)
    setEditThumbnailPreview(null)
    setIsEditDialogOpen(true)
  }

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Thumbnail must be less than 2MB",
          variant: "destructive",
        })
        return
      }
      setEditThumbnail(file)
      setEditThumbnailPreview(URL.createObjectURL(file))
    }
  }

  const handleTranslateDescription = async (targetLang: string) => {
    if (!editDescription) return

    setIsTranslating(true)
    try {
      const response = await fetch("/api/youtube/translate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: editDescription,
          targetLanguage: targetLang,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Translation failed")
      }

      const data = await response.json()
      setEditDescription(data.translatedText)

      toast({
        title: "Translated",
        description: `Description translated successfully`,
      })
    } catch (error) {
      console.error("[v0] Translation error:", error)
      toast({
        title: "Translation Failed",
        description: error instanceof Error ? error.message : "Failed to translate description",
        variant: "destructive",
      })
    } finally {
      setIsTranslating(false)
    }
  }

  const handleSaveEdit = async () => {
    if (!editingVideo) return

    setIsSaving(true)
    try {
      // Update video metadata
      const response = await fetch("/api/youtube/update-video", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          accessToken,
          videoId: editingVideo.id,
          title: editTitle,
          description: editDescription,
          privacyStatus: editPrivacy,
        }),
      })

      if (!response.ok) throw new Error("Failed to update video")

      if (editThumbnail) {
        const formData = new FormData()
        formData.append("accessToken", accessToken)
        formData.append("videoId", editingVideo.id)
        formData.append("thumbnail", editThumbnail)

        const thumbnailResponse = await fetch("/api/youtube/update-thumbnail", {
          method: "POST",
          body: formData,
        })

        if (!thumbnailResponse.ok) {
          const errorData = await thumbnailResponse.json()
          toast({
            title: "Thumbnail Update Failed",
            description: errorData.error || "Failed to update thumbnail. Try re-authenticating with full permissions.",
            variant: "destructive",
          })
        } else {
          toast({
            title: "Success",
            description: "Video and thumbnail updated successfully",
          })
        }
      } else {
        toast({
          title: "Success",
          description: "Video updated successfully",
        })
      }

      setIsEditDialogOpen(false)
      if (editThumbnailPreview) {
        URL.revokeObjectURL(editThumbnailPreview)
      }
      fetchMyVideos(true)
    } catch (error) {
      console.error("Error updating video:", error)
      toast({
        title: "Error",
        description: "Failed to update video",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteVideo = async () => {
    if (!deleteVideoId) return

    try {
      const response = await fetch(`/api/youtube/delete-video?access_token=${accessToken}&video_id=${deleteVideoId}`, {
        method: "DELETE",
      })

      if (!response.ok) throw new Error("Failed to delete video")

      toast({
        title: "Success",
        description: "Video deleted successfully",
      })

      setIsDeleteDialogOpen(false)
      setDeleteVideoId(null)
      fetchMyVideos(true)
    } catch (error) {
      console.error("Error deleting video:", error)
      toast({
        title: "Error",
        description: "Failed to delete video",
        variant: "destructive",
      })
    }
  }

  const getPrivacyIcon = (status: string) => {
    switch (status) {
      case "public":
        return <Globe className="w-3 h-3" />
      case "private":
        return <Lock className="w-3 h-3" />
      case "unlisted":
        return <Users className="w-3 h-3" />
      default:
        return null
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <Video className="w-10 h-10 text-primary" />
        </div>
        <h2 className="text-3xl font-bold mb-2 text-balance">No Videos Yet</h2>
        <p className="text-muted-foreground text-lg max-w-md text-pretty mb-6">
          Upload your first video to get started
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">My Videos</h2>
          <p className="text-muted-foreground">
            Manage all your uploaded videos
            {lastRefresh && <span className="ml-2 text-xs">• Updated {formatLastRefresh()}</span>}
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={toggleMultiSelectMode} 
            variant={isMultiSelectMode ? "default" : "outline"} 
            size="sm" 
            className="gap-2"
          >
            <CheckSquare className="w-4 h-4" />
            {isMultiSelectMode ? "Cancel" : "Select"}
          </Button>
          <Button onClick={() => fetchMyVideos(true)} variant="outline" size="sm" className="gap-2 bg-transparent">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
        </div>
      </div>

      <Card className="p-4">
        <Label htmlFor="search" className="text-sm font-semibold mb-2 block">
          Search Videos
        </Label>
        <Input
          id="search"
          placeholder="Search by title or description..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <div className="flex items-center justify-between mt-2">
          {filteredVideos.length !== videos.length && (
            <p className="text-xs text-muted-foreground">
              Showing {filteredVideos.length} of {videos.length} videos
            </p>
          )}
          {isMultiSelectMode && (
            <div className="flex items-center gap-2 ml-auto">
              <Button
                variant="outline"
                size="sm"
                onClick={selectAllVideos}
                className="gap-2"
              >
                {selectedVideos.size === filteredVideos.length ? "Deselect All" : "Select All"}
              </Button>
              {selectedVideos.size > 0 && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => setIsDeleteDialogOpen(true)}
                  className="gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete ({selectedVideos.size})
                </Button>
              )}
            </div>
          )}
        </div>
      </Card>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVideos.map((video) => (
          <Card 
            key={video.id} 
            className={`overflow-hidden group hover:border-primary/50 transition-all relative ${selectedVideos.has(video.id) ? 'ring-2 ring-primary' : ''}`}
            onClick={(e) => {
              if (isMultiSelectMode) {
                const target = e.target as HTMLElement
                if (!target.closest('button') && !target.closest('a')) {
                  toggleVideoSelection(video.id)
                }
              }
            }}
          >
            {isMultiSelectMode && (
              <div className="absolute top-2 left-2 z-10 bg-background/90 p-1 rounded">
                <Checkbox
                  checked={selectedVideos.has(video.id)}
                  onCheckedChange={() => toggleVideoSelection(video.id)}
                  className="border-2"
                />
              </div>
            )}
            <div className="relative aspect-video bg-muted">
              <img
                src={video.thumbnail || "/placeholder.svg"}
                alt={video.title}
                className="object-cover w-full h-full"
              />
              <div className="absolute top-2 right-2 flex gap-1">
                <div className="bg-black/80 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
                  {getPrivacyIcon(video.privacyStatus)}
                  <span className="capitalize">{video.privacyStatus}</span>
                </div>
              </div>
            </div>
            <div className="p-4 space-y-3">
              <h3 className="font-semibold line-clamp-2 leading-snug text-balance">{video.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{video.description}</p>

              <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  <span>{formatNumber(video.viewCount)}</span>
                </div>
                <div className="flex items-center gap-1">
                  <ThumbsUp className="w-3 h-3" />
                  <span>{formatNumber(video.likeCount)}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MessageCircle className="w-3 h-3" />
                  <span>{formatNumber(video.commentCount)}</span>
                </div>
              </div>

              <p className="text-xs text-muted-foreground border-t pt-2">{formatDate(video.publishedAt)}</p>

              {!isMultiSelectMode && (
                <div className="flex gap-2 pt-2 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 gap-2 bg-transparent"
                    onClick={() => window.open(`https://www.youtube.com/watch?v=${video.id}`, "_blank")}
                  >
                    <ExternalLink className="w-3 h-3" />
                    Watch
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2 bg-transparent"
                    onClick={() => openEditDialog(video)}
                  >
                    <Pencil className="w-3 h-3" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2 text-destructive hover:bg-destructive/10 bg-transparent"
                    onClick={() => {
                      setDeleteVideoId(video.id)
                      setIsDeleteDialogOpen(true)
                    }}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Video</DialogTitle>
            <DialogDescription>Update your video details, thumbnail, and privacy settings</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="Video title"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="description">Description</Label>
                <div className="flex gap-1 flex-wrap">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("es")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    ES
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("fr")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    FR
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("de")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    DE
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("ko")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    KO
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("th")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    TH
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("ja")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    JA
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("zh-CN")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    CN
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleTranslateDescription("pt")}
                    disabled={isTranslating}
                    className="gap-1 text-xs h-7"
                  >
                    <Languages className="w-3 h-3" />
                    PT
                  </Button>
                </div>
              </div>
              <Textarea
                id="description"
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                placeholder="Video description"
                rows={6}
              />
              {isTranslating && <p className="text-xs text-muted-foreground">Translating...</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="thumbnail">Thumbnail (Optional)</Label>
              {editThumbnailPreview && (
                <div className="relative w-full aspect-video rounded-lg overflow-hidden border">
                  <img
                    src={editThumbnailPreview || "/placeholder.svg"}
                    alt="Thumbnail preview"
                    className="w-full h-full object-cover"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute top-2 right-2"
                    onClick={() => {
                      if (editThumbnailPreview) {
                        URL.revokeObjectURL(editThumbnailPreview)
                      }
                      setEditThumbnail(null)
                      setEditThumbnailPreview(null)
                    }}
                  >
                    Remove
                  </Button>
                </div>
              )}
              <Button
                type="button"
                variant="outline"
                className="w-full gap-2"
                onClick={() => document.getElementById("edit-thumbnail-input")?.click()}
              >
                <Image className="w-4 h-4" />
                {editThumbnailPreview ? "Change Thumbnail" : "Add Thumbnail"}
              </Button>
              <input
                id="edit-thumbnail-input"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleThumbnailChange}
              />
              <p className="text-xs text-muted-foreground">Max 2MB. Recommended: 1280x720px. Requires YouTube upload scope.</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="privacy">Privacy</Label>
              <Select value={editPrivacy} onValueChange={setEditPrivacy}>
                <SelectTrigger id="privacy">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">Public</SelectItem>
                  <SelectItem value="unlisted">Unlisted</SelectItem>
                  <SelectItem value="private">Private</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} disabled={isSaving}>
              Cancel
            </Button>
            <Button onClick={handleSaveEdit} disabled={isSaving}>
              {isSaving ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedVideos.size > 0 
                ? `This will permanently delete ${selectedVideos.size} video(s) from YouTube. This action cannot be undone.`
                : "This action cannot be undone. This will permanently delete your video from YouTube."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setDeleteVideoId(null)
              setSelectedVideos(new Set())
            }}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={selectedVideos.size > 0 ? handleBatchDelete : handleDeleteVideo}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isBatchDeleting}
            >
              {isBatchDeleting ? "Deleting..." : `Delete Video${selectedVideos.size > 1 ? 's' : ''}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
