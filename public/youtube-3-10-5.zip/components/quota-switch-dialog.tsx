"use client"

import { useState, useEffect } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { AlertTriangle, RefreshCw, CheckCircle2, XCircle, LogOut, Info } from 'lucide-react'
import { getAllClients, setActiveClient, getActiveClient, isClientQuotaExceeded, type ClientConfig } from "@/lib/client-manager"

interface QuotaSwitchDialogProps {
  open: boolean
  onClose: () => void
  onSwitch: (clientId: string) => void
}

export function QuotaSwitchDialog({ open, onClose, onSwitch }: QuotaSwitchDialogProps) {
  const [clients, setClients] = useState<ClientConfig[]>([])
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null)
  const [activeClientId, setActiveClientId] = useState<string | null>(null)
  const [currentRedirectUri, setCurrentRedirectUri] = useState<string>("")

  useEffect(() => {
    if (open) {
      const allClients = getAllClients()
      setClients(allClients)
      
      const currentClient = getActiveClient()
      if (currentClient) {
        setActiveClientId(currentClient.id)
      }
      
      const availableClient = allClients.find(client => !isClientQuotaExceeded(client.id))
      if (availableClient) {
        setSelectedClientId(availableClient.id)
      }
      
      if (typeof window !== "undefined") {
        setCurrentRedirectUri(`${window.location.origin}/`)
      }
    }
  }, [open])

  const handleSwitch = () => {
    if (selectedClientId) {
      console.log('[v0] Switching to client:', selectedClientId)
      
      // Set the new active client
      setActiveClient(selectedClientId)
      
      // Clear all stored tokens to force re-authentication
      localStorage.removeItem("youtube_token")
      localStorage.removeItem("youtube_tokens_multi")
      
      console.log('[v0] Cleared all tokens, forcing re-authentication')
      
      // Call onSwitch callback
      onSwitch(selectedClientId)
      
      // Close dialog
      onClose()
      
      // Reload page to apply new client and force re-auth
      window.location.reload()
    }
  }

  const availableClients = clients.filter(c => !isClientQuotaExceeded(c.id))
  const quotaExceededClients = clients.filter(c => isClientQuotaExceeded(c.id))

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-destructive/10 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <DialogTitle className="text-xl">Quota Limit Reached</DialogTitle>
              <DialogDescription className="mt-1">
                The current API client has exceeded its quota. Switch to another client and re-authenticate to continue.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="p-3 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-amber-800 dark:text-amber-200 space-y-1">
              <p className="font-semibold">Important: Configure Redirect URI</p>
              <p>Each Google Client ID must have this redirect URI authorized in Google Cloud Console:</p>
              <code className="block px-2 py-1 bg-amber-100 dark:bg-amber-900 rounded text-xs font-mono break-all mt-1">
                {currentRedirectUri}
              </code>
              <p className="text-xs mt-1">
                Go to Google Cloud Console → APIs & Services → Credentials → OAuth 2.0 Client IDs → 
                Edit your client → Add the URI above to "Authorized redirect URIs"
              </p>
            </div>
          </div>
        </div>

        <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
          <div className="flex items-center gap-2">
            <LogOut className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0" />
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <strong>Note:</strong> Switching clients will log you out and reload the page. You'll need to sign in again with the new client.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 pb-4 border-b">
          <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />
              <span className="text-sm font-semibold text-green-800 dark:text-green-200">Available</span>
            </div>
            <p className="text-2xl font-bold text-green-600 dark:text-green-400">{availableClients.length}</p>
          </div>
          <div className="p-3 bg-red-50 dark:bg-red-950 rounded-lg border border-red-200 dark:border-red-800">
            <div className="flex items-center gap-2 mb-1">
              <XCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
              <span className="text-sm font-semibold text-red-800 dark:text-red-200">Quota Exceeded</span>
            </div>
            <p className="text-2xl font-bold text-red-600 dark:text-red-400">{quotaExceededClients.length}</p>
          </div>
        </div>

        <div className="space-y-4 py-4">
          {availableClients.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />
                <span>Available Clients ({availableClients.length})</span>
              </div>

              <div className="grid gap-2">
                {availableClients.map((client) => {
                  const isActive = client.id === activeClientId
                  const isSelected = selectedClientId === client.id
                  
                  return (
                    <button
                      key={client.id}
                      onClick={() => setSelectedClientId(client.id)}
                      className={`p-4 rounded-lg border-2 transition-all text-left ${
                        isSelected
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{client.label}</span>
                          {isActive && (
                            <span className="px-2 py-0.5 bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300 text-xs font-semibold rounded-full">
                              Currently Exceeded
                            </span>
                          )}
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                            <div className="w-2.5 h-2.5 bg-white rounded-full"></div>
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground break-all font-mono">
                        {client.clientId}
                      </p>
                    </button>
                  )
                })}
              </div>
            </div>
          )}

          {quotaExceededClients.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <XCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                <span className="text-red-600 dark:text-red-400">Quota Exceeded ({quotaExceededClients.length})</span>
              </div>

              <div className="grid gap-2 opacity-60">
                {quotaExceededClients.map((client) => {
                  const isActive = client.id === activeClientId
                  
                  return (
                    <div
                      key={client.id}
                      className="p-4 rounded-lg border-2 border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950/50"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-red-800 dark:text-red-200">{client.label}</span>
                          {isActive && (
                            <span className="px-2 py-0.5 bg-red-200 dark:bg-red-900 text-red-800 dark:text-red-200 text-xs font-semibold rounded-full">
                              Current
                            </span>
                          )}
                        </div>
                        <XCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                      </div>
                      <p className="text-xs text-red-700 dark:text-red-300 break-all font-mono">
                        {client.clientId}
                      </p>
                      <p className="text-xs text-red-700 dark:text-red-300 mt-2">
                        Quota resets at midnight Pacific Time
                      </p>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {availableClients.length === 0 && (
            <div className="p-4 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                <div>
                  <p className="font-semibold text-sm text-amber-900 dark:text-amber-100 mb-1">
                    All Clients Quota Exceeded
                  </p>
                  <p className="text-xs text-amber-800 dark:text-amber-200">
                    All your API clients have exceeded their daily quota. Quotas reset at midnight Pacific Time. 
                    You can add more clients in the environment variables or wait for the reset.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-3 justify-end border-t pt-4">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleSwitch}
            disabled={!selectedClientId || isClientQuotaExceeded(selectedClientId)}
            className="gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Switch & Re-authenticate
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
