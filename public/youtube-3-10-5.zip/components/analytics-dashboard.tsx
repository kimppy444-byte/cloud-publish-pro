"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Eye,
  ThumbsUp,
  MessageCircle,
  TrendingUp,
  RefreshCw,
  BarChart3,
  AlertCircle,
  ExternalLink,
  Copy,
  Users,
  Video,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { VideoCommentManager } from "@/components/video-comment-manager"
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts"

interface Account {
  email: string
  accessToken: string
  channelId?: string
  channelTitle?: string
  channelThumbnail?: string
}

interface AnalyticsDashboardProps {
  accessToken?: string
  accounts?: Account[]
}

interface ChannelStats {
  viewCount: string
  subscriberCount: string
  videoCount: string
}

interface RecentVideo {
  id: string
  title: string
  views: string
  likes: string
  comments: string
  publishedAt: string
  thumbnail?: string
}

interface AccountAnalytics {
  account: Account
  channelStats: ChannelStats | null
  recentVideos: RecentVideo[]
  isLoading: boolean
  error: string | null
}

export function AnalyticsDashboard({ accessToken, accounts = [] }: AnalyticsDashboardProps) {
  const [accountAnalytics, setAccountAnalytics] = useState<AccountAnalytics[]>([])
  const [selectedVideoForComment, setSelectedVideoForComment] = useState<{
    accountEmail: string
    video: RecentVideo
  } | null>(null)
  const { toast } = useToast()

  // Determine which accounts to use
  const activeAccounts = accounts.length > 0 ? accounts : accessToken ? [{ email: "default", accessToken }] : []

  const fetchAnalyticsForAccount = async (account: Account): Promise<Partial<AccountAnalytics>> => {
    try {
      const response = await fetch(`/api/youtube/analytics?access_token=${account.accessToken}`)

      if (!response.ok) {
        throw new Error(`Failed to fetch analytics: ${response.status}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      return {
        channelStats: data.channelStats || null,
        recentVideos: data.recentVideos || [],
        error: null,
      }
    } catch (error) {
      console.error("[v0] Error fetching analytics for", account.email, error)
      return {
        channelStats: null,
        recentVideos: [],
        error: error instanceof Error ? error.message : "Failed to load analytics",
      }
    }
  }

  const fetchAllAnalytics = async () => {
    // Initialize all accounts as loading
    setAccountAnalytics(
      activeAccounts.map((account) => ({
        account,
        channelStats: null,
        recentVideos: [],
        isLoading: true,
        error: null,
      })),
    )

    // Fetch analytics for all accounts in parallel
    const results = await Promise.all(
      activeAccounts.map(async (account) => {
        const data = await fetchAnalyticsForAccount(account)
        return {
          account,
          channelStats: data.channelStats || null,
          recentVideos: data.recentVideos || [],
          isLoading: false,
          error: data.error || null,
        }
      }),
    )

    setAccountAnalytics(results)
  }

  useEffect(() => {
    if (activeAccounts.length > 0) {
      fetchAllAnalytics()
    }
  }, [activeAccounts.length])

  const formatNumber = (num: string) => {
    const n = Number.parseInt(num)
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`
    return n.toString()
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  // Calculate aggregate stats
  const aggregateStats = accountAnalytics.reduce(
    (acc, item) => {
      if (item.channelStats) {
        acc.totalViews += Number.parseInt(item.channelStats.viewCount) || 0
        acc.totalSubscribers += Number.parseInt(item.channelStats.subscriberCount) || 0
        acc.totalVideos += Number.parseInt(item.channelStats.videoCount) || 0
      }
      return acc
    },
    { totalViews: 0, totalSubscribers: 0, totalVideos: 0 },
  )

  const isLoading = accountAnalytics.some((a) => a.isLoading)
  const hasAnyData = accountAnalytics.some((a) => a.channelStats !== null)

  if (activeAccounts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <BarChart3 className="w-10 h-10 text-primary" />
        </div>
        <h2 className="text-3xl font-bold mb-2 text-balance">No Accounts Connected</h2>
        <p className="text-muted-foreground text-lg max-w-md text-pretty">
          Connect a YouTube account to view analytics
        </p>
      </div>
    )
  }

  if (isLoading && accountAnalytics.every((a) => a.isLoading)) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header with Refresh */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Channel Analytics</h2>
          <p className="text-muted-foreground">
            {activeAccounts.length > 1
              ? `Viewing analytics for ${activeAccounts.length} accounts`
              : "Track your channel performance"}
          </p>
        </div>
        <Button onClick={fetchAllAnalytics} variant="outline" size="sm" className="gap-2 bg-transparent">
          <RefreshCw className="w-4 h-4" />
          Refresh All
        </Button>
      </div>

      {/* Aggregate Stats Cards */}
      {activeAccounts.length > 1 && hasAnyData && (
        <div className="grid sm:grid-cols-3 gap-4">
          <Card className="p-6 bg-gradient-to-br from-primary/5 to-transparent border-primary/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Combined Views</p>
                <p className="text-3xl font-bold mt-1">{formatNumber(aggregateStats.totalViews.toString())}</p>
              </div>
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Eye className="h-6 w-6 text-primary" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Across all accounts</p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-chart-2/5 to-transparent border-chart-2/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Combined Subscribers</p>
                <p className="text-3xl font-bold mt-1">{formatNumber(aggregateStats.totalSubscribers.toString())}</p>
              </div>
              <div className="h-12 w-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <Users className="h-6 w-6 text-chart-2" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Across all accounts</p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-chart-3/5 to-transparent border-chart-3/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Videos</p>
                <p className="text-3xl font-bold mt-1">{aggregateStats.totalVideos}</p>
              </div>
              <div className="h-12 w-12 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <Video className="h-6 w-6 text-chart-3" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Across all accounts</p>
          </Card>
        </div>
      )}

      {/* Per-Account Analytics Tabs */}
      <Tabs defaultValue={activeAccounts[0]?.email || "default"} className="space-y-4">
        <TabsList className="w-full justify-start overflow-x-auto flex-nowrap bg-muted/50 p-1">
          {activeAccounts.map((account) => (
            <TabsTrigger
              key={account.email}
              value={account.email}
              className="flex items-center gap-2 px-4 shrink-0 data-[state=active]:bg-background"
            >
              {account.channelThumbnail && (
                <img src={account.channelThumbnail || "/placeholder.svg"} alt="" className="w-5 h-5 rounded-full" />
              )}
              <span className="truncate max-w-32">{account.channelTitle || account.email}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {accountAnalytics.map((analytics) => (
          <TabsContent key={analytics.account.email} value={analytics.account.email} className="space-y-6">
            {analytics.isLoading ? (
              <div className="flex items-center justify-center py-20">
                <div className="animate-spin rounded-full h-10 w-10 border-4 border-primary border-t-transparent" />
              </div>
            ) : analytics.error ? (
              <Card className="p-8">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center">
                    <AlertCircle className="w-8 h-8 text-destructive" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold">Failed to Load Analytics</h3>
                    <p className="text-muted-foreground">{analytics.error}</p>
                  </div>
                  <Button onClick={fetchAllAnalytics} className="gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Try Again
                  </Button>
                </div>
              </Card>
            ) : !analytics.channelStats ? (
              <Card className="p-8">
                <div className="flex flex-col items-center text-center">
                  <BarChart3 className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-xl font-bold">No Data Available</h3>
                  <p className="text-muted-foreground">Unable to load analytics for this account</p>
                </div>
              </Card>
            ) : (
              <>
                {/* Account Stats Cards */}
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Card className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Views</p>
                        <p className="text-3xl font-bold mt-1">{formatNumber(analytics.channelStats.viewCount)}</p>
                      </div>
                      <div className="h-12 w-12 rounded-lg bg-chart-1/10 flex items-center justify-center">
                        <Eye className="h-6 w-6 text-chart-1" />
                      </div>
                    </div>
                    <div className="flex items-center gap-1 mt-4 text-sm text-chart-2">
                      <TrendingUp className="h-4 w-4" />
                      <span>Lifetime total</span>
                    </div>
                  </Card>

                  <Card className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Subscribers</p>
                        <p className="text-3xl font-bold mt-1">
                          {analytics.channelStats.subscriberCount === "0"
                            ? "Hidden"
                            : formatNumber(analytics.channelStats.subscriberCount)}
                        </p>
                      </div>
                      <div className="h-12 w-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
                        <Users className="h-6 w-6 text-chart-2" />
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">Total count</p>
                  </Card>

                  <Card className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Videos</p>
                        <p className="text-3xl font-bold mt-1">{analytics.channelStats.videoCount}</p>
                      </div>
                      <div className="h-12 w-12 rounded-lg bg-chart-3/10 flex items-center justify-center">
                        <Video className="h-6 w-6 text-chart-3" />
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-4">Published</p>
                  </Card>
                </div>

                {/* Performance Chart */}
                {analytics.recentVideos.length > 0 && (
                  <Card className="p-6">
                    <h3 className="text-lg font-semibold mb-4">Recent Video Performance</h3>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={analytics.recentVideos
                            .slice(0, 7)
                            .reverse()
                            .map((video) => ({
                              name: formatDate(video.publishedAt),
                              views: Number.parseInt(video.views) || 0,
                              likes: Number.parseInt(video.likes) || 0,
                            }))}
                          margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id={`colorViews-${analytics.account.email}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="hsl(220, 70%, 50%)" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="hsl(220, 70%, 50%)" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                          <XAxis
                            dataKey="name"
                            className="text-muted-foreground"
                            fontSize={12}
                            tickLine={false}
                            axisLine={false}
                          />
                          <YAxis
                            className="text-muted-foreground"
                            fontSize={12}
                            tickLine={false}
                            axisLine={false}
                            tickFormatter={(value) => formatNumber(value.toString())}
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                              color: "hsl(var(--card-foreground))",
                            }}
                          />
                          <Area
                            type="monotone"
                            dataKey="views"
                            stroke="hsl(220, 70%, 50%)"
                            fillOpacity={1}
                            fill={`url(#colorViews-${analytics.account.email})`}
                            strokeWidth={2}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </Card>
                )}

                {/* Recent Videos */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Recent Videos</h3>
                  <div className="space-y-3">
                    {analytics.recentVideos.length === 0 ? (
                      <p className="text-muted-foreground text-center py-8">No videos found</p>
                    ) : (
                      analytics.recentVideos.map((video) => (
                        <div key={video.id} className="space-y-3">
                          <div className="flex items-start gap-4 p-4 border border-border rounded-lg hover:border-primary/50 transition-colors">
                            {video.thumbnail && (
                              <div className="w-32 aspect-video rounded-md overflow-hidden flex-shrink-0 bg-muted">
                                <img
                                  src={video.thumbnail || "/placeholder.svg"}
                                  alt={video.title}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            )}

                            <div className="flex-1 min-w-0 space-y-3">
                              <div>
                                <a
                                  href={`https://www.youtube.com/watch?v=${video.id}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="font-semibold text-sm hover:text-primary transition-colors line-clamp-2"
                                >
                                  {video.title}
                                </a>
                                <p className="text-xs text-muted-foreground mt-1">{formatDate(video.publishedAt)}</p>
                              </div>

                              <div className="flex items-center gap-2 text-xs">
                                <code className="flex-1 px-2 py-1 bg-muted rounded text-muted-foreground font-mono truncate">
                                  https://www.youtube.com/watch?v={video.id}
                                </code>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 px-2 shrink-0"
                                  onClick={() => {
                                    navigator.clipboard.writeText(`https://www.youtube.com/watch?v=${video.id}`)
                                    toast({
                                      title: "Copied!",
                                      description: "Video URL copied to clipboard",
                                    })
                                  }}
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                                <Button variant="ghost" size="sm" className="h-7 px-2 shrink-0" asChild>
                                  <a
                                    href={`https://www.youtube.com/watch?v=${video.id}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                </Button>
                              </div>

                              <div className="flex items-center gap-4 text-sm">
                                <div className="flex items-center gap-1">
                                  <Eye className="w-4 h-4 text-muted-foreground" />
                                  <span>{formatNumber(video.views)}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <ThumbsUp className="w-4 h-4 text-muted-foreground" />
                                  <span>{formatNumber(video.likes)}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <MessageCircle className="w-4 h-4 text-muted-foreground" />
                                  <span>{formatNumber(video.comments)}</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {selectedVideoForComment?.accountEmail === analytics.account.email &&
                            selectedVideoForComment?.video.id === video.id && (
                              <VideoCommentManager
                                videoId={video.id}
                                accessToken={analytics.account.accessToken}
                                videoTitle={video.title}
                              />
                            )}

                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              setSelectedVideoForComment(
                                selectedVideoForComment?.video.id === video.id &&
                                  selectedVideoForComment?.accountEmail === analytics.account.email
                                  ? null
                                  : { accountEmail: analytics.account.email, video },
                              )
                            }
                            className="gap-2 ml-4"
                          >
                            <MessageCircle className="w-4 h-4" />
                            {selectedVideoForComment?.video.id === video.id &&
                            selectedVideoForComment?.accountEmail === analytics.account.email
                              ? "Hide Comment Box"
                              : "Post Comment"}
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </Card>
              </>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
