"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import {
  Instagram,
  Plus,
  Trash2,
  Zap,
  Eye,
  Clock,
  Hash,
  MessageCircle,
  Send,
  Play,
  Pause,
  RefreshCw,
  Info,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
} from "lucide-react"
import type { InstagramAutoReplyRule } from "@/lib/instagram-storage"
import {
  getInstagramAutoReplyRulesForAccount,
  saveInstagramAutoReplyRule,
  deleteInstagramAutoReplyRule,
  generateInstagramRuleId,
  updateInstagramRuleMatchCount,
  hasRepliedToInstagramComment,
  hasRepliedToInstagramUser,
  markInstagramCommentAsReplied,
} from "@/lib/instagram-storage"

interface InstagramAccount {
  id: string
  username?: string
  profile_picture_url?: string
  pageAccessToken: string
}

interface Comment {
  id: string
  text: string
  username: string
  timestamp: string
  mediaId: string
  mediaCaption?: string
  from?: { id: string }
}

interface RecentActivity {
  type: "match" | "reply" | "dm" | "error"
  message: string
  timestamp: number
  rule?: string
  username?: string
}

interface InstagramAutoReplyManagerProps {
  instagramAccount: InstagramAccount | null
  pageAccessToken: string
}

export function InstagramAutoReplyManager({ instagramAccount, pageAccessToken }: InstagramAutoReplyManagerProps) {
  const [rules, setRules] = useState<InstagramAutoReplyRule[]>([])
  const [isMonitoring, setIsMonitoring] = useState(false)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([])
  const [lastCheck, setLastCheck] = useState<Date | null>(null)
  const [checkInterval, setCheckInterval] = useState(60) // seconds
  const [replyMode, setReplyMode] = useState<"comment" | "dm">("comment") // dm or comment reply
  const monitoringRef = useRef<NodeJS.Timeout | null>(null)
  const { toast } = useToast()

  // New rule form state
  const [newKeyword, setNewKeyword] = useState("")
  const [newReplyMessage, setNewReplyMessage] = useState("")

  // Load rules when account changes
  useEffect(() => {
    if (instagramAccount) {
      const accountRules = getInstagramAutoReplyRulesForAccount(instagramAccount.id)
      setRules(accountRules)
    }
  }, [instagramAccount])

  const addActivity = useCallback((activity: Omit<RecentActivity, "timestamp">) => {
    setRecentActivity((prev) => [{ ...activity, timestamp: Date.now() }, ...prev.slice(0, 49)])
  }, [])

  const checkForComments = useCallback(async () => {
    if (!instagramAccount || !pageAccessToken || rules.filter((r) => r.enabled).length === 0) return

    setLastCheck(new Date())

    try {
      // Fetch recent comments
      const response = await fetch(
        `/api/instagram/comments?access_token=${pageAccessToken}&ig_account_id=${instagramAccount.id}`,
      )

      if (!response.ok) {
        const error = await response.json()
        addActivity({
          type: "error",
          message: `Failed to fetch comments: ${error.error}`,
        })
        return
      }

      const { comments } = await response.json()

      // Check each comment against enabled rules
      for (const comment of comments || []) {
        // Skip if we've already replied to this comment
        if (hasRepliedToInstagramComment(comment.id)) continue

        const commentText = (comment.text || "").toLowerCase()
        const userId = comment.from?.id

        for (const rule of rules.filter((r) => r.enabled)) {
          const keyword = rule.keyword.toLowerCase()

          // Check if comment contains the keyword
          if (commentText.includes(keyword)) {
            addActivity({
              type: "match",
              message: `Found keyword "${rule.keyword}" in comment from @${comment.username}`,
              rule: rule.keyword,
              username: comment.username,
            })

            if (replyMode === "comment") {
              // Reply to the comment directly
              try {
                const replyResponse = await fetch("/api/instagram/reply-comment", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    accessToken: pageAccessToken,
                    commentId: comment.id,
                    message: rule.replyMessage,
                  }),
                })

                if (replyResponse.ok) {
                  markInstagramCommentAsReplied(comment.id, rule.id, userId || "unknown")
                  updateInstagramRuleMatchCount(rule.id)

                  setRules((prev) =>
                    prev.map((r) =>
                      r.id === rule.id ? { ...r, matchCount: r.matchCount + 1, lastMatchAt: Date.now() } : r,
                    ),
                  )

                  addActivity({
                    type: "reply",
                    message: `Replied to @${comment.username}'s comment`,
                    rule: rule.keyword,
                    username: comment.username,
                  })

                  toast({
                    title: "Auto-Reply Sent",
                    description: `Replied to @${comment.username} for keyword "${rule.keyword}"`,
                  })
                } else {
                  const error = await replyResponse.json()
                  addActivity({
                    type: "error",
                    message: `Failed to reply: ${error.error}`,
                    rule: rule.keyword,
                  })
                }
              } catch (err) {
                addActivity({
                  type: "error",
                  message: `Reply error: ${err instanceof Error ? err.message : "Unknown error"}`,
                  rule: rule.keyword,
                })
              }
            } else if (replyMode === "dm" && userId) {
              // Check if we've already DMed this user for this rule recently
              if (hasRepliedToInstagramUser(userId, rule.id)) {
                addActivity({
                  type: "error",
                  message: `Already DMed @${comment.username} for this rule in the last 24h`,
                  rule: rule.keyword,
                })
                continue
              }

              // Send DM to the user
              try {
                const dmResponse = await fetch("/api/instagram/send-dm", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    accessToken: pageAccessToken,
                    igAccountId: instagramAccount.id,
                    recipientId: userId,
                    message: rule.replyMessage,
                  }),
                })

                if (dmResponse.ok) {
                  markInstagramCommentAsReplied(comment.id, rule.id, userId)
                  updateInstagramRuleMatchCount(rule.id)

                  setRules((prev) =>
                    prev.map((r) =>
                      r.id === rule.id ? { ...r, matchCount: r.matchCount + 1, lastMatchAt: Date.now() } : r,
                    ),
                  )

                  addActivity({
                    type: "dm",
                    message: `Sent DM to @${comment.username}`,
                    rule: rule.keyword,
                    username: comment.username,
                  })

                  toast({
                    title: "DM Sent",
                    description: `Sent DM to @${comment.username} for keyword "${rule.keyword}"`,
                  })
                } else {
                  const error = await dmResponse.json()
                  addActivity({
                    type: "error",
                    message: `DM failed: ${error.error}`,
                    rule: rule.keyword,
                  })
                }
              } catch (err) {
                addActivity({
                  type: "error",
                  message: `DM error: ${err instanceof Error ? err.message : "Unknown error"}`,
                  rule: rule.keyword,
                })
              }
            }

            // Only process one rule per comment
            break
          }
        }
      }
    } catch (err) {
      addActivity({
        type: "error",
        message: `Check failed: ${err instanceof Error ? err.message : "Unknown error"}`,
      })
    }
  }, [instagramAccount, pageAccessToken, rules, replyMode, addActivity, toast])

  // Start/stop monitoring
  useEffect(() => {
    if (isMonitoring) {
      checkForComments()
      monitoringRef.current = setInterval(checkForComments, checkInterval * 1000)
    } else {
      if (monitoringRef.current) {
        clearInterval(monitoringRef.current)
        monitoringRef.current = null
      }
    }

    return () => {
      if (monitoringRef.current) {
        clearInterval(monitoringRef.current)
      }
    }
  }, [isMonitoring, checkInterval, checkForComments])

  const handleCreateRule = () => {
    if (!instagramAccount || !newKeyword.trim() || !newReplyMessage.trim()) {
      toast({
        title: "Missing Fields",
        description: "Please fill in both keyword and reply message",
        variant: "destructive",
      })
      return
    }

    const newRule: InstagramAutoReplyRule = {
      id: generateInstagramRuleId(),
      keyword: newKeyword.trim(),
      replyMessage: newReplyMessage.trim(),
      enabled: true,
      createdAt: Date.now(),
      matchCount: 0,
      instagramAccountId: instagramAccount.id,
      pageAccessToken,
    }

    saveInstagramAutoReplyRule(newRule)
    setRules((prev) => [...prev, newRule])
    setNewKeyword("")
    setNewReplyMessage("")
    setIsCreateDialogOpen(false)

    toast({
      title: "Rule Created",
      description: `Auto-reply rule for "${newKeyword}" has been created`,
    })
  }

  const handleDeleteRule = (ruleId: string) => {
    deleteInstagramAutoReplyRule(ruleId)
    setRules((prev) => prev.filter((r) => r.id !== ruleId))
    toast({
      title: "Rule Deleted",
      description: "Auto-reply rule has been deleted",
    })
  }

  const handleToggleRule = (ruleId: string, enabled: boolean) => {
    const rule = rules.find((r) => r.id === ruleId)
    if (rule) {
      const updated = { ...rule, enabled }
      saveInstagramAutoReplyRule(updated)
      setRules((prev) => prev.map((r) => (r.id === ruleId ? updated : r)))
    }
  }

  const formatTimeAgo = (timestamp: number) => {
    const seconds = Math.floor((Date.now() - timestamp) / 1000)
    if (seconds < 60) return `${seconds}s ago`
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    const days = Math.floor(hours / 24)
    return `${days}d ago`
  }

  if (!instagramAccount) {
    return (
      <Card className="p-8 text-center">
        <Instagram className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">No Instagram Account Connected</h3>
        <p className="text-muted-foreground">Connect your Instagram Business Account to use the auto-reply feature.</p>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Info Banner */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Instagram Auto-Reply</AlertTitle>
        <AlertDescription>
          When someone comments a trigger keyword on your posts, you can automatically reply to their comment or send
          them a DM with your pre-configured message.
          <br />
          <br />
          <strong>Note:</strong> DMs can only be sent to users who have previously messaged your account (Instagram API
          limitation).
        </AlertDescription>
      </Alert>

      {/* Header with Controls */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex items-center gap-3">
          <Instagram className="w-5 h-5 text-pink-500" />
          <span className="font-medium">@{instagramAccount.username || instagramAccount.id}</span>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Select value={replyMode} onValueChange={(v: "comment" | "dm") => setReplyMode(v)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="comment">
                <span className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  Reply to Comment
                </span>
              </SelectItem>
              <SelectItem value="dm">
                <span className="flex items-center gap-2">
                  <Send className="w-4 h-4" />
                  Send DM
                </span>
              </SelectItem>
            </SelectContent>
          </Select>

          <Select value={checkInterval.toString()} onValueChange={(v) => setCheckInterval(Number.parseInt(v))}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="30">30 seconds</SelectItem>
              <SelectItem value="60">1 minute</SelectItem>
              <SelectItem value="120">2 minutes</SelectItem>
              <SelectItem value="300">5 minutes</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant={isMonitoring ? "destructive" : "default"}
            onClick={() => setIsMonitoring(!isMonitoring)}
            disabled={rules.filter((r) => r.enabled).length === 0}
            className="gap-2"
          >
            {isMonitoring ? (
              <>
                <Pause className="w-4 h-4" />
                Stop
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Start Monitoring
              </>
            )}
          </Button>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2 bg-transparent">
                <Plus className="w-4 h-4" />
                Add Rule
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Instagram Auto-Reply Rule</DialogTitle>
                <DialogDescription>
                  Set up a keyword trigger. When someone comments with this keyword on your posts, they'll receive your
                  automatic {replyMode === "dm" ? "DM" : "reply"}.
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="ig-keyword">Trigger Keyword</Label>
                  <Input
                    id="ig-keyword"
                    placeholder="e.g., SCRIPT, LINK, FREE"
                    value={newKeyword}
                    onChange={(e) => setNewKeyword(e.target.value.toUpperCase())}
                  />
                  <p className="text-xs text-muted-foreground">
                    Case-insensitive. Comments containing this word will trigger the auto-reply.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ig-reply">Auto-Reply Message</Label>
                  <Textarea
                    id="ig-reply"
                    placeholder={
                      replyMode === "dm"
                        ? "e.g., Thanks for your interest! Here's the link: https://..."
                        : "e.g., Check your DMs for the link!"
                    }
                    value={newReplyMessage}
                    onChange={(e) => setNewReplyMessage(e.target.value)}
                    rows={4}
                  />
                </div>

                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm font-medium mb-1">Example Caption:</p>
                  <p className="text-xs text-muted-foreground">
                    "Comment <strong>{newKeyword || "SCRIPT"}</strong> below and I'll send you the link!"
                  </p>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateRule}>Create Rule</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Status Banner */}
      {isMonitoring && (
        <Card className="p-4 bg-pink-50 dark:bg-pink-950 border-pink-200 dark:border-pink-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-3 h-3 bg-pink-500 rounded-full animate-pulse" />
                <div className="absolute inset-0 w-3 h-3 bg-pink-500 rounded-full animate-ping opacity-75" />
              </div>
              <div>
                <p className="font-medium text-pink-800 dark:text-pink-200">
                  Auto-Reply Active ({replyMode === "dm" ? "DM Mode" : "Comment Reply Mode"})
                </p>
                <p className="text-sm text-pink-600 dark:text-pink-400">
                  Checking every {checkInterval} seconds
                  {lastCheck && ` • Last check: ${formatTimeAgo(lastCheck.getTime())}`}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={checkForComments}
              className="gap-2 text-pink-700 dark:text-pink-300"
            >
              <RefreshCw className="w-4 h-4" />
              Check Now
            </Button>
          </div>
        </Card>
      )}

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Rules List */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Zap className="w-5 h-5 text-pink-500" />
              Auto-Reply Rules
            </h3>
            <Badge variant="secondary">{rules.length} rules</Badge>
          </div>

          {rules.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <MessageSquare className="w-10 h-10 mx-auto mb-3 opacity-50" />
              <p>No rules created yet</p>
              <p className="text-sm">Create your first auto-reply rule to get started</p>
            </div>
          ) : (
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-3">
                {rules.map((rule) => (
                  <Card
                    key={rule.id}
                    className={`p-4 transition-colors ${rule.enabled ? "bg-card" : "bg-muted/50 opacity-60"}`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge
                            variant={rule.enabled ? "default" : "secondary"}
                            className="bg-pink-500 hover:bg-pink-600"
                          >
                            <Hash className="w-3 h-3 mr-1" />
                            {rule.keyword}
                          </Badge>
                          {rule.matchCount > 0 && (
                            <Badge variant="outline" className="text-xs">
                              {rule.matchCount} matches
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-2">{rule.replyMessage}</p>
                        {rule.lastMatchAt && (
                          <p className="text-xs text-muted-foreground mt-2">
                            <Clock className="w-3 h-3 inline mr-1" />
                            Last match: {formatTimeAgo(rule.lastMatchAt)}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <Switch
                          checked={rule.enabled}
                          onCheckedChange={(checked) => handleToggleRule(rule.id, checked)}
                        />
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-destructive">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Rule</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete the auto-reply rule for "{rule.keyword}"?
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteRule(rule.id)}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          )}
        </Card>

        {/* Recent Activity */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Eye className="w-5 h-5 text-pink-500" />
              Recent Activity
            </h3>
            {recentActivity.length > 0 && (
              <Button variant="ghost" size="sm" onClick={() => setRecentActivity([])} className="text-xs">
                Clear
              </Button>
            )}
          </div>

          {recentActivity.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Clock className="w-10 h-10 mx-auto mb-3 opacity-50" />
              <p>No recent activity</p>
              <p className="text-sm">Activity will appear here when monitoring is active</p>
            </div>
          ) : (
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-2">
                {recentActivity.map((activity, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-lg text-sm flex items-start gap-3 ${
                      activity.type === "match"
                        ? "bg-blue-50 dark:bg-blue-950"
                        : activity.type === "reply"
                          ? "bg-green-50 dark:bg-green-950"
                          : activity.type === "dm"
                            ? "bg-pink-50 dark:bg-pink-950"
                            : "bg-red-50 dark:bg-red-950"
                    }`}
                  >
                    {activity.type === "match" && <Zap className="w-4 h-4 text-blue-500 mt-0.5" />}
                    {activity.type === "reply" && <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5" />}
                    {activity.type === "dm" && <Send className="w-4 h-4 text-pink-500 mt-0.5" />}
                    {activity.type === "error" && <AlertCircle className="w-4 h-4 text-red-500 mt-0.5" />}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium">{activity.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatTimeAgo(activity.timestamp)}
                        {activity.rule && ` • Rule: ${activity.rule}`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </Card>
      </div>
    </div>
  )
}
