"use client"

import { Button } from "@/components/ui/button"
import { Trash2, X, Languages } from 'lucide-react'
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface BatchActionsBarProps {
  selectedCount: number
  onClearSelection: () => void
  onBatchDelete: () => void
  onBatchTranslate?: () => void
}

export function BatchActionsBar({ selectedCount, onClearSelection, onBatchDelete, onBatchTranslate }: BatchActionsBarProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const { toast } = useToast()

  const handleDelete = async () => {
    if (!confirm(`Are you sure you want to delete ${selectedCount} video(s)?`)) {
      return
    }
    
    setIsDeleting(true)
    try {
      await onBatchDelete()
      toast({
        title: "Videos Deleted",
        description: `Successfully deleted ${selectedCount} video(s)`,
      })
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: error instanceof Error ? error.message : "Failed to delete videos",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  if (selectedCount === 0) return null

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-bottom-5">
      <div className="bg-primary text-primary-foreground rounded-full shadow-2xl border-2 border-primary-foreground/20 px-6 py-3 flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-primary-foreground/20 flex items-center justify-center">
            <span className="text-sm font-bold">{selectedCount}</span>
          </div>
          <span className="font-semibold">selected</span>
        </div>
        
        <div className="h-6 w-px bg-primary-foreground/20" />
        
        <div className="flex items-center gap-2">
          {onBatchTranslate && (
            <Button
              onClick={onBatchTranslate}
              variant="secondary"
              size="sm"
              className="gap-2 h-8"
            >
              <Languages className="w-4 h-4" />
              Translate
            </Button>
          )}
          
          <Button
            onClick={handleDelete}
            disabled={isDeleting}
            variant="destructive"
            size="sm"
            className="gap-2 h-8"
          >
            <Trash2 className="w-4 h-4" />
            {isDeleting ? "Deleting..." : "Delete"}
          </Button>
          
          <Button
            onClick={onClearSelection}
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 hover:bg-primary-foreground/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
