"use client"

import type React from "react"
import { useEffect, useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { VideoEditor } from "@/components/video-editor"
import {
  Upload,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Lock,
  Globe,
  Eye,
  ExternalLink,
  Sparkles,
  Film,
  Tag,
  FolderOpen,
  Shield,
  Scissors,
  Trash2,
  ImageIcon,
} from "lucide-react"
import { getUploadDefaults } from "@/lib/upload-defaults"
import { generateSmartLink, generateSmartLinkText } from "@/lib/smart-link"
import { toast } from "@/components/ui/use-toast"
import { QuotaSwitchDialog } from "@/components/quota-switch-dialog"
import { markClientQuotaExceeded, getActiveClient } from "@/lib/client-manager"

interface VideoUploaderProps {
  accessToken: string
}

type PrivacyStatus = "public" | "private" | "unlisted"

export function VideoUploader({ accessToken }: VideoUploaderProps) {
  const [file, setFile] = useState<File | null>(null)
  const [thumbnail, setThumbnail] = useState<File | null>(null)
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [tags, setTags] = useState("")
  const [category, setCategory] = useState("22") // 22 = People & Blogs
  const [privacy, setPrivacy] = useState<PrivacyStatus>("private")
  const [allowComments, setAllowComments] = useState(true)
  const [allowRatings, setAllowRatings] = useState(true)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "success" | "error">("idle")
  const [statusMessage, setStatusMessage] = useState("")
  const [uploadedVideoId, setUploadedVideoId] = useState<string | null>(null)
  const [videoDuration, setVideoDuration] = useState<number | null>(null)
  const [isShort, setIsShort] = useState(false)
  const [showEditor, setShowEditor] = useState(false)
  const [dualUpload, setDualUpload] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<string>("")
  const [customShortsDuration, setCustomShortsDuration] = useState<number>(60)
  const [showQuotaDialog, setShowQuotaDialog] = useState(false)
  const [userEmail, setUserEmail] = useState<string | null>(null)

  const videoPreviewUrl = useMemo(() => {
    if (!file) return null
    return URL.createObjectURL(file)
  }, [file])

  useEffect(() => {
    const fetchUserEmail = async () => {
      try {
        const response = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        })
        if (response.ok) {
          const data = await response.json()
          setUserEmail(data.email)
          console.log("[v0] Loaded user email for video uploader:", data.email)
        }
      } catch (error) {
        console.error("[v0] Failed to fetch user email:", error)
      }
    }
    fetchUserEmail()
  }, [accessToken])

  useEffect(() => {
    const defaults = getUploadDefaults(userEmail || undefined)
    if (defaults) {
      console.log("[v0] Loaded upload defaults for video uploader:", userEmail, defaults)
      setDescription(defaults.description)
      setTags(defaults.tags)
      setCategory(defaults.category)
      setPrivacy(defaults.privacy)
      setAllowComments(defaults.allowComments)
      setAllowRatings(defaults.allowRatings)
    }
  }, [userEmail])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      if (selectedFile.size > 128 * 1024 * 1024) {
        setUploadStatus("error")
        setStatusMessage("File size must be less than 128 MB")
        return
      }
      setFile(selectedFile)
      setUploadStatus("idle")
      setShowEditor(false) // Reset editor state when a new file is selected
    }
  }

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      if (selectedFile.size > 2 * 1024 * 1024) {
        setUploadStatus("error")
        setStatusMessage("Thumbnail must be less than 2 MB")
        return
      }
      setThumbnail(selectedFile)
      setThumbnailPreview(URL.createObjectURL(selectedFile))
    }
  }

  const handleEditComplete = (editedFile: File) => {
    setFile(editedFile)
    setShowEditor(false)
    setUploadStatus("idle") // Reset upload status after editing
  }

  const handleUpload = async () => {
    if (!file || !title) {
      setUploadStatus("error")
      setStatusMessage("Please select a file and enter a title")
      return
    }

    setIsUploading(true)
    setUploadStatus("idle")

    try {
      console.log("[v0] Access token (first 20 chars):", accessToken.substring(0, 20) + "...")
      console.log("[v0] File type:", file.type)
      console.log("[v0] File size:", file.size, "bytes")

      if (dualUpload && videoDuration !== null && videoDuration > 60) {
        setUploadProgress("Creating Shorts version...")

        const ffmpeg = new (await import("@ffmpeg/ffmpeg")).FFmpeg()
        await ffmpeg.load({
          coreURL: await (await import("@ffmpeg/util")).toBlobURL(
            "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js",
            "text/javascript",
          ),
          wasmURL: await (await import("@ffmpeg/util")).toBlobURL(
            "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm",
            "application/wasm",
          ),
        })

        await ffmpeg.writeFile("input.mp4", new Uint8Array(await file.arrayBuffer()))

        const shortsDuration = customShortsDuration
        await ffmpeg.exec([
          "-i",
          "input.mp4",
          "-ss",
          "0",
          "-to",
          shortsDuration.toString(),
          "-vf",
          "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2",
          "-c:v",
          "libx264",
          "-preset",
          "veryfast",
          "-crf",
          "28",
          "-c:a",
          "aac",
          "-b:a",
          "128k",
          "output.mp4",
        ])

        const shortsData = await ffmpeg.readFile("output.mp4")
        const shortsBlob = new Blob([shortsData], { type: "video/mp4" })
        const shortsFile = new File([shortsBlob], `shorts_${file.name}`, { type: "video/mp4" })

        setUploadProgress("Uploading full video...")
        await uploadVideo(file, title, description, tags, false)

        setUploadProgress("Uploading Shorts version...")
        await uploadVideo(shortsFile, `${title} #Shorts`, `${description}\n\n#Shorts`, `${tags},Shorts,Short`, true)

        setUploadStatus("success")
        setStatusMessage("Both full video and Short uploaded successfully!")
      } else {
        await uploadVideo(file, title, description, tags, isShort && videoDuration !== null && videoDuration <= 60)
        setUploadStatus("success")
        setStatusMessage(`Video uploaded successfully as ${privacy}!`)
      }

      if (videoPreviewUrl) {
        URL.revokeObjectURL(videoPreviewUrl)
      }
      if (thumbnailPreview) {
        URL.revokeObjectURL(thumbnailPreview)
      }

      setFile(null)
      setThumbnail(null)
      setThumbnailPreview(null)
      setTitle("")
      setDescription("")
      setTags("")
      setPrivacy("private")
      setAllowComments(true)
      setAllowRatings(true)
      setVideoDuration(null)
      setIsShort(false)
      setDualUpload(false)
      setShowEditor(false)
      setUploadProgress("")
      setCustomShortsDuration(60)
    } catch (error) {
      console.error("[v0] Upload error:", error)
      setUploadStatus("error")
      setStatusMessage(error instanceof Error ? error.message : "Upload failed")
      setUploadedVideoId(null)
      setVideoDuration(null)
      setIsShort(false)
      setDualUpload(false)
      setUploadProgress("")
    } finally {
      setIsUploading(false)
    }
  }

  const uploadVideo = async (
    videoFile: File,
    videoTitle: string,
    videoDescription: string,
    videoTags: string,
    asShort: boolean,
  ) => {
    const parsedTags = videoTags
      .split(",")
      .map((tag) => tag.trim())
      .filter((tag) => tag.length > 0)
      .slice(0, 30)

    const finalTags = asShort
      ? [...parsedTags, "Shorts", "Short"].filter((tag, index, self) => self.indexOf(tag) === index)
      : parsedTags

    const finalTitle = asShort && !videoTitle.includes("#Shorts") ? `${videoTitle} #Shorts` : videoTitle

    const finalDescription =
      asShort && !videoDescription.includes("#Shorts") ? `${videoDescription}\n\n#Shorts` : videoDescription

    const videoMetadata = {
      snippet: {
        title: finalTitle.substring(0, 100),
        description: finalDescription.substring(0, 5000),
        tags: finalTags.length > 0 ? finalTags : undefined,
        categoryId: category,
      },
      status: {
        privacyStatus: privacy,
        selfDeclaredMadeForKids: false,
        embeddable: true,
        publicStatsViewable: true,
      },
    }

    console.log("[v0] Starting upload with metadata:", videoMetadata)
    if (asShort) {
      console.log("[v0] Uploading as YouTube Short - Added #Shorts to title and description")
    }

    const contentType = videoFile.type || "video/mp4"

    const initResponse = await fetch(
      "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json; charset=UTF-8",
          "X-Upload-Content-Length": videoFile.size.toString(),
          "X-Upload-Content-Type": contentType,
        },
        body: JSON.stringify(videoMetadata),
      },
    )

    if (!initResponse.ok) {
      const errorText = await initResponse.text()
      console.error("[v0] Init response status:", initResponse.status)
      console.error("[v0] Init response headers:", Object.fromEntries(initResponse.headers.entries()))
      console.error("[v0] Init response error:", errorText)

      if (
        initResponse.status === 403 ||
        errorText.includes("quotaExceeded") ||
        errorText.includes("exceeded the number of videos")
      ) {
        const activeClient = getActiveClient()
        if (activeClient) {
          markClientQuotaExceeded(activeClient.id)
        }
        setShowQuotaDialog(true)
        throw new Error("Quota exceeded. Please switch to another API client.")
      }

      let errorMessage = `Failed to initialize upload: ${initResponse.status}`

      try {
        const errorJson = JSON.parse(errorText)
        if (errorJson.error?.message) {
          errorMessage = errorJson.error.message
        }
      } catch {
        if (errorText) {
          errorMessage += ` - ${errorText}`
        }
      }

      throw new Error(errorMessage)
    }

    const sessionUri = initResponse.headers.get("location")
    if (!sessionUri) {
      throw new Error("No session URI provided by YouTube API")
    }

    console.log("[v0] Resumable session URI obtained:", sessionUri)

    const uploadResponse = await fetch(sessionUri, {
      method: "PUT",
      headers: {
        "Content-Type": contentType,
      },
      body: videoFile,
    })

    if (!uploadResponse.ok) {
      const errorText = await uploadResponse.text()
      console.error("[v0] Upload response status:", uploadResponse.status)
      console.error("[v0] Upload response error:", errorText)

      if (
        uploadResponse.status === 403 ||
        errorText.includes("quotaExceeded") ||
        errorText.includes("exceeded the number of videos")
      ) {
        const activeClient = getActiveClient()
        if (activeClient) {
          markClientQuotaExceeded(activeClient.id)
        }
        setShowQuotaDialog(true)
        throw new Error("Quota exceeded. Please switch to another API client.")
      }

      let errorMessage = `Video upload failed: ${uploadResponse.status}`

      try {
        const errorJson = JSON.parse(errorText)
        if (errorJson.error?.message) {
          errorMessage = errorJson.error.message
        }
      } catch {
        if (errorText) {
          errorMessage += ` - ${errorText}`
        }
      }

      throw new Error(errorMessage)
    }

    const result = await uploadResponse.json()
    console.log("[v0] Upload successful, video ID:", result.id)
    setUploadedVideoId(result.id)

    const defaults = getUploadDefaults(userEmail || undefined)
    if (defaults?.socialUnlockEnabled && defaults.socialUnlockTargetUrl && result.id) {
      try {
        const channelResponse = await fetch("https://www.googleapis.com/youtube/v3/channels?part=id&mine=true", {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        })

        if (channelResponse.ok) {
          const channelData = await channelResponse.json()
          const channelId = channelData.items?.[0]?.id

          if (channelId) {
            const smartLink = await generateSmartLink({
              videoId: result.id,
              channelId,
              targetUrl: defaults.socialUnlockTargetUrl,
              actions: defaults.socialUnlockActions || { subscribe: true, like: true, comment: false },
            })

            const smartLinkText = generateSmartLinkText(smartLink)
            const updatedDescription = finalDescription + smartLinkText

            const updateResponse = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet`, {
              method: "PUT",
              headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                id: result.id,
                snippet: {
                  ...videoMetadata.snippet, // Use videoMetadata.snippet here
                  title: finalTitle,
                  description: updatedDescription.substring(0, 5000),
                  categoryId: category,
                },
              }),
            })

            if (updateResponse.ok) {
              console.log("[v0] Smart link added to video description")
            } else {
              const updateErrorText = await updateResponse.text()
              console.error("[v0] Failed to update video description with smart link:", updateErrorText)
            }
          }
        } else {
          const channelErrorText = await channelResponse.text()
          console.error("[v0] Failed to fetch channel ID:", channelErrorText)
        }
      } catch (error) {
        console.error("[v0] Error adding smart link:", error)
      }
    }

    if (thumbnail && result.id) {
      console.log("[v0] Thumbnail file detected, uploading...")

      try {
        const thumbnailResponse = await fetch(
          `https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=${result.id}`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${accessToken}`,
              "Content-Type": thumbnail.type,
            },
            body: thumbnail,
          },
        )

        if (thumbnailResponse.ok) {
          const thumbResult = await thumbnailResponse.json()
          console.log("[v0] Thumbnail uploaded successfully:", thumbResult)
          toast({
            title: "Thumbnail Uploaded",
            description: "Custom thumbnail has been set successfully.",
          })
        } else {
          const errorText = await thumbnailResponse.text()
          console.error("[v0] Thumbnail upload failed:", thumbnailResponse.status, errorText)

          if (thumbnailResponse.status === 403) {
            toast({
              title: "Thumbnail Upload Failed - Missing Permission",
              description: "Click 'Re-auth' at the top to grant thumbnail upload permissions.",
              variant: "destructive",
            })
          } else {
            toast({
              title: "Thumbnail Upload Failed",
              description: "Video uploaded but thumbnail failed. Try re-authenticating.",
              variant: "destructive",
            })
          }
        }
      } catch (error) {
        console.error("[v0] Thumbnail upload error:", error)
        toast({
          title: "Thumbnail Upload Error",
          description: "Video uploaded but thumbnail failed. Try re-authenticating.",
          variant: "destructive",
        })
      }
    }
  }

  const privacyOptions: Array<{ value: PrivacyStatus; label: string; icon: React.ReactNode; description: string }> = [
    {
      value: "public",
      label: "Public",
      icon: <Globe className="w-4 h-4" />,
      description: "Everyone can find and watch",
    },
    {
      value: "unlisted",
      label: "Unlisted",
      icon: <Eye className="w-4 h-4" />,
      description: "Only with the link",
    },
    {
      value: "private",
      label: "Private",
      icon: <Lock className="w-4 h-4" />,
      description: "Only you and invited people",
    },
  ]

  const categories = [
    { id: "1", name: "Film & Animation" },
    { id: "2", name: "Autos & Vehicles" },
    { id: "10", name: "Music" },
    { id: "15", name: "Pets & Animals" },
    { id: "17", name: "Sports" },
    { id: "18", name: "Short Movies" },
    { id: "19", name: "Travel & Events" },
    { id: "20", name: "Gaming" },
    { id: "21", name: "Videoblogging" },
    { id: "22", name: "People & Blogs" },
    { id: "23", name: "Comedy" },
    { id: "24", name: "Entertainment" },
    { id: "25", name: "News & Politics" },
    { id: "26", name: "Howto & Style" },
    { id: "27", name: "Education" },
    { id: "28", name: "Science & Technology" },
    { id: "29", name: "Nonprofits & Activism" },
  ]

  if (showEditor && file) {
    return <VideoEditor videoFile={file} onEditComplete={handleEditComplete} onCancel={() => setShowEditor(false)} />
  }

  return (
    <div className="space-y-6">
      <QuotaSwitchDialog
        open={showQuotaDialog}
        onClose={() => setShowQuotaDialog(false)}
        onSwitch={() => {
          toast({
            title: "Client Switched",
            description: "Now using new API client. Try uploading again.",
          })
        }}
      />

      <Card className="p-4 bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-800">
        <div className="space-y-2">
          <p className="text-sm font-semibold text-amber-900 dark:text-amber-100">Getting a 400 error?</p>
          <p className="text-sm text-amber-800 dark:text-amber-200">
            If you're seeing "Failed to initialize upload: 400", try clicking the <strong>Re-auth</strong> button at the
            top to re-authenticate with full upload permissions. This ensures your account has all the necessary scopes.
          </p>
        </div>
      </Card>

      {videoPreviewUrl && (
        <Card className="overflow-hidden border-2">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 p-6 border-b">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Film className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-xl">Video Preview</h3>
                  <p className="text-sm text-muted-foreground">Review how your video will appear</p>
                </div>
              </div>
              <Button onClick={() => setShowEditor(true)} variant="outline" size="sm" className="gap-2">
                <Scissors className="w-4 h-4" />
                Edit Video
              </Button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="relative w-full aspect-video bg-black rounded-lg shadow-lg overflow-hidden">
                  <video
                    src={videoPreviewUrl}
                    controls
                    className="w-full h-full"
                    onLoadedMetadata={(e) => {
                      const videoEl = e.currentTarget
                      const duration = videoEl.duration
                      setVideoDuration(duration)

                      const aspectRatio = videoEl.videoWidth / videoEl.videoHeight
                      console.log(
                        "[v0] Video dimensions:",
                        videoEl.videoWidth,
                        "x",
                        videoEl.videoHeight,
                        "aspect ratio:",
                        aspectRatio.toFixed(2),
                      )

                      if (duration <= 60 && aspectRatio < 1) {
                        setIsShort(true)
                        console.log("[v0] Video qualifies as Short: vertical aspect ratio and ≤60 seconds")
                      } else if (duration <= 60) {
                        console.log(
                          "[v0] Video is ≤60 seconds but NOT vertical (aspect ratio:",
                          aspectRatio.toFixed(2),
                          "). May not display as Short.",
                        )
                      }
                    }}
                  />

                  {thumbnailPreview && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
                      <div className="relative w-full h-full">
                        <img
                          src={thumbnailPreview || "/placeholder.svg"}
                          alt="Thumbnail overlay"
                          className="w-full h-full object-contain"
                        />
                        <div className="absolute top-3 right-3 flex gap-2">
                          <Button
                            onClick={(e) => {
                              e.stopPropagation()
                              document.getElementById("thumbnail-input")?.click()
                            }}
                            variant="secondary"
                            size="sm"
                            className="gap-1.5 bg-white/90 hover:bg-white"
                            disabled={isUploading}
                          >
                            <ImageIcon className="w-3.5 h-3.5" />
                            Change
                          </Button>
                          <Button
                            onClick={(e) => {
                              e.stopPropagation()
                              if (thumbnailPreview) {
                                URL.revokeObjectURL(thumbnailPreview)
                              }
                              setThumbnail(null)
                              setThumbnailPreview(null)
                            }}
                            variant="destructive"
                            size="sm"
                            disabled={isUploading}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                        <div className="absolute bottom-3 left-3 bg-black/80 px-2 py-1 rounded text-xs text-white font-semibold">
                          Custom Thumbnail
                        </div>
                      </div>
                    </div>
                  )}

                  {!thumbnailPreview && (
                    <button
                      onClick={() => document.getElementById("thumbnail-input")?.click()}
                      className="absolute inset-0 flex items-center justify-center bg-transparent hover:bg-black/10 transition-colors group"
                      disabled={isUploading}
                    >
                      <div className="flex items-center gap-2 px-4 py-2 bg-white/90 hover:bg-white rounded-lg shadow-lg transition-all group-hover:scale-105">
                        <ImageIcon className="w-4 h-4" />
                        <span className="font-semibold text-sm">Add Thumbnail</span>
                      </div>
                    </button>
                  )}

                  <input
                    id="thumbnail-input"
                    type="file"
                    accept="image/jpeg,image/png,image/jpg"
                    onChange={handleThumbnailChange}
                    className="hidden"
                    disabled={isUploading}
                  />
                </div>

                {videoDuration !== null && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-white dark:bg-gray-900 rounded-full border shadow-sm">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      <span className="text-sm font-semibold">{Math.round(videoDuration)}s</span>
                    </div>
                    {videoDuration <= 60 && (
                      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full shadow-md text-xs font-bold">
                        <Sparkles className="w-3.5 h-3.5" />
                        Shorts Eligible
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="bg-white dark:bg-gray-900 rounded-lg p-4 shadow-sm border">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="p-1.5 bg-blue-100 dark:bg-blue-900 rounded">
                      <Film className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground mb-1">Title</p>
                      <p className="font-semibold text-sm leading-snug break-words">{title || "No title set"}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white dark:bg-gray-900 rounded-lg p-4 shadow-sm border">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="p-1.5 bg-green-100 dark:bg-green-900 rounded">
                      <Tag className="w-4 h-4 text-green-600 dark:text-green-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground mb-1">Description</p>
                      <p className="text-sm text-muted-foreground leading-relaxed break-words line-clamp-3">
                        {description || "No description"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white dark:bg-gray-900 rounded-lg p-3 shadow-sm border">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1 bg-purple-100 dark:bg-purple-900 rounded">
                        <FolderOpen className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                      </div>
                      <p className="text-xs text-muted-foreground">Category</p>
                    </div>
                    <p className="text-sm font-semibold">
                      {categories.find((cat) => cat.id === category)?.name || "Unknown"}
                    </p>
                  </div>

                  <div className="bg-white dark:bg-gray-900 rounded-lg p-3 shadow-sm border">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1 bg-amber-100 dark:bg-amber-900 rounded">
                        <Shield className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                      </div>
                      <p className="text-xs text-muted-foreground">Privacy</p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {privacy === "public" && <Globe className="w-3.5 h-3.5" />}
                      {privacy === "unlisted" && <Eye className="w-3.5 h-3.5" />}
                      {privacy === "private" && <Lock className="w-3.5 h-3.5" />}
                      <p className="text-sm font-semibold capitalize">{privacy}</p>
                    </div>
                  </div>
                </div>

                {tags && (
                  <div className="bg-white dark:bg-gray-900 rounded-lg p-3 shadow-sm border">
                    <p className="text-xs text-muted-foreground mb-2">Tags</p>
                    <div className="flex flex-wrap gap-1.5">
                      {tags
                        .split(",")
                        .slice(0, 5)
                        .map((tag, index) => (
                          <span
                            key={index}
                            className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-xs rounded-full"
                          >
                            {tag.trim()}
                          </span>
                        ))}
                      {tags.split(",").length > 5 && (
                        <span className="px-2 py-0.5 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs rounded-full">
                          +{tags.split(",").length - 5} more
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </Card>
      )}

      <Card className="p-8">
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold mb-2">Upload Video to Your Channel</h2>
            <p className="text-muted-foreground">
              Configure your video settings before uploading. Choose privacy level, add tags, and customize permissions.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-semibold mb-2 block">Select Video File</label>
              <div
                className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
                onClick={() => document.getElementById("file-input")?.click()}
              >
                <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold mb-1">{file ? file.name : "Click to select video or drag and drop"}</p>
                <p className="text-sm text-muted-foreground">MP4, WebM, or other formats. Maximum 128 MB.</p>
                <input
                  id="file-input"
                  type="file"
                  accept="video/*"
                  onChange={handleFileChange}
                  className="hidden"
                  disabled={isUploading}
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Video Title</label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter video title"
                disabled={isUploading}
              />
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Description (Optional)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter video description"
                className="w-full p-3 border border-border rounded-md bg-background text-foreground disabled:opacity-50"
                rows={4}
                disabled={isUploading}
              />
            </div>

            {videoDuration !== null && videoDuration <= 60 && (
              <div className="p-4 bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800 rounded-lg">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isShort}
                    onChange={(e) => setIsShort(e.target.checked)}
                    disabled={isUploading}
                    className="rounded w-4 h-4 mt-0.5"
                  />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span className="text-sm font-semibold">Upload as YouTube Short</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      This video is {Math.round(videoDuration)} seconds long and can be uploaded as a Short. Shorts
                      appear in the Shorts feed and get more discovery.
                    </p>
                  </div>
                </label>
              </div>
            )}

            {videoDuration !== null && videoDuration > 60 && (
              <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-2 border-purple-200 dark:border-purple-800 rounded-lg space-y-4">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dualUpload}
                    onChange={(e) => setDualUpload(e.target.checked)}
                    disabled={isUploading}
                    className="rounded w-4 h-4 mt-0.5"
                  />
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                      <span className="text-sm font-semibold">Upload to Both Video & Shorts</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Upload the full {Math.round(videoDuration)}s video AND automatically create a vertical Shorts
                      version. Get double the reach!
                    </p>
                  </div>
                </label>
                {dualUpload && (
                  <div className="pl-7 space-y-3">
                    <div className="p-3 bg-white dark:bg-gray-900 rounded-lg border border-purple-200 dark:border-purple-800">
                      <label className="text-xs font-semibold mb-2 block text-purple-900 dark:text-purple-100">
                        Shorts Video Length (seconds)
                      </label>
                      <div className="flex items-center gap-3">
                        <input
                          type="range"
                          min="58"
                          max="60"
                          step="1"
                          value={customShortsDuration}
                          onChange={(e) => setCustomShortsDuration(Number(e.target.value))}
                          disabled={isUploading}
                          className="flex-1"
                        />
                        <div className="flex items-center gap-1 px-3 py-1.5 bg-purple-100 dark:bg-purple-900 rounded-full border border-purple-300 dark:border-purple-700">
                          <span className="text-sm font-bold text-purple-700 dark:text-purple-300">
                            {customShortsDuration}s
                          </span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        Choose how long your Short will be. Recommended: 58-60 seconds for maximum engagement.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div>
              <label className="text-sm font-semibold mb-2 block">Tags (Optional)</label>
              <Input
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="Enter tags separated by commas (e.g. vlog, travel, music)"
                disabled={isUploading}
              />
              <p className="text-xs text-muted-foreground mt-1">Maximum 30 tags</p>
            </div>

            <div>
              <label className="text-sm font-semibold mb-2 block">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                disabled={isUploading}
                className="w-full p-3 border border-border rounded-md bg-background text-foreground disabled:opacity-50"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border">
              <label className="text-sm font-semibold block">Privacy Settings</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {privacyOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setPrivacy(option.value)}
                    disabled={isUploading}
                    className={`p-3 rounded-lg border-2 transition-all text-left ${
                      privacy === option.value
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    } disabled:opacity-50`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {option.icon}
                      <span className="font-semibold text-sm">{option.label}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{option.description}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 p-4 bg-muted/30 rounded-lg border border-border">
              <label className="text-sm font-semibold block">Viewer Permissions</label>
              <div className="space-y-2">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowComments}
                    onChange={(e) => setAllowComments(e.target.checked)}
                    disabled={isUploading}
                    className="rounded w-4 h-4"
                  />
                  <span className="text-sm">Allow comments</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowRatings}
                    onChange={(e) => setAllowRatings(e.target.checked)}
                    disabled={isUploading}
                    className="rounded w-4 h-4"
                  />
                  <span className="text-sm">Show like/dislike</span>
                </label>
              </div>
            </div>

            {uploadStatus === "success" && (
              <div className="space-y-3 p-4 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0" />
                  <p className="text-sm font-semibold text-green-800 dark:text-green-200">{statusMessage}</p>
                </div>
                {uploadedVideoId && (
                  <div className="space-y-2">
                    <a
                      href={`https://www.youtube.com/watch?v=${uploadedVideoId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-green-700 dark:text-green-300 hover:underline font-medium"
                    >
                      <ExternalLink className="w-4 h-4" />
                      View on YouTube
                    </a>
                    <a
                      href={`https://studio.youtube.com/video/${uploadedVideoId}/edit`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-green-700 dark:text-green-300 hover:underline"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Edit in YouTube Studio
                    </a>
                    <p className="text-xs text-green-700 dark:text-green-300">
                      Video ID:{" "}
                      <code className="bg-green-100 dark:bg-green-900 px-1 py-0.5 rounded">{uploadedVideoId}</code>
                    </p>
                    {privacy === "private" && (
                      <p className="text-xs text-green-700 dark:text-green-300 mt-2">
                        Your video is <strong>private</strong>. Change it to public or unlisted in YouTube Studio to
                        share it with others.
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            {uploadStatus === "error" && (
              <div className="flex items-center gap-3 p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
                <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
                <p className="text-sm text-red-800 dark:text-red-200">{statusMessage}</p>
              </div>
            )}

            <Button onClick={handleUpload} disabled={!file || !title || isUploading} className="w-full gap-2" size="lg">
              {isUploading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {uploadProgress || "Uploading..."}
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  {dualUpload ? "Upload Both Versions" : "Upload Video"}
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-4 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
        <p className="text-sm text-blue-800 dark:text-blue-200">
          <strong>Note:</strong> Make sure you're authenticated with the YouTube account that owns @COMBO_WICK channel.
        </p>
      </Card>
    </div>
  )
}
