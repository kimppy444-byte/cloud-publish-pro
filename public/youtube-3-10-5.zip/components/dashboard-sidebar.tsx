"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  LayoutDashboard,
  Upload,
  FolderUp,
  Calendar,
  Search,
  Users,
  Settings,
  BarChart3,
  Key,
  FileVideo,
  ChevronLeft,
  ChevronRight,
  Youtube,
  Plus,
  LogOut,
  Facebook,
  Instagram,
} from "lucide-react"
import { type MultiAccountToken, initiateOAuthFlow, removeToken } from "@/lib/youtube-auth"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type TabType =
  | "overview"
  | "search"
  | "channel"
  | "upload"
  | "bulk-upload"
  | "accounts"
  | "analytics"
  | "defaults"
  | "clients"
  | "scheduled"
  | "facebook" // Added facebook tab type
  | "instagram" // Added instagram tab type
  | string

interface DashboardSidebarProps {
  activeTab: TabType
  onTabChange: (tab: TabType) => void
  accounts: MultiAccountToken[]
  isCollapsed: boolean
  onToggleCollapse: () => void
}

const mainNavItems = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "search", label: "Search", icon: Search },
]

const socialNavItems = [
  { id: "facebook", label: "Facebook & IG", icon: Facebook },
  { id: "instagram", label: "IG Auto-Reply", icon: Instagram },
]

const uploadNavItems = [
  { id: "upload", label: "Upload Video", icon: Upload },
  { id: "bulk-upload", label: "Bulk Upload", icon: FolderUp },
  { id: "scheduled", label: "Scheduled", icon: Calendar },
]

const settingsNavItems = [
  { id: "accounts", label: "Accounts", icon: Users },
  { id: "defaults", label: "Upload Defaults", icon: FileVideo },
  { id: "clients", label: "API Clients", icon: Key },
  { id: "channel", label: "Settings", icon: Settings },
]

export function DashboardSidebar({
  activeTab,
  onTabChange,
  accounts,
  isCollapsed,
  onToggleCollapse,
}: DashboardSidebarProps) {
  const [currentAccount, setCurrentAccount] = useState<MultiAccountToken | null>(null)

  useEffect(() => {
    if (accounts.length > 0 && !currentAccount) {
      setCurrentAccount(accounts[0])
    }
  }, [accounts, currentAccount])

  const handleSignOut = () => {
    removeToken()
    window.location.reload()
  }

  const NavItem = ({ item, isActive }: { item: (typeof mainNavItems)[0]; isActive: boolean }) => (
    <Button
      variant={isActive ? "secondary" : "ghost"}
      className={cn(
        "w-full justify-start gap-3 h-10",
        isCollapsed && "justify-center px-2",
        isActive && "bg-accent text-accent-foreground font-medium",
      )}
      onClick={() => onTabChange(item.id)}
    >
      <item.icon className={cn("h-4 w-4 shrink-0", isActive && "text-primary")} />
      {!isCollapsed && <span>{item.label}</span>}
    </Button>
  )

  return (
    <aside
      className={cn(
        "flex flex-col border-r border-border bg-sidebar h-screen sticky top-0 transition-all duration-300",
        isCollapsed ? "w-16" : "w-64",
      )}
    >
      {/* Logo Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-sidebar-border">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary">
              <Youtube className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-sm">Creator Studio</span>
          </div>
        )}
        {isCollapsed && (
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary mx-auto">
            <Youtube className="w-4 h-4 text-primary-foreground" />
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          className={cn("h-8 w-8 shrink-0", isCollapsed && "absolute -right-3 bg-card border shadow-sm")}
          onClick={onToggleCollapse}
        >
          {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      {/* Account Selector */}
      {currentAccount && (
        <div className="p-3 border-b border-sidebar-border">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className={cn("w-full h-auto p-2 justify-start gap-3", isCollapsed && "justify-center p-2")}
              >
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarImage src={currentAccount.picture || "/placeholder.svg"} />
                  <AvatarFallback className="bg-primary/10 text-primary text-xs">
                    {currentAccount.name?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                {!isCollapsed && (
                  <div className="flex flex-col items-start min-w-0">
                    <span className="text-sm font-medium truncate w-full">{currentAccount.name}</span>
                    <span className="text-xs text-muted-foreground truncate w-full">{currentAccount.email}</span>
                  </div>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64">
              <DropdownMenuLabel>Switch Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {accounts.map((account) => (
                <DropdownMenuItem key={account.email} onClick={() => setCurrentAccount(account)} className="gap-3">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={account.picture || "/placeholder.svg"} />
                    <AvatarFallback className="text-xs">{account.name?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col min-w-0">
                    <span className="text-sm truncate">{account.name}</span>
                    <span className="text-xs text-muted-foreground truncate">{account.email}</span>
                  </div>
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => initiateOAuthFlow()} className="gap-2">
                <Plus className="h-4 w-4" />
                Add Account
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleSignOut} className="gap-2 text-destructive">
                <LogOut className="h-4 w-4" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3 py-4">
        <div className="space-y-6">
          {/* Main Navigation */}
          <div className="space-y-1">
            {!isCollapsed && <p className="text-xs font-medium text-muted-foreground px-3 mb-2">MAIN</p>}
            {mainNavItems.map((item) => (
              <NavItem key={item.id} item={item} isActive={activeTab === item.id} />
            ))}
          </div>

          <div className="space-y-1">
            {!isCollapsed && <p className="text-xs font-medium text-muted-foreground px-3 mb-2">SOCIAL</p>}
            {socialNavItems.map((item) => (
              <NavItem key={item.id} item={item} isActive={activeTab === item.id} />
            ))}
          </div>

          {/* Account Videos - Dynamic */}
          {accounts.length > 0 && (
            <div className="space-y-1">
              {!isCollapsed && <p className="text-xs font-medium text-muted-foreground px-3 mb-2">MY CHANNELS</p>}
              {accounts.map((account) => (
                <Button
                  key={account.email}
                  variant={activeTab === `my-videos-${account.email}` ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-3 h-10",
                    isCollapsed && "justify-center px-2",
                    activeTab === `my-videos-${account.email}` && "bg-accent font-medium",
                  )}
                  onClick={() => onTabChange(`my-videos-${account.email}`)}
                >
                  <Avatar className="h-5 w-5 shrink-0">
                    <AvatarImage src={account.picture || "/placeholder.svg"} />
                    <AvatarFallback className="text-[10px]">{account.name?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>
                  {!isCollapsed && <span className="truncate">{account.name || account.email.split("@")[0]}</span>}
                </Button>
              ))}
            </div>
          )}

          {/* Upload Section */}
          <div className="space-y-1">
            {!isCollapsed && <p className="text-xs font-medium text-muted-foreground px-3 mb-2">UPLOAD</p>}
            {uploadNavItems.map((item) => (
              <NavItem key={item.id} item={item} isActive={activeTab === item.id} />
            ))}
          </div>

          {/* Settings Section */}
          <div className="space-y-1">
            {!isCollapsed && <p className="text-xs font-medium text-muted-foreground px-3 mb-2">SETTINGS</p>}
            {settingsNavItems.map((item) => (
              <NavItem key={item.id} item={item} isActive={activeTab === item.id} />
            ))}
          </div>
        </div>
      </ScrollArea>
    </aside>
  )
}
