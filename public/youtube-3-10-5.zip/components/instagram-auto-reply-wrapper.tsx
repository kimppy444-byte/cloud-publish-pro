"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Instagram, Facebook, ExternalLink, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { InstagramAutoReplyManager } from "@/components/instagram-auto-reply-manager"

interface FacebookPage {
  id: string
  name: string
  access_token: string
  instagram_business_account?: { id: string }
}

interface InstagramAccount {
  id: string
  username?: string
  profile_picture_url?: string
  pageAccessToken: string
}

export function InstagramAutoReplyWrapper() {
  const [accessToken, setAccessToken] = useState("")
  const [isConnected, setIsConnected] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [pages, setPages] = useState<FacebookPage[]>([])
  const [selectedPage, setSelectedPage] = useState<FacebookPage | null>(null)
  const [instagramAccount, setInstagramAccount] = useState<InstagramAccount | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const saved = localStorage.getItem("fb_access_token")
    if (saved) {
      setAccessToken(saved)
      // Auto-connect if we have a saved token
      connectWithToken(saved)
    }
  }, [])

  const connectWithToken = async (token: string) => {
    setIsLoading(true)
    try {
      const res = await fetch(
        `https://graph.facebook.com/v19.0/me/accounts?access_token=${token}&fields=id,name,access_token,instagram_business_account`,
      )
      const data = await res.json()

      if (data.error) {
        throw new Error(data.error.message)
      }

      if (data.data && data.data.length > 0) {
        setPages(data.data)

        // Find a page with Instagram connected
        const pageWithIG = data.data.find((p: FacebookPage) => p.instagram_business_account)
        if (pageWithIG) {
          setSelectedPage(pageWithIG)
          await loadInstagramAccount(pageWithIG)
        } else {
          setSelectedPage(data.data[0])
        }

        setIsConnected(true)
        localStorage.setItem("fb_access_token", token)
      }
    } catch (error: any) {
      console.error("Connection failed:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const connectFacebook = async () => {
    if (!accessToken.trim()) {
      toast({ title: "Error", description: "Please enter your access token", variant: "destructive" })
      return
    }
    await connectWithToken(accessToken)
  }

  const loadInstagramAccount = async (page: FacebookPage) => {
    if (!page.instagram_business_account) return

    try {
      const res = await fetch(
        `https://graph.facebook.com/v19.0/${page.instagram_business_account.id}?access_token=${page.access_token}&fields=id,username,profile_picture_url`,
      )
      const data = await res.json()

      if (!data.error) {
        setInstagramAccount({
          ...data,
          pageAccessToken: page.access_token,
        })
      }
    } catch (error) {
      console.error("Failed to load Instagram account:", error)
    }
  }

  const handlePageChange = async (pageId: string) => {
    const page = pages.find((p) => p.id === pageId)
    if (page) {
      setSelectedPage(page)
      if (page.instagram_business_account) {
        await loadInstagramAccount(page)
      } else {
        setInstagramAccount(null)
      }
    }
  }

  if (!isConnected) {
    return (
      <div className="max-w-xl mx-auto">
        <Card className="p-8">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400 mb-4">
              <Instagram className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Connect Instagram</h2>
            <p className="text-muted-foreground">
              Connect your Instagram Business Account to set up auto-replies for comments.
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fb-token">Facebook Page Access Token</Label>
              <Input
                id="fb-token"
                type="password"
                placeholder="Paste your access token here..."
                value={accessToken}
                onChange={(e) => setAccessToken(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                You need a Facebook Page with an Instagram Business Account connected.
              </p>
            </div>

            <Button onClick={connectFacebook} disabled={isLoading} className="w-full gap-2">
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Facebook className="w-4 h-4" />}
              Connect Facebook
            </Button>

            <div className="text-center">
              <a
                href="https://developers.facebook.com/tools/explorer/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-primary hover:underline inline-flex items-center gap-1"
              >
                Get Access Token from Graph API Explorer
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          <div className="mt-6 p-4 bg-muted rounded-lg">
            <h4 className="font-medium mb-2">Required Permissions:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• instagram_basic</li>
              <li>• instagram_manage_comments</li>
              <li>• instagram_manage_messages (for DMs)</li>
              <li>• pages_show_list</li>
              <li>• pages_read_engagement</li>
            </ul>
          </div>
        </Card>
      </div>
    )
  }

  // Show page selector if multiple pages with Instagram
  const pagesWithInstagram = pages.filter((p) => p.instagram_business_account)

  return (
    <div className="space-y-6">
      {/* Page Selector */}
      {pagesWithInstagram.length > 1 && (
        <Card className="p-4">
          <div className="flex items-center gap-4">
            <Label>Select Page:</Label>
            <select
              className="flex h-10 w-full max-w-xs rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={selectedPage?.id || ""}
              onChange={(e) => handlePageChange(e.target.value)}
            >
              {pagesWithInstagram.map((page) => (
                <option key={page.id} value={page.id}>
                  {page.name}
                </option>
              ))}
            </select>
          </div>
        </Card>
      )}

      {/* No Instagram Connected Warning */}
      {selectedPage && !selectedPage.instagram_business_account && (
        <Card className="p-6 bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800">
          <div className="flex items-start gap-3">
            <Instagram className="w-5 h-5 text-yellow-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-yellow-800 dark:text-yellow-200">No Instagram Account Connected</h4>
              <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                The selected Facebook page doesn't have an Instagram Business Account connected. Please select a
                different page or connect Instagram to your Facebook page.
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Instagram Auto-Reply Manager */}
      {instagramAccount && selectedPage && (
        <InstagramAutoReplyManager instagramAccount={instagramAccount} pageAccessToken={selectedPage.access_token} />
      )}
    </div>
  )
}
