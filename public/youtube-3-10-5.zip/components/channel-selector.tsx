"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { fetchAllChannels, getAllStoredTokens } from "@/lib/youtube-auth"
import { AlertCircle, Loader2 } from "lucide-react"

interface Channel {
  id: string
  snippet: {
    title: string
    description: string
    thumbnails: {
      default: { url: string }
    }
  }
  statistics: {
    videoCount: string
    subscriberCount: string
  }
  accountEmail?: string
}

interface ChannelSelectorProps {
  selectedChannels: string[]
  onChannelsChange: (channelIds: string[]) => void
}

export function ChannelSelector({ selectedChannels, onChannelsChange }: ChannelSelectorProps) {
  const [channels, setChannels] = useState<Channel[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadChannels = async () => {
      try {
        setIsLoading(true)
        setError(null)

        const tokens = getAllStoredTokens()

        if (tokens.length === 0) {
          setError("No accounts connected. Please sign in with at least one YouTube account.")
          setChannels([])
          return
        }

        const allChannels: Channel[] = []

        for (const token of tokens) {
          try {
            const fetchedChannels = await fetchAllChannels(token.access_token)
            const channelsWithEmail = fetchedChannels.map((ch: Channel) => ({
              ...ch,
              accountEmail: token.email,
            }))
            allChannels.push(...channelsWithEmail)
          } catch (err) {
            console.error(`[v0] Failed to fetch channels for ${token.email}:`, err)
          }
        }

        setChannels(allChannels)

        if (allChannels.length > 0 && selectedChannels.length === 0) {
          onChannelsChange([allChannels[0].id])
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load channels")
      } finally {
        setIsLoading(false)
      }
    }

    loadChannels()
  }, [selectedChannels.length, onChannelsChange])

  const toggleChannel = (channelId: string) => {
    const updated = selectedChannels.includes(channelId)
      ? selectedChannels.filter((id) => id !== channelId)
      : [...selectedChannels, channelId]
    onChannelsChange(updated)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    )
  }

  if (error) {
    return (
      <Card className="p-4 bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-red-900 dark:text-red-100">Failed to load channels</p>
            <p className="text-sm text-red-800 dark:text-red-200">{error}</p>
          </div>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold mb-3">Select Channels to Upload To</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Choose which channels you want to upload your video(s) to. You can select channels from any connected account.
        </p>
      </div>

      <div className="space-y-2">
        {channels.map((channel) => (
          <Card
            key={`${channel.accountEmail}-${channel.id}`}
            className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
          >
            <label className="flex items-start gap-3 cursor-pointer">
              <Checkbox
                checked={selectedChannels.includes(channel.id)}
                onCheckedChange={() => toggleChannel(channel.id)}
                className="mt-1"
              />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{channel.snippet.title}</p>
                <p className="text-xs text-muted-foreground">
                  {channel.statistics.videoCount} videos • {channel.statistics.subscriberCount} subscribers
                </p>
                <p className="text-xs text-muted-foreground mt-1">{channel.accountEmail}</p>
              </div>
            </label>
          </Card>
        ))}
      </div>

      {selectedChannels.length === 0 && (
        <Card className="p-4 bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-800">
          <p className="text-sm text-amber-800 dark:text-amber-200">Select at least one channel to upload to</p>
        </Card>
      )}
    </div>
  )
}
