import { shortenUrl } from "./url-shortener"

export interface SmartLinkData {
  videoId: string
  channelId: string
  targetUrl: string
  actions: {
    subscribe: boolean
    like: boolean
    comment: boolean
  }
}

export async function generateSmartLink(
  data: SmartLinkData,
  baseUrl: string = window.location.origin,
): Promise<string> {
  // Create action mask: subscribe=1, like=2, comment=4
  let mask = 0
  if (data.actions.subscribe) mask |= 1
  if (data.actions.like) mask |= 2
  if (data.actions.comment) mask |= 4

  const compactChannelId = data.channelId.startsWith("UC") ? data.channelId.slice(2) : data.channelId

  // Encode as [mask, channelId, targetUrl]
  const payload = [mask, compactChannelId, data.targetUrl]
  const encoded = btoa(JSON.stringify(payload)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")

  const longUrl = `${baseUrl}/u/${data.videoId}?d=${encoded}`

  const shortUrl = await shortenUrl(longUrl)
  return shortUrl
}

export function generateSmartLinkText(smartLink: string): string {
  return `\n\n━━━━━━━━━━━━━━━━━━━━\n🎁 UNLOCK EXCLUSIVE CONTENT\n${smartLink}\n━━━━━━━━━━━━━━━━━━━━`
}
