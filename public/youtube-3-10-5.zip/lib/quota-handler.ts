import { switchToNextClient, markClientQuotaExceeded, getActiveClient } from './client-manager'

export interface QuotaError {
  isQuotaError: boolean
  message: string
  shouldRetry: boolean
}

export function detectQuotaError(error: any): QuotaError {
  // Check if it's a quota exceeded error from YouTube API
  const errorMessage = typeof error === 'string' ? error : error?.message || ''
  const errorString = JSON.stringify(error).toLowerCase()
  
  const quotaKeywords = [
    'quotaexceeded',
    'quota exceeded',
    'daily limit exceeded',
    'rate limit exceeded',
    'insufficient tokens',
    'usagelimits',
  ]
  
  const isQuotaError = quotaKeywords.some(keyword => 
    errorString.includes(keyword) || errorMessage.toLowerCase().includes(keyword)
  )
  
  // Also check for 403 status code which often indicates quota issues
  const is403 = errorString.includes('"status":403') || errorString.includes('status: 403')
  
  return {
    isQuotaError: isQuotaError || is403,
    message: isQuotaError 
      ? 'API quota limit reached for this client'
      : is403 
        ? 'Request forbidden - possible quota limit'
        : errorMessage,
    shouldRetry: isQuotaError || is403
  }
}

export function handleQuotaError(): { switched: boolean; newClient: string | null } {
  const currentClient = getActiveClient()
  if (!currentClient) {
    return { switched: false, newClient: null }
  }
  
  // Mark current client as quota exceeded
  markClientQuotaExceeded(currentClient.id)
  
  // Try to switch to next client
  const nextClient = switchToNextClient()
  
  if (nextClient && nextClient.id !== currentClient.id) {
    return { switched: true, newClient: nextClient.label }
  }
  
  return { switched: false, newClient: null }
}

// Get auto-switch preference from localStorage
const AUTO_SWITCH_KEY = "youtube_auto_switch_on_quota"

export function getAutoSwitchPreference(): boolean {
  const stored = localStorage.getItem(AUTO_SWITCH_KEY)
  return stored === 'true' // Default to false if not set
}

export function setAutoSwitchPreference(enabled: boolean) {
  localStorage.setItem(AUTO_SWITCH_KEY, enabled.toString())
}
