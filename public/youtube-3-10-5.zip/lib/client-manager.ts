interface ClientConfig {
  id: string
  clientId: string
  label: string
}

function loadClientIdsFromEnv(): ClientConfig[] {
  const clients: ClientConfig[] = []
  
  const envVars = [
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_1', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_1 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_2', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_2 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_3', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_3 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_4', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_4 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_5', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_5 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_6', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_6 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_7', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_7 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_8', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_8 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_9', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_9 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_10', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_10 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_11', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_11 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_12', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_12 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_13', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_13 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_14', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_14 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_15', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_15 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_16', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_16 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_17', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_17 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_18', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_18 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_19', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_19 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_20', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_20 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_21', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_21 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_22', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_22 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_23', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_23 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_24', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_24 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_25', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_25 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_26', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_26 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_27', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_27 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_28', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_28 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_29', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_29 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_30', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_30 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_31', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_31 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_32', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_32 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_33', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_33 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_34', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_34 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_35', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_35 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_36', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_36 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_37', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_37 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_38', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_38 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_39', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_39 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_40', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_40 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_41', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_41 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_42', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_42 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_43', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_43 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_44', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_44 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_45', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_45 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_46', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_46 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_47', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_47 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_48', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_48 },
    { key: 'NEXT_PUBLIC_GOOGLE_CLIENT_ID_49', value: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID_49 },
  ]
  
  envVars.forEach((envVar, index) => {
    if (envVar.value && envVar.value.trim()) {
      clients.push({
        id: index === 0 ? 'client-default' : `client-${index}`,
        clientId: envVar.value.trim(),
        label: index === 0 ? 'Default Client' : `Client ${index}`
      })
    }
  })
  
  console.log('[v0] Loaded', clients.length, 'API clients from environment variables')
  
  return clients
}

const ACTIVE_CLIENT_KEY = "youtube_active_client"
const QUOTA_EXCEEDED_KEY = "youtube_quota_exceeded"

export type { ClientConfig }

export function getAllClients(): ClientConfig[] {
  return loadClientIdsFromEnv()
}

export function getActiveClient(): ClientConfig | null {
  const clients = getAllClients()
  if (clients.length === 0) return null
  
  const activeId = localStorage.getItem(ACTIVE_CLIENT_KEY)
  
  if (activeId) {
    const client = clients.find(c => c.id === activeId)
    if (client) return client
  }
  
  // Return first client by default
  return clients[0]
}

export function getActiveClientId(): string {
  const activeClient = getActiveClient()
  return activeClient?.clientId || process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || ''
}

export function setActiveClient(clientId: string) {
  localStorage.setItem(ACTIVE_CLIENT_KEY, clientId)
}

export function switchToNextClient(): ClientConfig | null {
  const clients = getAllClients()
  if (clients.length <= 1) return null
  
  const currentClient = getActiveClient()
  if (!currentClient) return null
  
  const currentIndex = clients.findIndex(c => c.id === currentClient.id)
  const nextIndex = (currentIndex + 1) % clients.length
  const nextClient = clients[nextIndex]
  
  setActiveClient(nextClient.id)
  return nextClient
}

export function markClientQuotaExceeded(clientId: string) {
  const exceeded = getQuotaExceededClients()
  if (!exceeded.includes(clientId)) {
    exceeded.push(clientId)
    localStorage.setItem(QUOTA_EXCEEDED_KEY, JSON.stringify(exceeded))
  }
}

export function getQuotaExceededClients(): string[] {
  const stored = localStorage.getItem(QUOTA_EXCEEDED_KEY)
  if (!stored) return []
  try {
    return JSON.parse(stored)
  } catch {
    return []
  }
}

export function clearQuotaExceeded() {
  localStorage.removeItem(QUOTA_EXCEEDED_KEY)
}

export function isClientQuotaExceeded(clientId: string): boolean {
  return getQuotaExceededClients().includes(clientId)
}
