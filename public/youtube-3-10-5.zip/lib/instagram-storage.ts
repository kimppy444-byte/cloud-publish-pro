// Instagram auto-reply storage utilities
export interface InstagramAutoReplyRule {
  id: string
  keyword: string // The trigger keyword (case-insensitive)
  replyMessage: string // The auto-reply message
  enabled: boolean
  createdAt: number
  matchCount: number // How many times this rule has matched
  lastMatchAt?: number
  instagramAccountId: string // Which IG account this rule belongs to
  pageAccessToken?: string // Store for webhook processing
}

export interface RepliedComment {
  commentId: string
  ruleId: string
  repliedAt: number
  userId: string
}

const STORAGE_KEY = "instagram_auto_reply_rules"
const REPLIED_COMMENTS_KEY = "instagram_auto_replied_comments"

export function getInstagramAutoReplyRules(): InstagramAutoReplyRule[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem(STORAGE_KEY)
  if (!stored) return []
  try {
    return JSON.parse(stored)
  } catch {
    return []
  }
}

export function getInstagramAutoReplyRulesForAccount(accountId: string): InstagramAutoReplyRule[] {
  return getInstagramAutoReplyRules().filter((rule) => rule.instagramAccountId === accountId)
}

export function saveInstagramAutoReplyRule(rule: InstagramAutoReplyRule): void {
  if (typeof window === "undefined") return
  const rules = getInstagramAutoReplyRules()
  const index = rules.findIndex((r) => r.id === rule.id)
  if (index >= 0) {
    rules[index] = rule
  } else {
    rules.push(rule)
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rules))
}

export function deleteInstagramAutoReplyRule(ruleId: string): void {
  if (typeof window === "undefined") return
  const rules = getInstagramAutoReplyRules()
  const filtered = rules.filter((r) => r.id !== ruleId)
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered))
}

export function generateInstagramRuleId(): string {
  return `ig_rule_${Date.now()}_${Math.random().toString(36).substring(7)}`
}

export function updateInstagramRuleMatchCount(ruleId: string): void {
  if (typeof window === "undefined") return
  const rules = getInstagramAutoReplyRules()
  const rule = rules.find((r) => r.id === ruleId)
  if (rule) {
    rule.matchCount = (rule.matchCount || 0) + 1
    rule.lastMatchAt = Date.now()
    saveInstagramAutoReplyRule(rule)
  }
}

// Replied comments tracking
export function getRepliedComments(): RepliedComment[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem(REPLIED_COMMENTS_KEY)
  if (!stored) return []
  try {
    return JSON.parse(stored)
  } catch {
    return []
  }
}

export function hasRepliedToInstagramComment(commentId: string): boolean {
  const replied = getRepliedComments()
  return replied.some((r) => r.commentId === commentId)
}

export function hasRepliedToInstagramUser(userId: string, ruleId: string): boolean {
  const replied = getRepliedComments()
  // Check if we DMed this user for this rule in the last 24 hours
  const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000
  return replied.some((r) => r.userId === userId && r.ruleId === ruleId && r.repliedAt > oneDayAgo)
}

export function markInstagramCommentAsReplied(commentId: string, ruleId: string, userId: string): void {
  if (typeof window === "undefined") return
  const replied = getRepliedComments()
  replied.push({
    commentId,
    ruleId,
    repliedAt: Date.now(),
    userId,
  })
  // Keep only last 1000 entries
  const trimmed = replied.slice(-1000)
  localStorage.setItem(REPLIED_COMMENTS_KEY, JSON.stringify(trimmed))
}
