// Utility to shorten URLs using the external API

export async function shortenUrl(longUrl: string, customAlias?: string): Promise<string> {
  try {
    const response = await fetch("https://jearflqiuwzjdzrnnjyk.supabase.co/functions/v1/shorten-url", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: longUrl,
        ...(customAlias && { customAlias }),
      }),
    })

    if (!response.ok) {
      console.error("[v0] URL shortening failed:", response.statusText)
      // Fallback to original URL if shortening fails
      return longUrl
    }

    const data = await response.json()
    return data.shortUrl || longUrl
  } catch (error) {
    console.error("[v0] Error shortening URL:", error)
    // Fallback to original URL if shortening fails
    return longUrl
  }
}
