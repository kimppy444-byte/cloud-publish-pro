export interface UploadDefaults {
  description: string
  tags: string
  category: string
  privacy: "public" | "private" | "unlisted"
  allowComments: boolean
  allowRatings: boolean
  socialUnlockEnabled?: boolean
  socialUnlockTargetUrl?: string
  socialUnlockActions?: {
    subscribe: boolean
    like: boolean
    comment: boolean
  }
}

function getStorageKey(email?: string): string {
  if (email) {
    return `youtube_upload_defaults_${email}`
  }
  return "youtube_upload_defaults"
}

export function getUploadDefaults(email?: string): UploadDefaults | null {
  if (typeof window === "undefined") return null

  const stored = localStorage.getItem(getStorageKey(email))
  if (!stored) return null

  try {
    const parsed = JSON.parse(stored)
    return {
      socialUnlockEnabled: false,
      socialUnlockTargetUrl: "",
      socialUnlockActions: {
        subscribe: true,
        like: true,
        comment: false,
      },
      ...parsed,
    }
  } catch {
    return null
  }
}

export function saveUploadDefaults(defaults: UploadDefaults, email?: string): void {
  if (typeof window === "undefined") return
  localStorage.setItem(getStorageKey(email), JSON.stringify(defaults))
}

export function clearUploadDefaults(email?: string): void {
  if (typeof window === "undefined") return
  localStorage.removeItem(getStorageKey(email))
}
