// YouTube OAuth authentication utilities with multi-account support

import { getActiveClientId } from "./client-manager"

const GOOGLE_CLIENT_ID =
  process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || "302161788573-tho9l56pvgtq5nefhf1uvpla9tb3u14t.apps.googleusercontent.com"

export const YOUTUBE_SCOPES = [
  "https://www.googleapis.com/auth/youtube",
  "https://www.googleapis.com/auth/youtube.upload",
  "https://www.googleapis.com/auth/youtube.force-ssl",
  "https://www.googleapis.com/auth/userinfo.email", // Added to get email
  "https://www.googleapis.com/auth/userinfo.profile", // Added to get profile info
]

export interface YouTubeAuthToken {
  access_token: string
  expires_in: number
  token_type: string
  scope: string
}

export interface MultiAccountToken {
  email: string
  name: string
  picture?: string
  access_token: string
  expires_in: number
  token_type: string
  scope: string
  expiry: number
}

export function getClientId() {
  // Try to get active client ID from client manager first
  if (typeof window !== "undefined") {
    const activeClientId = getActiveClientId()
    if (activeClientId) {
      return activeClientId
    }
  }

  // Fall back to env variable
  return (
    process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID ||
    "302161788573-tho9l56pvgtq5nefhf1uvpla9tb3u14t.apps.googleusercontent.com"
  )
}

export function initializeGoogleAuth() {
  const script = document.createElement("script")
  script.src = "https://accounts.google.com/gsi/client"
  script.async = true
  document.body.appendChild(script)
}

export function initiateOAuthFlow() {
  const redirectUri = typeof window !== "undefined" ? window.location.origin : ""
  const scope = YOUTUBE_SCOPES.join(" ")

  const clientId = getClientId()

  console.log("[v0] OAuth Flow - Client ID:", clientId)
  console.log("[v0] OAuth Flow - Redirect URI:", redirectUri)

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "token",
    scope: scope,
    prompt: "select_account",
    access_type: "online",
  })

  window.location.href = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`
}

export function getTokenFromUrl(): YouTubeAuthToken | null {
  const hash = window.location.hash.substring(1)
  if (!hash) return null

  const params = new URLSearchParams(hash)
  const token = params.get("access_token")
  const expiresIn = params.get("expires_in")

  if (token && expiresIn) {
    return {
      access_token: token,
      expires_in: Number(expiresIn),
      token_type: "Bearer",
      scope: params.get("scope") || "",
    }
  }

  return null
}

export function getAllStoredTokens(): MultiAccountToken[] {
  const stored = localStorage.getItem("youtube_tokens_multi")
  if (!stored) return []

  try {
    const tokens = JSON.parse(stored)
    // Filter out truly expired tokens (with 5 minute buffer to prevent edge cases)
    const validTokens = tokens.filter((token: MultiAccountToken) => {
      if (!token.expiry) return true // Keep tokens without expiry set
      return token.expiry > Date.now() + 300000 // 5 minute buffer
    })

    // If we filtered any tokens, update localStorage
    if (validTokens.length !== tokens.length && validTokens.length > 0) {
      localStorage.setItem("youtube_tokens_multi", JSON.stringify(validTokens))
    }

    return validTokens
  } catch (error) {
    console.error("[v0] Error parsing stored tokens:", error)
    return []
  }
}

export async function saveTokenMultiAccount(token: YouTubeAuthToken) {
  try {
    const userInfo = await fetchUserInfo(token.access_token)
    // Set expiry time with full duration from token
    const expiryTime = Date.now() + token.expires_in * 1000

    const multiToken: MultiAccountToken = {
      email: userInfo.email,
      name: userInfo.name,
      picture: userInfo.picture,
      access_token: token.access_token,
      expires_in: token.expires_in,
      token_type: token.token_type,
      scope: token.scope,
      expiry: expiryTime,
    }

    // Get existing accounts
    const existing = getAllStoredTokens()
    const filtered = existing.filter((t) => t.email !== userInfo.email)
    const all = [...filtered, multiToken]

    localStorage.setItem("youtube_tokens_multi", JSON.stringify(all))

    // Clear the URL hash
    if (typeof window !== "undefined") {
      window.history.replaceState(null, "", window.location.pathname + window.location.search)
    }

    return multiToken
  } catch (error) {
    console.error("[v0] Failed to save token:", error)
    throw error
  }
}

export async function fetchUserInfo(accessToken: string) {
  const response = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  })

  if (!response.ok) {
    throw new Error("Failed to fetch user info")
  }

  return response.json()
}

export function getStoredTokenByEmail(email: string): MultiAccountToken | null {
  const tokens = getAllStoredTokens()
  return tokens.find((t) => t.email === email) || null
}

export function removeAccount(email: string) {
  const tokens = getAllStoredTokens()
  const filtered = tokens.filter((t) => t.email !== email)
  localStorage.setItem("youtube_tokens_multi", JSON.stringify(filtered))
}

// Legacy support - get first valid token
export function getStoredToken(): YouTubeAuthToken | null {
  const tokens = getAllStoredTokens()
  if (tokens.length === 0) return null

  const token = tokens[0]
  return {
    access_token: token.access_token,
    expires_in: token.expires_in,
    token_type: token.token_type,
    scope: token.scope,
  }
}

export function saveToken(token: YouTubeAuthToken) {
  saveTokenMultiAccount(token)
}

export function clearToken() {
  localStorage.removeItem("youtube_token")
  localStorage.removeItem("youtube_tokens_multi")
}

export function removeToken() {
  clearToken()
}

export function clearStoredToken() {
  clearToken()
}

export async function fetchChannelInfo(accessToken: string) {
  const response = await fetch(
    "https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,brandingSettings&mine=true",
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    },
  )

  if (!response.ok) {
    throw new Error("Failed to fetch channel info")
  }

  const data = await response.json()
  return data.items[0]
}

export async function fetchAllChannels(accessToken: string) {
  const response = await fetch(
    "https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,brandingSettings&maxResults=50&mine=true",
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    },
  )

  if (!response.ok) {
    throw new Error("Failed to fetch channels")
  }

  const data = await response.json()
  return data.items || []
}

export async function updateChannelInfo(accessToken: string, channelData: any) {
  const response = await fetch("https://www.googleapis.com/youtube/v3/channels?part=brandingSettings", {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(channelData),
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    console.error("[v0] YouTube API error:", errorData)
    throw new Error(errorData.error?.message || "Failed to update channel info")
  }

  return response.json()
}

export function isTokenExpiringSoon(token: MultiAccountToken): boolean {
  if (!token.expiry) return false
  // Token expires in less than 5 minutes
  return token.expiry < Date.now() + 300000
}

export async function validateToken(accessToken: string): Promise<boolean> {
  try {
    const response = await fetch("https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=" + accessToken)
    return response.ok
  } catch {
    return false
  }
}
