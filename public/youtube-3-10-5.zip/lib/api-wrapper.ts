import { detectQuotaError, handleQuotaError, getAutoSwitchPreference } from './quota-handler'

export async function fetchWithQuotaHandling(
  url: string,
  options?: RequestInit
): Promise<Response> {
  try {
    const response = await fetch(url, options)
    
    // Check if response indicates quota error
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      const quotaCheck = detectQuotaError(errorData)
      
      if (quotaCheck.isQuotaError && getAutoSwitchPreference()) {
        const { switched, newClient } = handleQuotaError()
        
        if (switched && newClient) {
          // Notify user about the switch
          if (typeof window !== 'undefined') {
            const event = new CustomEvent('quota-client-switched', {
              detail: { newClient }
            })
            window.dispatchEvent(event)
          }
          
          throw new Error(`Quota exceeded. Automatically switched to ${newClient}. Please retry your request.`)
        } else {
          throw new Error('All API clients have reached their quota limits. Please try again later.')
        }
      }
      
      // Return the response even if it's an error (let caller handle it)
      return response
    }
    
    return response
  } catch (error) {
    const quotaCheck = detectQuotaError(error)
    
    if (quotaCheck.isQuotaError && getAutoSwitchPreference()) {
      const { switched, newClient } = handleQuotaError()
      
      if (switched && newClient) {
        if (typeof window !== 'undefined') {
          const event = new CustomEvent('quota-client-switched', {
            detail: { newClient }
          })
          window.dispatchEvent(event)
        }
        
        throw new Error(`Quota exceeded. Automatically switched to ${newClient}. Please retry your request.`)
      }
    }
    
    throw error
  }
}
