// Smart link system for Facebook/Instagram social unlock
// Similar to YouTube unlock but adapted for FB/IG actions

import { shortenUrl } from "./url-shortener"

export interface FBSmartLinkData {
  postId: string
  pageId: string
  platform: "facebook" | "instagram"
  targetUrl: string
  pageName?: string
  postUrl?: string
  actions: {
    follow: boolean
    like: boolean
    comment: boolean
  }
}

export async function generateFBSmartLink(
  data: FBSmartLinkData,
  baseUrl: string = typeof window !== "undefined" ? window.location.origin : "",
): Promise<string> {
  // Create action mask: follow=1, like=2, comment=4
  let mask = 0
  if (data.actions.follow) mask |= 1
  if (data.actions.like) mask |= 2
  if (data.actions.comment) mask |= 4

  const p = data.platform === "instagram" ? "i" : "f"

  // Only include non-empty values, use shorter array format
  const payload = [mask, p, data.pageId, data.postUrl || "", data.targetUrl, data.pageName || ""]

  const encoded = btoa(JSON.stringify(payload)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")

  const longUrl = `${baseUrl}/u/fb/${data.postId}?d=${encoded}`

  const shortUrl = await shortenUrl(longUrl)
  return shortUrl
}

export function generateFBSmartLinkText(smartLink: string): string {
  return `\n\n━━━━━━━━━━━━━━━━━━━━\n🎁 UNLOCK EXCLUSIVE CONTENT\n${smartLink}\n━━━━━━━━━━━━━━━━━━━━`
}

export function decodeFBSmartLink(encodedData: string): FBSmartLinkData | null {
  try {
    const base64 = encodedData.replace(/-/g, "+").replace(/_/g, "/")
    const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), "=")
    const decoded = JSON.parse(atob(padded))

    if (Array.isArray(decoded) && decoded.length >= 5) {
      const [mask, platform, pageId, postUrl, targetUrl, pageName] = decoded

      const platformFull =
        platform === "i" ? "instagram" : platform === "f" ? "facebook" : (platform as "facebook" | "instagram")

      return {
        postId: "",
        pageId,
        platform: platformFull,
        targetUrl,
        pageName: pageName || "",
        postUrl: postUrl || "",
        actions: {
          follow: (mask & 1) === 1,
          like: (mask & 2) === 2,
          comment: (mask & 4) === 4,
        },
      }
    }
    return null
  } catch (e) {
    console.error("Failed to decode FB smart link", e)
    return null
  }
}
