"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import {
  getTokenFromUrl,
  saveToken,
  getStoredToken,
  getAllStoredTokens,
  type MultiAccountToken,
} from "@/lib/youtube-auth"
import { Search, Play, ExternalLink, Loader2 } from "lucide-react"

// Components
import { AuthButton } from "@/components/auth-button"
import { VideoUploader } from "@/components/video-uploader"
import { ChannelManager } from "@/components/channel-manager"
import { AccountManager } from "@/components/account-manager"
import { ErrorBoundary } from "@/components/error-boundary"
import { AnalyticsDashboard } from "@/components/analytics-dashboard"
import { BulkUploader } from "@/components/bulk-uploader"
import { MyVideosManager } from "@/components/my-videos-manager"
import { UploadDefaultsManager } from "@/components/upload-defaults-manager"
import { ClientSwitcher } from "@/components/client-switcher"
import { ClientSelectorLogin } from "@/components/client-selector-login"
import { ScheduledUploadsManager } from "@/components/scheduled-uploads-manager"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardOverview } from "@/components/dashboard-overview"
import { FacebookManager } from "@/components/facebook-manager" // Added Facebook import
import { InstagramAutoReplyWrapper } from "@/components/instagram-auto-reply-wrapper" // Added Instagram import
import { initRainEffect } from "./rain-effect"

type TabType =
  | "overview"
  | "search"
  | "channel"
  | "upload"
  | "bulk-upload"
  | "accounts"
  | "analytics"
  | "defaults"
  | "clients"
  | "scheduled"
  | "facebook" // Added facebook
  | "instagram" // Added instagram tab type
  | string

interface VideoType {
  id: string
  title: string
  thumbnail: string
  channelTitle: string
  publishedAt: string
  viewCount?: string
  description: string
}

export default function YouTubeCreatorApp() {
  const [accessToken, setAccessToken] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<TabType>("overview")
  const [searchQuery, setSearchQuery] = useState("")
  const [videos, setVideos] = useState<VideoType[]>([])
  const [selectedVideo, setSelectedVideo] = useState<VideoType | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [storedAccounts, setStoredAccounts] = useState<MultiAccountToken[]>([])
  const [searchError, setSearchError] = useState<string | null>(null)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const urlToken = getTokenFromUrl()
    if (urlToken) {
      saveToken(urlToken)
      setAccessToken(urlToken.access_token)
    } else {
      const storedToken = getStoredToken()
      setAccessToken(storedToken?.access_token || null)
    }

    const accounts = getAllStoredTokens()
    setStoredAccounts(accounts)

    if (!accessToken) {
      initRainEffect()
    }
  }, [])

  useEffect(() => {
    const handleFocus = () => {
      const accounts = getAllStoredTokens()
      setStoredAccounts(accounts)
    }

    window.addEventListener("focus", handleFocus)
    return () => window.removeEventListener("focus", handleFocus)
  }, [])

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!searchQuery.trim() || !accessToken) return

    setIsLoading(true)
    setSearchError(null)
    try {
      const response = await fetch(
        `/api/youtube/search?q=${encodeURIComponent(searchQuery)}&access_token=${accessToken}`,
      )
      const data = await response.json()

      if (data.error) {
        if (data.error.includes("quota")) {
          setSearchError("API quota exceeded. Try switching to a different API client in Settings.")
          toast({
            title: "Quota Exceeded",
            description: "Switch API clients in Settings to continue",
            variant: "destructive",
          })
        } else {
          setSearchError(data.error)
        }
        return
      }

      setVideos(data.items || [])
    } catch {
      setSearchError("Failed to search videos. Please try again.")
      toast({
        title: "Search failed",
        description: "Unable to search videos. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getPageTitle = () => {
    if (activeTab === "overview") return "Dashboard"
    if (activeTab === "analytics") return "Analytics"
    if (activeTab === "search") return "Search Videos"
    if (activeTab === "upload") return "Upload Video"
    if (activeTab === "bulk-upload") return "Bulk Upload"
    if (activeTab === "scheduled") return "Scheduled Uploads"
    if (activeTab === "accounts") return "Account Manager"
    if (activeTab === "defaults") return "Upload Defaults"
    if (activeTab === "clients") return "API Clients"
    if (activeTab === "channel") return "Settings"
    if (activeTab === "facebook") return "Facebook" // Added facebook title
    if (activeTab === "instagram") return "Instagram Auto-Reply" // Added Instagram page title
    if (activeTab.startsWith("my-videos-")) {
      const email = activeTab.replace("my-videos-", "")
      const account = storedAccounts.find((a) => a.email === email)
      return account?.name || "My Videos"
    }
    return "Dashboard"
  }

  const getPageSubtitle = () => {
    if (activeTab === "overview") return "Welcome back! Here's your channel overview."
    if (activeTab === "analytics") return "Track your channel's performance"
    if (activeTab === "search") return "Search and discover YouTube videos"
    if (activeTab === "upload") return "Upload a video to your channel"
    if (activeTab === "bulk-upload") return "Upload multiple videos at once"
    if (activeTab === "scheduled") return "View and manage scheduled uploads"
    if (activeTab === "accounts") return "Manage your connected YouTube accounts"
    if (activeTab === "defaults") return "Set default values for uploads"
    if (activeTab === "clients") return "Manage API clients to avoid quota limits"
    if (activeTab === "channel") return "Configure your channel settings"
    if (activeTab === "facebook") return "Manage your Facebook pages" // Added facebook subtitle
    if (activeTab === "instagram") return "Auto-reply to comments and DMs with keywords" // Added Instagram subtitle
    if (activeTab.startsWith("my-videos-")) return "Manage your uploaded videos"
    return ""
  }

  // Not authenticated - show login screen
  if (!accessToken) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6 relative overflow-hidden">
        <div className="rain-container absolute inset-0 z-0" id="rain-container" />

        <div className="w-full max-w-md relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center mb-6">
              <img src="/combo-wick-logo.png" alt="Combo_Wick Logo" className="w-48 h-auto" />
            </div>
            <h1 className="text-3xl font-bold mb-2 text-balance">Welcome back Master...</h1>
            <p className="text-muted-foreground text-pretty">Glad to see you here again. Here's a coffee ☕</p>
          </div>

          <Card className="p-6 space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Select API Client</label>
                <div>
                  <ClientSelectorLogin />
                </div>
              </div>
              <AuthButton />
            </div>
          </Card>
        </div>
      </div>
    )
  }

  // Authenticated - show dashboard
  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar - hidden on mobile by default */}
      <div className={`hidden md:block ${mobileMenuOpen ? "block" : ""}`}>
        <DashboardSidebar
          activeTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab)
            setMobileMenuOpen(false)
          }}
          accounts={storedAccounts}
          isCollapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
      </div>

      {/* Mobile sidebar overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative h-full w-64">
            <DashboardSidebar
              activeTab={activeTab}
              onTabChange={(tab) => {
                setActiveTab(tab)
                setMobileMenuOpen(false)
              }}
              accounts={storedAccounts}
              isCollapsed={false}
              onToggleCollapse={() => {}}
            />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-h-screen">
        <DashboardHeader
          title={getPageTitle()}
          subtitle={getPageSubtitle()}
          accounts={storedAccounts}
          onMobileMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)}
        />

        <main className="flex-1 p-6 overflow-auto">
          <div className="max-w-7xl mx-auto">
            {activeTab === "overview" ? (
              <DashboardOverview accounts={storedAccounts} onNavigate={setActiveTab} />
            ) : activeTab === "facebook" ? (
              <ErrorBoundary>
                <FacebookManager />
              </ErrorBoundary>
            ) : activeTab === "instagram" ? (
              <ErrorBoundary>
                <InstagramAutoReplyWrapper />
              </ErrorBoundary>
            ) : activeTab === "search" ? (
              <div className="space-y-6">
                <form onSubmit={handleSearch}>
                  <div className="relative max-w-2xl">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="Search YouTube videos..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-12 pr-24 h-12 text-base"
                    />
                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="absolute right-1.5 top-1/2 -translate-y-1/2"
                      size="sm"
                    >
                      {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Search"}
                    </Button>
                  </div>
                </form>

                {searchError && (
                  <Card className="p-4 bg-destructive/10 border-destructive/20">
                    <p className="text-sm text-destructive">{searchError}</p>
                  </Card>
                )}

                {videos.length > 0 && (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {videos.map((video) => (
                      <Card
                        key={video.id}
                        className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer"
                        onClick={() => setSelectedVideo(selectedVideo?.id === video.id ? null : video)}
                      >
                        <div className="relative aspect-video">
                          <img
                            src={video.thumbnail || "/placeholder.svg"}
                            alt={video.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                            <Play className="w-12 h-12 text-white" />
                          </div>
                        </div>
                        <div className="p-4">
                          <h3 className="font-semibold line-clamp-2 mb-1">{video.title}</h3>
                          <p className="text-sm text-muted-foreground">{video.channelTitle}</p>
                          {video.viewCount && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {Number(video.viewCount).toLocaleString()} views
                            </p>
                          )}
                        </div>
                        {selectedVideo?.id === video.id && (
                          <div className="p-4 border-t bg-muted/50">
                            <p className="text-sm text-muted-foreground line-clamp-3 mb-3">{video.description}</p>
                            <Button size="sm" variant="outline" asChild className="gap-2 bg-transparent">
                              <a
                                href={`https://www.youtube.com/watch?v=${video.id}`}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <ExternalLink className="w-4 h-4" />
                                Watch on YouTube
                              </a>
                            </Button>
                          </div>
                        )}
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            ) : activeTab === "upload" ? (
              <ErrorBoundary>
                <VideoUploader accessToken={accessToken} />
              </ErrorBoundary>
            ) : activeTab === "channel" ? (
              <ErrorBoundary>
                <ChannelManager accessToken={accessToken} />
              </ErrorBoundary>
            ) : activeTab === "analytics" ? (
              <ErrorBoundary>
                <AnalyticsDashboard
                  accessToken={accessToken}
                  accounts={storedAccounts.map((acc) => ({
                    email: acc.email,
                    accessToken: acc.access_token,
                    channelId: acc.channelId,
                    channelTitle: acc.name,
                    channelThumbnail: acc.picture,
                  }))}
                />
              </ErrorBoundary>
            ) : activeTab.startsWith("my-videos-") ? (
              <ErrorBoundary>
                {(() => {
                  const email = activeTab.replace("my-videos-", "")
                  const account = storedAccounts.find((a) => a.email === email)
                  return account ? <MyVideosManager accessToken={account.access_token} /> : null
                })()}
              </ErrorBoundary>
            ) : activeTab === "bulk-upload" ? (
              <ErrorBoundary>
                <BulkUploader />
              </ErrorBoundary>
            ) : activeTab === "accounts" ? (
              <ErrorBoundary>
                <AccountManager />
              </ErrorBoundary>
            ) : activeTab === "defaults" ? (
              <ErrorBoundary>
                <UploadDefaultsManager />
              </ErrorBoundary>
            ) : activeTab === "clients" ? (
              <ErrorBoundary>
                <ClientSwitcher />
              </ErrorBoundary>
            ) : activeTab === "scheduled" ? (
              <ErrorBoundary>
                <ScheduledUploadsManager />
              </ErrorBoundary>
            ) : null}
          </div>
        </main>
      </div>
    </div>
  )
}
