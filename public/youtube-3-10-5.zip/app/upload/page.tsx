"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { VideoUploader } from "@/components/video-uploader"
import { BulkUploader } from "@/components/bulk-uploader"
import { VideoTrimmer } from "@/components/video-trimmer"
import { getStoredToken, clearStoredToken } from "@/lib/youtube-auth"
import { useRouter } from "next/navigation"
import { Upload, Users, LogOut, RefreshCw, Scissors } from "lucide-react"

export default function UploadPage() {
  const [accessToken, setAccessToken] = useState<string | null>(null)
  const [uploadMode, setUploadMode] = useState<"single" | "bulk" | "trim">("single")
  const [isReauthenticating, setIsReauthenticating] = useState(false)
  const [trimFile, setTrimFile] = useState<File | null>(null)
  const router = useRouter()

  useEffect(() => {
    const token = getStoredToken()
    setAccessToken(token)
  }, [])

  const handleReauth = async () => {
    setIsReauthenticating(true)
    try {
      clearStoredToken()
      router.push("/")
    } catch (error) {
      console.error("[v0] Re-auth error:", error)
    } finally {
      setIsReauthenticating(false)
    }
  }

  const handleSignOut = () => {
    clearStoredToken()
    router.push("/")
  }

  if (!accessToken) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="p-8 text-center max-w-md">
          <h2 className="text-2xl font-bold mb-4">Not Authenticated</h2>
          <p className="text-muted-foreground mb-6">Please sign in to upload videos.</p>
          <Button onClick={() => router.push("/")}>Go to Home</Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2">YouTube Upload Manager</h1>
            <p className="text-muted-foreground">Upload and manage videos across your channels</p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleReauth}
              variant="outline"
              size="sm"
              disabled={isReauthenticating}
              className="gap-2 bg-transparent"
            >
              {isReauthenticating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              Re-auth
            </Button>
            <Button onClick={handleSignOut} variant="outline" size="sm" className="gap-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>
        </div>

        <Card className="p-6">
          <h2 className="font-semibold mb-4">Upload Mode</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => setUploadMode("single")}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                uploadMode === "single" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
              }`}
            >
              <Upload className="w-6 h-6 mb-2" />
              <p className="font-semibold mb-1">Single Upload</p>
              <p className="text-sm text-muted-foreground">Upload one video to your channel</p>
            </button>
            <button
              onClick={() => setUploadMode("bulk")}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                uploadMode === "bulk" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
              }`}
            >
              <Users className="w-6 h-6 mb-2" />
              <p className="font-semibold mb-1">Bulk Upload</p>
              <p className="text-sm text-muted-foreground">Upload multiple videos to multiple channels</p>
            </button>
            <button
              onClick={() => setUploadMode("trim")}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                uploadMode === "trim" ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
              }`}
            >
              <Scissors className="w-6 h-6 mb-2" />
              <p className="font-semibold mb-1">Trim Video</p>
              <p className="text-sm text-muted-foreground">Cut video to any length for testing</p>
            </button>
          </div>
        </Card>

        {uploadMode === "single" && <VideoUploader accessToken={accessToken} />}
        {uploadMode === "bulk" && <BulkUploader />}
        {uploadMode === "trim" && (
          <div className="space-y-4">
            {!trimFile ? (
              <Card className="p-8 text-center">
                <Scissors className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="font-semibold mb-2">Select a video to trim</p>
                <p className="text-sm text-muted-foreground mb-4">
                  Cut your video to any length. Perfect for creating Shorts or testing uploads.
                </p>
                <input
                  type="file"
                  accept="video/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) setTrimFile(file)
                  }}
                  className="hidden"
                  id="trim-file-input"
                />
                <Button onClick={() => document.getElementById("trim-file-input")?.click()}>Choose Video File</Button>
              </Card>
            ) : (
              <>
                <VideoTrimmer
                  videoFile={trimFile}
                  onTrimComplete={(trimmedFile) => {
                    setTrimFile(trimmedFile)
                    alert("Video trimmed successfully! You can now use it for upload.")
                  }}
                />
                <Button onClick={() => setTrimFile(null)} variant="outline" className="w-full">
                  Choose Different Video
                </Button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
