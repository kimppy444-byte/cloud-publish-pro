// Rain animation script that creates falling raindrops
export function initRainEffect() {
  const container = document.getElementById("rain-container")
  if (!container) return

  const numberOfDrops = 100

  function createRaindrop() {
    const drop = document.createElement("div")
    drop.className = "raindrop"

    // Random horizontal position
    const leftPosition = Math.random() * 100
    drop.style.left = `${leftPosition}%`

    // Random animation duration (speed)
    const duration = Math.random() * 1 + 0.5 // Between 0.5s and 1.5s
    drop.style.animationDuration = `${duration}s`

    // Random delay
    const delay = Math.random() * 2
    drop.style.animationDelay = `${delay}s`

    // Random opacity
    drop.style.opacity = String(Math.random() * 0.5 + 0.3)

    container.appendChild(drop)
  }

  // Create initial raindrops
  for (let i = 0; i < numberOfDrops; i++) {
    createRaindrop()
  }
}

// Initialize on load
if (typeof window !== "undefined") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initRainEffect)
  } else {
    initRainEffect()
  }
}
