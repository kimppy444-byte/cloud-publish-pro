import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Toaster } from "@/components/ui/toaster"
import { ErrorBoundary } from "@/components/error-boundary"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Combo_Wick Official Page",
  description: "Manage your YouTube channel, upload videos, and search for content",
  generator: "v0.app",
  icons: {
    icon: "/combo-wick-logo.png",
    apple: "/combo-wick-logo.png",
  },
  other: {
    monetag: "918fb4be7cd0479209ccdaccd18c7b80",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans antialiased`}>
        <ErrorBoundary>
          {children}
          <Toaster />
        </ErrorBoundary>
        <Analytics />
      </body>
    </html>
  )
}
