"use client"

import { useEffect, useState, use } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  CheckCircle2,
  Lock,
  ThumbsUp,
  MessageSquare,
  ArrowRight,
  Loader2,
  Download,
  Facebook,
  Instagram,
  UserPlus,
} from "lucide-react"
import { useSearchParams } from "next/navigation"
import { decodeFBSmartLink, type FBSmartLinkData } from "@/lib/fb-smart-link"

export default function FBUnlockPage({ params }: { params: Promise<{ postId: string }> }) {
  const { postId } = use(params)
  const searchParams = useSearchParams()

  const [linkData, setLinkData] = useState<FBSmartLinkData | null>(null)
  const [completedActions, setCompletedActions] = useState<{ [key: string]: boolean }>({})
  const [isVerifying, setIsVerifying] = useState<{ [key: string]: boolean }>({})
  const [isUnlocked, setIsUnlocked] = useState(false)

  useEffect(() => {
    try {
      const d = searchParams.get("d")
      if (d) {
        const decoded = decodeFBSmartLink(d)
        if (decoded) {
          decoded.postId = postId
          setLinkData(decoded)
        }
      }
    } catch (e) {
      console.error("Failed to parse unlock params", e)
    }
  }, [searchParams, postId])

  const verifyAction = (action: string, url: string) => {
    window.open(url, "_blank")
    setIsVerifying((prev) => ({ ...prev, [action]: true }))

    // Simulate verification after user completes the action
    setTimeout(() => {
      setCompletedActions((prev) => {
        const newState = { ...prev, [action]: true }

        if (linkData) {
          const required = []
          if (linkData.actions.follow) required.push("follow")
          if (linkData.actions.like) required.push("like")
          if (linkData.actions.comment) required.push("comment")

          const allDone = required.every((req) => newState[req])
          if (allDone) setIsUnlocked(true)
        }

        return newState
      })
      setIsVerifying((prev) => ({ ...prev, [action]: false }))
    }, 5000)
  }

  const handleUnlock = () => {
    if (isUnlocked && linkData?.targetUrl) {
      window.location.href = linkData.targetUrl
    }
  }

  const getPostUrl = () => {
    if (linkData?.postUrl) return linkData.postUrl
    if (linkData?.platform === "instagram") {
      return `https://www.instagram.com/p/${postId}/`
    }
    return `https://www.facebook.com/${postId}`
  }

  const getPageUrl = () => {
    if (linkData?.platform === "instagram") {
      return `https://www.instagram.com/${linkData.pageName || ""}`
    }
    return `https://www.facebook.com/${linkData?.pageId}`
  }

  const PlatformIcon = linkData?.platform === "instagram" ? Instagram : Facebook
  const platformColor = linkData?.platform === "instagram" ? "from-pink-600 to-purple-600" : "from-blue-600 to-blue-700"
  const platformBg = linkData?.platform === "instagram" ? "bg-gradient-to-r from-pink-600 to-purple-600" : "bg-blue-600"

  if (!linkData) {
    return (
      <div className="min-h-screen bg-[#0f0f0f] text-white flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white flex flex-col items-center justify-center p-4">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div
          className={`absolute top-[-10%] left-[-10%] w-[40%] h-[40%] ${linkData.platform === "instagram" ? "bg-pink-600/20" : "bg-blue-600/20"} blur-[120px] rounded-full`}
        />
        <div
          className={`absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] ${linkData.platform === "instagram" ? "bg-purple-600/20" : "bg-blue-500/20"} blur-[120px] rounded-full`}
        />
      </div>

      <div className="max-w-md w-full relative z-10 space-y-8">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-4">
            <Lock className="w-3 h-3 text-purple-400" />
            <span className="text-xs font-medium text-gray-300">Content Locked</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
            Complete Steps to Unlock
          </h1>
          <p className="text-gray-400 text-sm">Perform the actions below to access the exclusive content.</p>
        </div>

        <Card className="bg-[#1a1a1a] border-white/5 shadow-2xl overflow-hidden">
          {/* Platform Header */}
          <div className={`p-4 bg-gradient-to-r ${platformColor} flex items-center gap-3`}>
            <PlatformIcon className="w-6 h-6 text-white" />
            <div>
              <p className="font-bold text-white">
                {linkData.platform === "instagram" ? "Instagram" : "Facebook"} Unlock
              </p>
              {linkData.pageName && <p className="text-white/80 text-sm">@{linkData.pageName}</p>}
            </div>
          </div>

          <div className="p-6 space-y-4">
            {linkData.actions.follow && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.follow ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("follow", getPageUrl())}
                disabled={completedActions.follow || isVerifying.follow}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.follow ? "bg-green-500" : platformBg}`}>
                    <UserPlus className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-foreground">
                      Follow {linkData.platform === "instagram" ? "Account" : "Page"}
                    </div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.follow ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.follow ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}

            {linkData.actions.like && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.like ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("like", getPostUrl())}
                disabled={completedActions.like || isVerifying.like}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.like ? "bg-green-500" : "bg-red-500"}`}>
                    <ThumbsUp className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-foreground">Like Post</div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.like ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.like ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}

            {linkData.actions.comment && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.comment ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("comment", getPostUrl())}
                disabled={completedActions.comment || isVerifying.comment}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.comment ? "bg-green-500" : "bg-green-600"}`}>
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-foreground">Comment on Post</div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.comment ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.comment ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}
          </div>

          <div className="p-6 bg-white/5 border-t border-white/5">
            <Button
              className={`w-full h-12 text-lg font-bold transition-all duration-300 ${
                isUnlocked
                  ? `bg-gradient-to-r ${platformColor} hover:opacity-90 shadow-lg`
                  : "bg-gray-700 text-gray-400 cursor-not-allowed"
              }`}
              onClick={handleUnlock}
              disabled={!isUnlocked}
            >
              {isUnlocked ? (
                <span className="flex items-center gap-2">
                  <Download className="w-5 h-5" />
                  Unlock Link
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Complete Steps to Unlock
                </span>
              )}
            </Button>
            {!isUnlocked && (
              <p className="text-center text-xs text-gray-500 mt-3">Checking for completion automatically...</p>
            )}
          </div>
        </Card>

        <p className="text-center text-xs text-gray-600">Powered by Social Unlock</p>
      </div>
    </div>
  )
}
