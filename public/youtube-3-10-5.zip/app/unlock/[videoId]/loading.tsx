export default function Loading() {
  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white flex items-center justify-center">
      <div className="animate-pulse space-y-4">
        <div className="h-8 w-48 bg-white/10 rounded mx-auto" />
        <div className="h-4 w-64 bg-white/5 rounded mx-auto" />
      </div>
    </div>
  )
}
