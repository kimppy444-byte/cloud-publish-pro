import { type NextRequest, NextResponse } from "next/server"

// Test endpoint to simulate Instagram webhooks
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, text } = body // type: 'comment' or 'dm', text: message content

    let webhookPayload

    if (type === "comment") {
      webhookPayload = {
        entry: [
          {
            id: "test-page-id",
            time: Date.now(),
            changes: [
              {
                field: "comments",
                value: {
                  id: `test-comment-${Date.now()}`,
                  text: text,
                  from: {
                    id: "test-user-id",
                    username: "test_user",
                  },
                  media: {
                    id: "test-media-id",
                  },
                },
              },
            ],
          },
        ],
      }
    } else {
      webhookPayload = {
        entry: [
          {
            id: "test-page-id",
            time: Date.now(),
            messaging: [
              {
                sender: {
                  id: "test-user-id",
                },
                recipient: {
                  id: "test-page-id",
                },
                timestamp: Date.now(),
                message: {
                  mid: `test-message-${Date.now()}`,
                  text: text,
                },
              },
            ],
          },
        ],
      }
    }

    // Send to webhook endpoint
    const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/instagram/webhook`
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(webhookPayload),
    })

    const result = await response.json()

    return NextResponse.json({
      success: true,
      message: "Test webhook sent",
      payload: webhookPayload,
      result,
    })
  } catch (error) {
    console.error("[v0] Test webhook error:", error)
    return NextResponse.json({ error: "Failed to send test webhook" }, { status: 500 })
  }
}
