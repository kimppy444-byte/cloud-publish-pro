import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { accessToken, igAccountId, recipientId, message } = await request.json()

    if (!accessToken || !igAccountId || !recipientId || !message) {
      return NextResponse.json({ error: "Missing parameters" }, { status: 400 })
    }

    // Send DM via Instagram Messaging API
    const response = await fetch(
      `https://graph.facebook.com/v19.0/${igAccountId}/messages?access_token=${accessToken}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipient: { id: recipientId },
          message: { text: message },
        }),
      },
    )

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.error?.message || "Failed to send DM. User may not have messaged you first." },
        { status: 400 },
      )
    }

    const data = await response.json()
    return NextResponse.json({ success: true, data })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to send DM" }, { status: 500 })
  }
}
