import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const accessToken = searchParams.get("access_token")
  const igAccountId = searchParams.get("ig_account_id")

  if (!accessToken || !igAccountId) {
    return NextResponse.json({ error: "Missing parameters" }, { status: 400 })
  }

  try {
    // Fetch recent media posts
    const mediaResponse = await fetch(
      `https://graph.facebook.com/v19.0/${igAccountId}/media?fields=id,caption,media_type,timestamp&limit=10&access_token=${accessToken}`,
    )

    if (!mediaResponse.ok) {
      const error = await mediaResponse.json()
      return NextResponse.json({ error: error.error?.message || "Failed to fetch media" }, { status: 400 })
    }

    const mediaData = await mediaResponse.json()
    const allComments = []

    // Fetch comments for each media post
    for (const media of mediaData.data || []) {
      const commentsResponse = await fetch(
        `https://graph.facebook.com/v19.0/${media.id}/comments?fields=id,text,username,timestamp,from&access_token=${accessToken}`,
      )

      if (commentsResponse.ok) {
        const commentsData = await commentsResponse.json()
        for (const comment of commentsData.data || []) {
          allComments.push({
            ...comment,
            mediaId: media.id,
            mediaCaption: media.caption,
          })
        }
      }
    }

    return NextResponse.json({ comments: allComments })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to fetch comments" }, { status: 500 })
  }
}
