import { type NextRequest, NextResponse } from "next/server"
import { list, put } from "@vercel/blob"

const RULES_BLOB_KEY = "instagram-auto-reply-rules.json"

export interface KeywordRule {
  id: string
  name: string
  keywords: string[]
  response: string
  enabled: boolean
  replyToDMs: boolean
  replyToComments: boolean
  createdAt: string
  updatedAt: string
}

// GET - Fetch all rules
export async function GET() {
  try {
    const { blobs } = await list({ prefix: RULES_BLOB_KEY })

    if (blobs.length === 0) {
      // Return default rules
      const defaultRules: KeywordRule[] = [
        {
          id: "1",
          name: "Script Request",
          keywords: ["SCRIPT", "script", "Script"],
          response: "Thanks for your interest! Here's your script: https://example.com/script",
          enabled: true,
          replyToDMs: true,
          replyToComments: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: "2",
          name: "Link Request",
          keywords: ["LINK", "link", "Link"],
          response: "Here's the link you requested: https://example.com/link",
          enabled: true,
          replyToDMs: true,
          replyToComments: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ]

      return NextResponse.json({ rules: defaultRules })
    }

    const blob = blobs[0]
    const response = await fetch(blob.url)
    const rules = await response.json()

    return NextResponse.json({ rules })
  } catch (error) {
    console.error("[v0] Error fetching rules:", error)
    return NextResponse.json({ error: "Failed to fetch rules" }, { status: 500 })
  }
}

// POST - Create or update rules
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const rules: KeywordRule[] = body.rules

    // Validate rules
    if (!Array.isArray(rules)) {
      return NextResponse.json({ error: "Invalid rules format" }, { status: 400 })
    }

    // Save to blob storage
    const blob = await put(RULES_BLOB_KEY, JSON.stringify(rules), {
      access: "public",
      contentType: "application/json",
    })

    return NextResponse.json({ success: true, blob })
  } catch (error) {
    console.error("[v0] Error saving rules:", error)
    return NextResponse.json({ error: "Failed to save rules" }, { status: 500 })
  }
}

// DELETE - Delete a specific rule
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const ruleId = searchParams.get("id")

    if (!ruleId) {
      return NextResponse.json({ error: "Rule ID required" }, { status: 400 })
    }

    // Fetch current rules
    const { blobs } = await list({ prefix: RULES_BLOB_KEY })

    if (blobs.length > 0) {
      const blob = blobs[0]
      const response = await fetch(blob.url)
      const rules: KeywordRule[] = await response.json()

      // Filter out the rule to delete
      const updatedRules = rules.filter((rule) => rule.id !== ruleId)

      // Save updated rules
      await put(RULES_BLOB_KEY, JSON.stringify(updatedRules), {
        access: "public",
        contentType: "application/json",
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error deleting rule:", error)
    return NextResponse.json({ error: "Failed to delete rule" }, { status: 500 })
  }
}
