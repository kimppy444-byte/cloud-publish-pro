import { type NextRequest, NextResponse } from "next/server"
import { list, put } from "@vercel/blob"

const LOGS_BLOB_KEY = "instagram-auto-reply-logs.json"

export interface InteractionLog {
  id: string
  type: "comment" | "dm"
  keyword: string
  from: string
  commentId?: string
  response: string
  timestamp: string
}

// GET - Fetch all logs
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "100")

    const { blobs } = await list({ prefix: LOGS_BLOB_KEY })

    if (blobs.length === 0) {
      return NextResponse.json({ logs: [] })
    }

    const blob = blobs[0]
    const response = await fetch(blob.url)
    let logs: InteractionLog[] = await response.json()

    // Sort by timestamp descending and limit
    logs = logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, limit)

    return NextResponse.json({ logs })
  } catch (error) {
    console.error("[v0] Error fetching logs:", error)
    return NextResponse.json({ error: "Failed to fetch logs" }, { status: 500 })
  }
}

// POST - Add new log
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const newLog: InteractionLog = {
      id: Date.now().toString(),
      ...body,
    }

    // Fetch existing logs
    let logs: InteractionLog[] = []
    const { blobs } = await list({ prefix: LOGS_BLOB_KEY })

    if (blobs.length > 0) {
      const blob = blobs[0]
      const response = await fetch(blob.url)
      logs = await response.json()
    }

    // Add new log
    logs.push(newLog)

    // Keep only last 1000 logs
    if (logs.length > 1000) {
      logs = logs.slice(-1000)
    }

    // Save to blob storage
    await put(LOGS_BLOB_KEY, JSON.stringify(logs), {
      access: "public",
      contentType: "application/json",
    })

    return NextResponse.json({ success: true, log: newLog })
  } catch (error) {
    console.error("[v0] Error saving log:", error)
    return NextResponse.json({ error: "Failed to save log" }, { status: 500 })
  }
}
