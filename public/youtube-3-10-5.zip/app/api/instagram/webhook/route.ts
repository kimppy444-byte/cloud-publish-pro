import { type NextRequest, NextResponse } from "next/server"

// Instagram webhook verification
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const mode = searchParams.get("hub.mode")
  const token = searchParams.get("hub.verify_token")
  const challenge = searchParams.get("hub.challenge")

  const VERIFY_TOKEN = process.env.INSTAGRAM_VERIFY_TOKEN || "your_verify_token"

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    console.log("[v0] Webhook verified")
    return new NextResponse(challenge, { status: 200 })
  }

  return NextResponse.json({ error: "Verification failed" }, { status: 403 })
}

// Handle incoming webhook events
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] Webhook received:", JSON.stringify(body, null, 2))

    // Process each entry
    for (const entry of body.entry || []) {
      // Handle comments
      if (entry.changes) {
        for (const change of entry.changes) {
          if (change.field === "comments" && change.value) {
            await handleComment(change.value)
          }
        }
      }

      // Handle messages (DMs)
      if (entry.messaging) {
        for (const message of entry.messaging) {
          await handleMessage(message)
        }
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Webhook error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function handleComment(commentData: any) {
  const commentText = commentData.text?.toLowerCase() || ""
  const commentId = commentData.id
  const from = commentData.from

  console.log("[v0] Processing comment:", commentText)

  // Get keyword rules from database/storage
  const rules = await getKeywordRules()

  for (const rule of rules) {
    const keywords = rule.keywords.map((k: string) => k.toLowerCase())
    const matchedKeyword = keywords.find((keyword: string) => commentText.includes(keyword))

    if (matchedKeyword && rule.enabled) {
      console.log(`[v0] Matched keyword "${matchedKeyword}" for rule:`, rule.name)

      // Reply to comment
      await replyToComment(commentId, rule.response)

      // Log the interaction
      await logInteraction({
        type: "comment",
        keyword: matchedKeyword,
        from: from?.username || from?.id,
        commentId,
        response: rule.response,
        timestamp: new Date().toISOString(),
      })

      break // Only match first rule
    }
  }
}

async function handleMessage(messageData: any) {
  const sender = messageData.sender
  const recipient = messageData.recipient
  const message = messageData.message

  if (!message || !message.text) return

  const messageText = message.text.toLowerCase()

  console.log("[v0] Processing DM:", messageText)

  // Get keyword rules
  const rules = await getKeywordRules()

  for (const rule of rules) {
    if (!rule.replyToDMs) continue

    const keywords = rule.keywords.map((k: string) => k.toLowerCase())
    const matchedKeyword = keywords.find((keyword: string) => messageText.includes(keyword))

    if (matchedKeyword && rule.enabled) {
      console.log(`[v0] Matched keyword "${matchedKeyword}" in DM for rule:`, rule.name)

      // Reply to DM
      await replyToMessage(sender.id, rule.response)

      // Log the interaction
      await logInteraction({
        type: "dm",
        keyword: matchedKeyword,
        from: sender.id,
        response: rule.response,
        timestamp: new Date().toISOString(),
      })

      break
    }
  }
}

async function replyToComment(commentId: string, replyText: string) {
  const accessToken = process.env.INSTAGRAM_ACCESS_TOKEN

  if (!accessToken) {
    console.error("[v0] No Instagram access token found")
    return
  }

  try {
    const response = await fetch(`https://graph.facebook.com/v18.0/${commentId}/replies`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: replyText,
        access_token: accessToken,
      }),
    })

    const data = await response.json()

    if (data.error) {
      console.error("[v0] Error replying to comment:", data.error)
    } else {
      console.log("[v0] Successfully replied to comment")
    }
  } catch (error) {
    console.error("[v0] Error replying to comment:", error)
  }
}

async function replyToMessage(recipientId: string, messageText: string) {
  const accessToken = process.env.INSTAGRAM_ACCESS_TOKEN
  const pageId = process.env.INSTAGRAM_PAGE_ID

  if (!accessToken || !pageId) {
    console.error("[v0] Missing Instagram credentials")
    return
  }

  try {
    const response = await fetch(`https://graph.facebook.com/v18.0/${pageId}/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        recipient: { id: recipientId },
        message: { text: messageText },
        access_token: accessToken,
      }),
    })

    const data = await response.json()

    if (data.error) {
      console.error("[v0] Error sending DM:", data.error)
    } else {
      console.log("[v0] Successfully sent DM")
    }
  } catch (error) {
    console.error("[v0] Error sending DM:", error)
  }
}

async function getKeywordRules() {
  // In production, fetch from database
  // For now, return from localStorage/blob storage
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/instagram/rules`)
    if (response.ok) {
      const data = await response.json()
      return data.rules || []
    }
  } catch (error) {
    console.error("[v0] Error fetching rules:", error)
  }

  return []
}

async function logInteraction(interaction: any) {
  try {
    await fetch(`${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/instagram/logs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(interaction),
    })
  } catch (error) {
    console.error("[v0] Error logging interaction:", error)
  }
}
