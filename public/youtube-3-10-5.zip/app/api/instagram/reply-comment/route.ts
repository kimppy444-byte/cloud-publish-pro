import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { accessToken, commentId, message } = await request.json()

    if (!accessToken || !commentId || !message) {
      return NextResponse.json({ error: "Missing parameters" }, { status: 400 })
    }

    // Reply to the comment
    const response = await fetch(`https://graph.facebook.com/v19.0/${commentId}/replies?access_token=${accessToken}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json({ error: error.error?.message || "Failed to reply" }, { status: 400 })
    }

    const data = await response.json()
    return NextResponse.json({ success: true, data })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to reply to comment" }, { status: 500 })
  }
}
