import { NextResponse } from "next/server"

export async function PUT(request: Request) {
  try {
    const { accessToken, videoId, title, description, privacyStatus } = await request.json()

    if (!accessToken || !videoId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const response = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet,status`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        id: videoId,
        snippet: {
          title,
          description,
          categoryId: "22",
        },
        status: {
          privacyStatus,
        },
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("[v0] YouTube API error:", errorData)
      const errorMessage = errorData.error?.message || "Failed to update video"
      return NextResponse.json({ error: errorMessage }, { status: response.status })
    }

    const data = await response.json()
    return NextResponse.json({ success: true, video: data })
  } catch (error) {
    console.error("[v0] Error updating video:", error)
    const errorMessage = error instanceof Error ? error.message : "Failed to update video"
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
