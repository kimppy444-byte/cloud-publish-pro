import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { text, targetLanguage, sourceLanguage = "en" } = await request.json()

    if (!text || !targetLanguage) {
      return NextResponse.json(
        { error: "Missing required fields: text and targetLanguage" },
        { status: 400 }
      )
    }

    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${sourceLanguage}|${targetLanguage}`

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      const errorData = await response.text()
      console.error("[v0] MyMemory API error:", errorData)
      return NextResponse.json(
        { error: "Translation failed" },
        { status: response.status }
      )
    }

    const data = await response.json()
    
    if (data.responseStatus !== 200) {
      return NextResponse.json(
        { error: data.responseDetails || "Translation failed" },
        { status: 400 }
      )
    }

    const translatedText = data.responseData.translatedText

    return NextResponse.json({
      translatedText,
      detectedSourceLanguage: sourceLanguage,
      targetLanguage,
    })
  } catch (error) {
    console.error("[v0] Translation error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Translation failed" },
      { status: 500 }
    )
  }
}
