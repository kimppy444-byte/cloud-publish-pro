import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const accessToken = searchParams.get("access_token")

  if (!accessToken) {
    return NextResponse.json({ error: "Access token is required" }, { status: 400 })
  }

  try {
    // Get channel ID first
    const channelResponse = await fetch(
      "https://www.googleapis.com/youtube/v3/channels?part=id,statistics,contentDetails&mine=true",
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    )

    if (!channelResponse.ok) {
      throw new Error("Failed to fetch channel info")
    }

    const channelData = await channelResponse.json()
    const channel = channelData.items?.[0]

    if (!channel) {
      return NextResponse.json({ error: "No channel found" }, { status: 404 })
    }

    // Get recent videos
    const videosResponse = await fetch(
      "https://www.googleapis.com/youtube/v3/search?part=id&forMine=true&type=video&order=date&maxResults=10",
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    )

    const videosData = await videosResponse.json()
    const videoIds = videosData.items?.map((item: any) => item.id.videoId).join(",") || ""

    // Get video statistics
    let recentVideos = []
    if (videoIds) {
      const statsResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/videos?part=statistics,snippet&id=${videoIds}`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      )
      const statsData = await statsResponse.json()
      recentVideos = statsData.items || []
    }

    return NextResponse.json({
      channelStats: channel.statistics,
      recentVideos: recentVideos.map((video: any) => ({
        id: video.id,
        title: video.snippet.title,
        views: video.statistics.viewCount,
        likes: video.statistics.likeCount,
        comments: video.statistics.commentCount,
        publishedAt: video.snippet.publishedAt,
        thumbnail: video.snippet.thumbnails?.medium?.url || video.snippet.thumbnails?.default?.url,
      })),
    })
  } catch (error) {
    console.error("Analytics error:", error)
    return NextResponse.json({ error: "Failed to fetch analytics" }, { status: 500 })
  }
}
