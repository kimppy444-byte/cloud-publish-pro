import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { accessToken, videoId, text } = await request.json()

    if (!accessToken || !videoId || !text) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const response = await fetch("https://www.googleapis.com/youtube/v3/commentThreads?part=snippet", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        snippet: {
          videoId,
          topLevelComment: {
            snippet: {
              textOriginal: text,
            },
          },
        },
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("[v0] YouTube comment error:", errorData)
      return NextResponse.json(
        { error: errorData.error?.message || "Failed to post comment" },
        { status: response.status },
      )
    }

    const data = await response.json()
    return NextResponse.json({ success: true, comment: data })
  } catch (error) {
    console.error("[v0] Error posting comment:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to post comment" },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { accessToken, commentId } = await request.json()

    if (!accessToken || !commentId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const response = await fetch("https://www.googleapis.com/youtube/v3/comments/setModerationStatus", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        id: commentId,
        moderationStatus: "published",
        banAuthor: false,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("[v0] YouTube pin error:", errorData)
      return NextResponse.json({ error: errorData.error?.message || "Failed to pin comment" }, { status: response.status })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error pinning comment:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to pin comment" },
      { status: 500 },
    )
  }
}
