import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const accessToken = formData.get("accessToken") as string
    const videoId = formData.get("videoId") as string
    const thumbnail = formData.get("thumbnail") as File

    if (!accessToken || !videoId || !thumbnail) {
      return NextResponse.json(
        { error: "Missing required fields: accessToken, videoId, and thumbnail file" },
        { status: 400 }
      )
    }

    // Validate file size (max 2MB)
    if (thumbnail.size > 2 * 1024 * 1024) {
      return NextResponse.json(
        { error: "Thumbnail must be less than 2MB" },
        { status: 400 }
      )
    }

    const arrayBuffer = await thumbnail.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Upload thumbnail to YouTube using multipart/form-data
    const response = await fetch(
      `https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=${videoId}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/octet-stream",
          "Content-Length": buffer.length.toString(),
        },
        body: buffer,
      }
    )

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Thumbnail upload failed:", response.status, errorText)
      
      if (response.status === 403) {
        return NextResponse.json(
          { error: "Permission denied. Ensure you have the correct OAuth scopes and re-authenticate." },
          { status: 403 }
        )
      }

      return NextResponse.json(
        { error: `Failed to upload thumbnail: ${errorText}` },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json({ success: true, thumbnail: data })
  } catch (error) {
    console.error("[v0] Thumbnail upload error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to upload thumbnail" },
      { status: 500 }
    )
  }
}
