import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const accessToken = searchParams.get("access_token")

  if (!accessToken) {
    return NextResponse.json({ error: "No access token provided" }, { status: 401 })
  }

  try {
    const channelResponse = await fetch(
      "https://www.googleapis.com/youtube/v3/channels?part=contentDetails&mine=true",
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    )

    if (!channelResponse.ok) {
      const errorText = await channelResponse.text()
      console.error("[v0] YouTube API error (channel):", channelResponse.status, errorText)
      throw new Error(`Failed to fetch channel info: ${channelResponse.status}`)
    }

    const channelData = await channelResponse.json()
    const uploadsPlaylistId = channelData.items[0]?.contentDetails?.relatedPlaylists?.uploads

    if (!uploadsPlaylistId) {
      return NextResponse.json({ videos: [] })
    }

    const videosResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId=${uploadsPlaylistId}&maxResults=50&mine=true`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    )

    if (!videosResponse.ok) {
      const errorText = await videosResponse.text()
      console.error("[v0] YouTube API error (videos):", videosResponse.status, errorText)
      throw new Error(`Failed to fetch videos: ${videosResponse.status}`)
    }

    const videosData = await videosResponse.json()
    const videoIds = videosData.items.map((item: any) => item.contentDetails.videoId).join(",")

    if (!videoIds) {
      return NextResponse.json({ videos: [] })
    }

    const statsResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=statistics,status&id=${videoIds}`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    )

    if (!statsResponse.ok) {
      const errorText = await statsResponse.text()
      console.error("[v0] YouTube API error (stats):", statsResponse.status, errorText)
      throw new Error(`Failed to fetch video stats: ${statsResponse.status}`)
    }

    const statsData = await statsResponse.json()

    const videos = videosData.items.map((item: any) => {
      const videoId = item.contentDetails.videoId
      const stats = statsData.items.find((stat: any) => stat.id === videoId)

      return {
        id: videoId,
        title: item.snippet.title,
        description: item.snippet.description,
        thumbnail: item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.medium?.url,
        publishedAt: item.snippet.publishedAt,
        viewCount: stats?.statistics?.viewCount || "0",
        likeCount: stats?.statistics?.likeCount || "0",
        commentCount: stats?.statistics?.commentCount || "0",
        privacyStatus: stats?.status?.privacyStatus || "unknown",
      }
    })

    videos.sort((a: any, b: any) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())

    return NextResponse.json({ videos })
  } catch (error) {
    console.error("[v0] Error fetching my videos:", error)
    const errorMessage = error instanceof Error ? error.message : "Failed to fetch videos"
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
