import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { text, targetLanguages } = await request.json()

    if (!text || !targetLanguages || targetLanguages.length === 0) {
      return NextResponse.json({ error: "Missing text or target languages" }, { status: 400 })
    }

    const translations: Record<string, string> = {}

    for (const lang of targetLanguages) {
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${lang}`
      
      const response = await fetch(url)
      const data = await response.json()

      if (data.responseStatus === 200 && data.responseData) {
        translations[lang] = data.responseData.translatedText
      } else {
        translations[lang] = `Translation failed for ${lang}`
      }

      await new Promise(resolve => setTimeout(resolve, 100))
    }

    return NextResponse.json({ translations })
  } catch (error) {
    console.error("[v0] Batch translation error:", error)
    return NextResponse.json(
      { error: "Translation failed" },
      { status: 500 }
    )
  }
}
