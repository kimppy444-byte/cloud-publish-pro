import { type NextRequest, NextResponse } from "next/server"

const YOUTUBE_API_KEY = "AIzaSyCJ3h3sCWy2Qe3qIWC_hmk6QLPcWHDpe5I"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const query = searchParams.get("q")

  if (!query) {
    return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
  }

  try {
    // Search for videos
    const searchResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(
        query,
      )}&type=video&maxResults=20&key=${YOUTUBE_API_KEY}`,
    )

    if (!searchResponse.ok) {
      throw new Error("Failed to fetch from YouTube API")
    }

    const searchData = await searchResponse.json()
    const videoIds = searchData.items.map((item: any) => item.id.videoId).join(",")

    // Get video statistics
    const statsResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=statistics&id=${videoIds}&key=${YOUTUBE_API_KEY}`,
    )

    const statsData = await statsResponse.json()
    const statsMap = new Map(statsData.items.map((item: any) => [item.id, item.statistics]))

    const videos = searchData.items.map((item: any) => {
      const stats = statsMap.get(item.id.videoId)
      return {
        id: item.id.videoId,
        title: item.snippet.title,
        thumbnail: item.snippet.thumbnails.medium.url,
        channelTitle: item.snippet.channelTitle,
        publishedAt: item.snippet.publishedAt,
        viewCount: stats?.viewCount,
        description: item.snippet.description,
      }
    })

    return NextResponse.json({ videos })
  } catch (error) {
    console.error("[v0] YouTube API error:", error)
    return NextResponse.json({ error: "Failed to search videos" }, { status: 500 })
  }
}
