import { NextResponse } from "next/server"

// We store mappings in memory (for production, use a database like Redis or KV)
const urlMappings = new Map<string, string>()

function generateShortCode(url: string): string {
  // Create a simple hash from the URL
  let hash = 0
  for (let i = 0; i < url.length; i++) {
    const char = url.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32bit integer
  }
  // Convert to base36 for shorter representation
  return Math.abs(hash).toString(36)
}

export async function POST(request: Request) {
  try {
    const { url } = await request.json()

    if (!url) {
      return NextResponse.json({ error: "URL is required" }, { status: 400 })
    }

    const shortCode = generateShortCode(url)
    urlMappings.set(shortCode, url)

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || (typeof window !== "undefined" ? window.location.origin : "")

    // Return a much shorter URL
    const shortUrl = `${baseUrl || ""}/s/${shortCode}`

    return NextResponse.json({ shortUrl, originalUrl: url })
  } catch (error) {
    console.error("[v0] URL shortening error:", error)
    return NextResponse.json({ error: "Failed to shorten URL" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get("code")

  if (!code) {
    return NextResponse.json({ error: "Code is required" }, { status: 400 })
  }

  const originalUrl = urlMappings.get(code)
  if (!originalUrl) {
    return NextResponse.json({ error: "URL not found" }, { status: 404 })
  }

  return NextResponse.json({ url: originalUrl })
}
