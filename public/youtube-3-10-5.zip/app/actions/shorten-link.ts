"use server"

// In a production environment, you'd want to use a database or KV store
const shortLinks = new Map<string, { videoId: string; encodedData: string; createdAt: number }>()

interface ShortLinkData {
  videoId: string
  encodedData: string
  createdAt: number
}

export async function createShortLink(videoId: string, encodedData: string): Promise<string> {
  // Generate a short code (6 characters)
  const shortCode = Math.random().toString(36).substring(2, 8)

  const data: ShortLinkData = {
    videoId,
    encodedData,
    createdAt: Date.now(),
  }

  // Store in memory (in production, use a database or KV store)
  shortLinks.set(shortCode, data)

  // Clean up old links (older than 30 days)
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000
  for (const [key, value] of shortLinks.entries()) {
    if (value.createdAt < thirtyDaysAgo) {
      shortLinks.delete(key)
    }
  }

  return shortCode
}

export async function getShortLinkData(shortCode: string): Promise<ShortLinkData | null> {
  const data = shortLinks.get(shortCode)

  if (!data) {
    return null
  }

  // Check if link has expired (30 days)
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000
  if (data.createdAt < thirtyDaysAgo) {
    shortLinks.delete(shortCode)
    return null
  }

  return data
}
