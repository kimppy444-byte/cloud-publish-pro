"use client"

import { useEffect, useState, use } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  CheckCircle2,
  Lock,
  ThumbsUp,
  MessageSquare,
  ArrowRight,
  Loader2,
  Download,
  Facebook,
  Instagram,
  UserPlus,
  ExternalLink,
  Youtube,
} from "lucide-react"
import { useSearchParams } from "next/navigation"
import { decodeFBSmartLink, type FBSmartLinkData } from "@/lib/fb-smart-link"

export default function FBUnlockPage({ params }: { params: Promise<{ postId: string }> }) {
  const { postId } = use(params)
  const searchParams = useSearchParams()

  const [linkData, setLinkData] = useState<FBSmartLinkData | null>(null)
  const [completedActions, setCompletedActions] = useState<{ [key: string]: boolean }>({})
  const [isVerifying, setIsVerifying] = useState<{ [key: string]: boolean }>({})
  const [isUnlocked, setIsUnlocked] = useState(false)

  const [adClickCount, setAdClickCount] = useState(0)
  const AD_LINK = "https://otieu.com/4/10327158"
  const REQUIRED_AD_CLICKS = 2

  useEffect(() => {
    try {
      const d = searchParams.get("d")
      if (d) {
        const decoded = decodeFBSmartLink(d)
        if (decoded) {
          decoded.postId = postId
          setLinkData(decoded)
        }
      }
    } catch (e) {
      console.error("Failed to parse unlock params", e)
    }
  }, [searchParams, postId])

  const verifyAction = (action: string, url: string) => {
    window.open(url, "_blank")
    setIsVerifying((prev) => ({ ...prev, [action]: true }))

    // Simulate verification after user completes the action
    setTimeout(() => {
      setCompletedActions((prev) => {
        const newState = { ...prev, [action]: true }

        if (linkData) {
          const required = []
          if (linkData.actions.follow) required.push("follow")
          if (linkData.actions.like) required.push("like")
          if (linkData.actions.comment) required.push("comment")

          const allDone = required.every((req) => newState[req])
          if (allDone) setIsUnlocked(true)
        }

        return newState
      })
      setIsVerifying((prev) => ({ ...prev, [action]: false }))
    }, 5000)
  }

  const handleUnlock = () => {
    if (!isUnlocked) return

    if (adClickCount < REQUIRED_AD_CLICKS) {
      // Open ad link
      window.open(AD_LINK, "_blank")
      setAdClickCount((prev) => prev + 1)
    } else {
      // After 2 clicks, navigate to target URL
      if (linkData?.targetUrl) {
        window.location.href = linkData.targetUrl
      }
    }
  }

  const getButtonText = () => {
    if (!isUnlocked) {
      return (
        <span className="flex items-center gap-2">
          <Lock className="w-4 h-4" />
          Complete Steps to Unlock
        </span>
      )
    }

    if (adClickCount < REQUIRED_AD_CLICKS) {
      return (
        <span className="flex items-center gap-2">
          <ExternalLink className="w-5 h-5" />
          Continue ({adClickCount}/{REQUIRED_AD_CLICKS})
        </span>
      )
    }

    return (
      <span className="flex items-center gap-2">
        <Download className="w-5 h-5" />
        Unlock Link
      </span>
    )
  }

  const getPostUrl = () => {
    // If we have the actual post URL from the share link, use it
    if (linkData?.postUrl) return linkData.postUrl

    // Fallback to constructing the URL
    if (linkData?.platform === "instagram") {
      // Use the reel/post format for Instagram
      return `https://www.instagram.com/reel/${postId}/`
    }
    return `https://www.facebook.com/${postId}`
  }

  const getPageUrl = () => {
    if (linkData?.platform === "instagram") {
      return `https://www.instagram.com/${linkData.pageName || ""}`
    }
    return `https://www.facebook.com/${linkData?.pageId}`
  }

  const PlatformIcon = linkData?.platform === "instagram" ? Instagram : Facebook
  const platformColor = linkData?.platform === "instagram" ? "from-pink-600 to-purple-600" : "from-blue-600 to-blue-700"
  const platformBg = linkData?.platform === "instagram" ? "bg-gradient-to-r from-pink-600 to-purple-600" : "bg-blue-600"

  if (!linkData) {
    return (
      <div className="min-h-screen bg-[#0f0f0f] text-white flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white flex flex-col items-center justify-center p-4">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div
          className={`absolute top-[-10%] left-[-10%] w-[40%] h-[40%] ${linkData.platform === "instagram" ? "bg-pink-600/20" : "bg-blue-600/20"} blur-[120px] rounded-full`}
        />
        <div
          className={`absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] ${linkData.platform === "instagram" ? "bg-purple-600/20" : "bg-blue-500/20"} blur-[120px] rounded-full`}
        />
      </div>

      <div className="max-w-md w-full relative z-10 space-y-8">
        <div className="flex flex-col items-center gap-3 mb-4">
          <p className="text-sm text-gray-400">Follow me on social media</p>
          <div className="flex gap-4">
            <a
              href="https://www.youtube.com/@COMBO_WICK"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
            >
              <Youtube className="w-5 h-5" />
              <span className="font-medium">YouTube</span>
            </a>
            <a
              href="https://www.tiktok.com/@combo_wick"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 rounded-lg transition-all"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
              </svg>
              <span className="font-medium">TikTok</span>
            </a>
          </div>
        </div>

        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-4">
            <Lock className="w-3 h-3 text-purple-400" />
            <span className="text-xs font-medium text-gray-300">Content Locked</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
            Complete Steps to Unlock
          </h1>
          <p className="text-gray-400 text-sm">Perform the actions below to access the exclusive content.</p>
        </div>

        <Card className="bg-[#1a1a1a] border-white/5 shadow-2xl overflow-hidden">
          {/* Platform Header */}
          <div className={`p-4 bg-gradient-to-r ${platformColor} flex items-center gap-3`}>
            <PlatformIcon className="w-6 h-6 text-white" />
            <div>
              <p className="font-bold text-white">
                {linkData.platform === "instagram" ? "Instagram" : "Facebook"} Unlock
              </p>
              {linkData.pageName && <p className="text-white/80 text-sm">@{linkData.pageName}</p>}
            </div>
          </div>

          <div className="p-6 space-y-4">
            {linkData.actions.follow && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.follow ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("follow", getPageUrl())}
                disabled={completedActions.follow || isVerifying.follow}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.follow ? "bg-green-500" : platformBg}`}>
                    <UserPlus className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-foreground">
                      Follow {linkData.platform === "instagram" ? "Account" : "Page"}
                    </div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.follow ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.follow ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}

            {linkData.actions.like && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.like ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("like", getPostUrl())}
                disabled={completedActions.like || isVerifying.like}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.like ? "bg-green-500" : "bg-red-500"}`}>
                    <ThumbsUp className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-foreground">Like Post</div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.like ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.like ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}

            {linkData.actions.comment && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.comment ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("comment", getPostUrl())}
                disabled={completedActions.comment || isVerifying.comment}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.comment ? "bg-green-500" : "bg-green-600"}`}>
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-foreground">Comment on Post</div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.comment ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.comment ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}
          </div>

          <div className="p-6 bg-white/5 border-t border-white/5">
            <Button
              className={`w-full h-12 text-lg font-bold transition-all duration-300 ${
                isUnlocked
                  ? `bg-gradient-to-r ${platformColor} hover:opacity-90 shadow-lg`
                  : "bg-gray-700 text-gray-400 cursor-not-allowed"
              }`}
              onClick={handleUnlock}
              disabled={!isUnlocked}
            >
              {getButtonText()}
            </Button>
            {!isUnlocked && (
              <p className="text-center text-xs text-gray-500 mt-3">Checking for completion automatically...</p>
            )}
            {isUnlocked && adClickCount < REQUIRED_AD_CLICKS && (
              <p className="text-center text-xs text-gray-400 mt-3">
                Click the button {REQUIRED_AD_CLICKS - adClickCount} more time
                {REQUIRED_AD_CLICKS - adClickCount > 1 ? "s" : ""} to unlock
              </p>
            )}
          </div>
        </Card>

        <p className="text-center text-xs text-gray-600">Powered by Social Unlock</p>
      </div>
    </div>
  )
}
