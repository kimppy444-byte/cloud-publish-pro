"use client"

import { useEffect, useState, use } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  CheckCircle2,
  Lock,
  ThumbsUp,
  MessageSquare,
  Youtube,
  ArrowRight,
  Loader2,
  Download,
  ExternalLink,
} from "lucide-react"
import { useSearchParams } from "next/navigation"

export default function UnlockPage({ params }: { params: Promise<{ videoId: string }> }) {
  const { videoId } = use(params)
  const searchParams = useSearchParams()

  const [targetUrl, setTargetUrl] = useState<string>("")
  const [channelId, setChannelId] = useState<string>("")
  const [actions, setActions] = useState({ subscribe: true, like: true, comment: false })

  const [completedActions, setCompletedActions] = useState<{ [key: string]: boolean }>({})
  const [isVerifying, setIsVerifying] = useState<{ [key: string]: boolean }>({})
  const [isUnlocked, setIsUnlocked] = useState(false)

  const [adClickCount, setAdClickCount] = useState(0)
  const AD_LINK = "https://otieu.com/4/10327158"
  const REQUIRED_AD_CLICKS = 2

  useEffect(() => {
    try {
      const d = searchParams.get("d")

      if (d) {
        const base64 = d.replace(/-/g, "+").replace(/_/g, "/")
        const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), "=")
        const decoded = JSON.parse(atob(padded))

        if (Array.isArray(decoded) && decoded.length === 3) {
          const [mask, cId, tUrl] = decoded

          const fullChannelId = cId.length === 22 ? `UC${cId}` : cId

          setChannelId(fullChannelId)
          setTargetUrl(tUrl)

          setActions({
            subscribe: (mask & 1) === 1,
            like: (mask & 2) === 2,
            comment: (mask & 4) === 4,
          })
          return
        }
      }

      const t = searchParams.get("t")
      const c = searchParams.get("c")
      const a = searchParams.get("a")

      if (t) setTargetUrl(atob(t))
      if (c) setChannelId(atob(c))
      if (a) setActions(JSON.parse(atob(a)))
    } catch (e) {
      console.error("Failed to parse unlock params", e)
    }
  }, [searchParams])

  const verifyAction = (action: string, url: string) => {
    window.open(url, "_blank")

    setIsVerifying((prev) => ({ ...prev, [action]: true }))

    setTimeout(() => {
      setCompletedActions((prev) => {
        const newState = { ...prev, [action]: true }

        const required = []
        if (actions.subscribe) required.push("subscribe")
        if (actions.like) required.push("like")
        if (actions.comment) required.push("comment")

        const allDone = required.every((req) => newState[req])
        if (allDone) setIsUnlocked(true)

        return newState
      })
      setIsVerifying((prev) => ({ ...prev, [action]: false }))
    }, 5000)
  }

  const handleUnlock = () => {
    if (!isUnlocked) return

    if (adClickCount < REQUIRED_AD_CLICKS) {
      // Open ad link
      window.open(AD_LINK, "_blank")
      setAdClickCount((prev) => prev + 1)
    } else {
      // After 2 clicks, navigate to target URL
      if (targetUrl) {
        window.location.href = targetUrl
      }
    }
  }

  const getButtonText = () => {
    if (!isUnlocked) {
      return (
        <span className="flex items-center gap-2">
          <Lock className="w-4 h-4" />
          Complete Steps to Unlock
        </span>
      )
    }

    if (adClickCount < REQUIRED_AD_CLICKS) {
      return (
        <span className="flex items-center gap-2">
          <ExternalLink className="w-5 h-5" />
          Continue ({adClickCount}/{REQUIRED_AD_CLICKS})
        </span>
      )
    }

    return (
      <span className="flex items-center gap-2">
        <Download className="w-5 h-5" />
        Unlock Link
      </span>
    )
  }

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white flex flex-col items-center justify-center p-4">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/20 blur-[120px] rounded-full" />
      </div>

      <div className="max-w-md w-full relative z-10 space-y-8">
        <div className="flex flex-col items-center gap-3 mb-4">
          <p className="text-sm text-gray-400">Follow me on social media</p>
          <div className="flex gap-4">
            <a
              href="https://www.youtube.com/@COMBO_WICK"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
            >
              <Youtube className="w-5 h-5" />
              <span className="font-medium">YouTube</span>
            </a>
            <a
              href="https://www.tiktok.com/@combo_wick"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 rounded-lg transition-all"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
              </svg>
              <span className="font-medium">TikTok</span>
            </a>
          </div>
        </div>

        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-4">
            <Lock className="w-3 h-3 text-purple-400" />
            <span className="text-xs font-medium text-gray-300">Content Locked</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
            Complete Steps to Unlock
          </h1>
          <p className="text-gray-400 text-sm">Perform the actions below to access the destination link.</p>
        </div>

        <Card className="bg-[#1a1a1a] border-white/5 shadow-2xl overflow-hidden">
          <div className="aspect-video w-full bg-black relative group">
            <iframe
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${videoId}?controls=0&showinfo=0&rel=0`}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              className="opacity-50 group-hover:opacity-100 transition-opacity duration-500"
            />
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
                <Lock className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            {actions.subscribe && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.subscribe ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() =>
                  verifyAction("subscribe", `https://www.youtube.com/channel/${channelId}?sub_confirmation=1`)
                }
                disabled={completedActions.subscribe || isVerifying.subscribe}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.subscribe ? "bg-green-500" : "bg-red-600"}`}>
                    <Youtube className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold">Subscribe to Channel</div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.subscribe ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.subscribe ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}

            {actions.like && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.like ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("like", `https://www.youtube.com/watch?v=${videoId}`)}
                disabled={completedActions.like || isVerifying.like}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.like ? "bg-green-500" : "bg-blue-600"}`}>
                    <ThumbsUp className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold">Like Video</div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.like ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.like ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}

            {actions.comment && (
              <Button
                variant="outline"
                className={`w-full h-14 justify-between group border-white/10 hover:bg-white/5 ${
                  completedActions.comment ? "bg-green-500/10 border-green-500/50 hover:bg-green-500/20" : ""
                }`}
                onClick={() => verifyAction("comment", `https://www.youtube.com/watch?v=${videoId}`)}
                disabled={completedActions.comment || isVerifying.comment}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${completedActions.comment ? "bg-green-500" : "bg-green-600"}`}>
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold">Comment on Video</div>
                    <div className="text-xs text-muted-foreground">Required</div>
                  </div>
                </div>
                {isVerifying.comment ? (
                  <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                ) : completedActions.comment ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                ) : (
                  <ArrowRight className="w-5 h-5 text-gray-500 group-hover:text-white transition-colors" />
                )}
              </Button>
            )}
          </div>

          <div className="p-6 bg-white/5 border-t border-white/5">
            <Button
              className={`w-full h-12 text-lg font-bold transition-all duration-300 ${
                isUnlocked
                  ? "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 shadow-lg shadow-purple-500/25"
                  : "bg-gray-700 text-gray-400 cursor-not-allowed"
              }`}
              onClick={handleUnlock}
              disabled={!isUnlocked}
            >
              {getButtonText()}
            </Button>
            {!isUnlocked && (
              <p className="text-center text-xs text-gray-500 mt-3">Checking for completion automatically...</p>
            )}
            {isUnlocked && adClickCount < REQUIRED_AD_CLICKS && (
              <p className="text-center text-xs text-gray-400 mt-3">
                Click the button {REQUIRED_AD_CLICKS - adClickCount} more time
                {REQUIRED_AD_CLICKS - adClickCount > 1 ? "s" : ""} to unlock
              </p>
            )}
          </div>
        </Card>
      </div>
    </div>
  )
}
