import { redirect } from "next/navigation"
import { getShortLinkData } from "@/app/actions/shorten-link"

export default async function ShortLinkPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params

  try {
    const data = await getShortLinkData(code)

    if (data) {
      redirect(`/unlock/${data.videoId}?d=${data.encodedData}`)
    }
  } catch (error) {
    console.error("Failed to resolve short link:", error)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0f0f0f] text-white">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-2">Link Not Found</h1>
        <p className="text-gray-400">This short link does not exist or has expired.</p>
      </div>
    </div>
  )
}
